# StegoScope v1 Installation Guide

1. Extract `StegoScope-v1.zip` completely.
2. Open the extracted `StegoScope` folder.
3. Select exactly one platform folder.
4. Run the matching installer from that folder.

## Linux / Kali / Ubuntu

Terminal installer:

```bash
cd StegoScope/Linux
bash install.sh
```

Graphical installer:

```bash
cd StegoScope/Linux
bash install-gui.sh
```

The app source remains in `StegoScope/app`. The installer creates
`StegoScope/app/.venv`, installs dependencies, and creates a desktop menu entry.

## Windows

Open `StegoScope\\Windows` and double-click `install-gui.bat`, or run
`install.bat` in Command Prompt. Launch with `run.bat`.

## macOS

```bash
cd StegoScope/macOS
bash install-macos.sh
```

Launch with `bash run.sh` or double-click `StegoScope.command`.

## Uninstall

Use the platform-specific uninstaller where available. Uninstall removes the
private virtual environment and launcher; it does not delete the source folder.
