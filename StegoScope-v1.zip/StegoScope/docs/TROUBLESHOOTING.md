# Troubleshooting

## Kali says externally-managed-environment

Do not run pip against system Python. Use the supplied installer from the
`Linux` folder. It installs into `app/.venv` and handles the PEP 668 restriction.

## GUI installer says PySide6 is missing

Run `bash Linux/install-gui.sh` from the extracted release. It creates a private
bootstrap environment automatically, then opens the graphical installer.

## GUI does not start

Check that Python 3.11 or newer is installed. On Debian/Kali, Python virtual
environment support may be required (`python3-venv`).

## Wrong operating system folder

Use only `Linux`, `Windows`, or `macOS` matching the current operating system.
Do not mix `.sh` and `.bat` launchers.
