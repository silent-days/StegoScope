# StegoScope v1.0.0 OS Packages

Choose exactly one folder for the target operating system. The folders are intentionally separate so platform launchers and installation instructions are not mixed.

## Linux

Use the `Linux/StegoScope-v1.0.0-Linux.zip` package. Extract it, open a terminal in the extracted folder, and run:

```bash
bash install-gui.sh
```

The graphical installer creates the private environment, installs dependencies, creates the desktop entry, and provides Launch/Uninstall buttons. `./run.sh` starts the installed application.

## Windows

Use `Windows/StegoScope-v1.0.0-Windows.zip`. Extract it and double-click `install-gui.bat`. The GUI installer creates `.venv`, installs dependencies, and provides Launch/Uninstall controls. `run.bat` starts the app after installation.

## macOS

Use `macOS/StegoScope-v1.0.0-macOS.zip`. Extract it and run `bash install-macos.sh` from Terminal. The script creates a private `.venv` and writes `StegoScope.command`; double-click that command file to launch the GUI.

All packages require Python 3.11 or newer. The image analysis is offline and the packages do not upload images.
