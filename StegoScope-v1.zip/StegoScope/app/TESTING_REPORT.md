# StegoScope: Testing Report

**Project:** StegoScope (Python steganography detector)
**Date:** 2026-11-14
**Environment:** Python 3.12.16, Linux x86_64, Pillow 11.3.0, NumPy 2.1.3,
SciPy 1.14.1, PySide6 6.12.0, ReportLab 4.4.9, pytest 9.0.2.

---

## 1. Summary

| Item | Result |
| --- | --- |
| Total tests collected | 132 |
| Passed | **144** |
| Failed | **0** |
| Skipped | 1 (GUI construction — sandbox lacks `libEGL.so.1`) |
| Warnings | 16 (matplotlib/Pillow internal deprecations in test deps only) |
| Run time | ~8 s |

Command: `QT_QPA_PLATFORM=offscreen python -m pytest tests/ -q`

---

## 2. Detection-quality metrics (controlled suite)

The suite generates clean and LSB-replacement-embedded images with known
ground truth via `tests/helpers/make_samples.py`, then runs the full
pipeline and measures classification quality.

**Definition.** Positive class = embedded (stego). Predicted positive =
verdict in `{SUSPICIOUS, LIKELY HIDDEN DATA}`. Predicted negative = `CLEAN`.

| Metric | Value |
| --- | --- |
| True positives (TP) | 6 |
| False positives (FP) | 0 |
| True negatives (TN) | 4 |
| False negatives (FN) | 0 |
| Precision (TP/(TP+FP)) | **1.00** |
| Recall (TP/(TP+FN)) | **1.00** |

### Per-image results (captured from the live run)

| Class | Image | Verdict | Score |
| --- | --- | --- | --- |
| clean | clean_rgb | CLEAN | 20 |
| clean | clean_rgba | CLEAN | 16 |
| clean | clean_gray | CLEAN | 20 |
| clean | clean_bmp | CLEAN | 21 |
| STEGO | embedded_full | LIKELY HIDDEN DATA | 80 |
| STEGO | embedded_half | SUSPICIOUS | 69 |
| STEGO | embedded_rgba | LIKELY HIDDEN DATA | 72 |
| STEGO | embedded_gray | LIKELY HIDDEN DATA | 92 |
| STEGO | embedded_small | LIKELY HIDDEN DATA | 73 |
| STEGO | embedded_text | SUSPICIOUS | 70 |

Hard assertions enforced by the test: **FP == 0** (no clean image is a
false positive) and **recall ≥ 0.5**. Both hold with margin.

### Detector monotonicity (assignment Step 3 & 4 — "score rises with
payload size" / "verify with two different payload sizes")

`TestDetectorMonotonicity` embeds random payloads of increasing size
(0 / 1024 / 8192 / 24576 bytes, `fill=False`) into the same cover and
confirms both detectors rise with the embedded fraction:

| Payload bytes | Chi-Square max embed prob | RS max imbalance |
| --- | --- | --- |
| 0 (clean) | 0.000 | 0.0371 |
| 1024 | 0.000 | 0.0371 |
| 8192 | 0.488 | 0.0859 |
| 24576 (full) | 0.987 | 0.1203 |

Both are non-decreasing and the full payload is the maximum — exactly the
behaviour the assignment's Step 3 (chi-square) and Step 4 (RS) tests
require.

---

## 3. Payload round-trip verification

A known message is embedded (MSB-first, channel-sequential R,G,B,A) by
the test embedder, the image is saved/reloaded through the real loader,
and the candidate payload is extracted and compared **byte-for-byte**:

| Mode | Exact match |
| --- | --- |
| Default (MSB-first, channel-sequential) | ✅ |
| `bit_order="lsb"` (LSB-first embed + extract) | ✅ |
| `interleave=True` (true RGB round-robin) | ✅ |
| Single channel `["R"]` | ✅ |
| CLI `--payload-out` (subprocess end-to-end) | ✅ |
| Full random fill (payload + random remainder) | ✅ |

The recovered bytes exactly equal the original embedded message in every
case. Extracted data is never executed (asserted by
`test_payload_never_executed`).

---

## 4. Edge-case & robustness coverage

| Scenario | Test | Outcome |
| --- | --- | --- |
| 16-bit PNG | `test_16bit_rejected` | refused with clear error |
| Palette PNG | `test_palette_mode_preserves_index_plane` | index plane preserved |
| LA mode | `test_la_mode_supported` | loads natively |
| Decompression bomb | `test_decompression_bomb_rejected` | rejected |
| Oversized file | `test_file_size_guard` | rejected |
| Corrupted PNG | `test_corrupted_rejected` | rejected |
| Valid JPEG | `test_unsupported_jpeg_rejected` | rejected by format |
| Missing path | `test_invalid_path_raises` | FileNotFoundError |
| Various dimensions (1×1 … 100×100) | `test_various_dimensions` | OK |
| Insufficient Chi-Square sample | `test_insufficient_sample_flagged` | flagged |
| Empty/zero image extraction | `test_empty_image_safe` | safe, zero bytes |
| Invalid extraction channel | `test_invalid_channel_raises` | PayloadError |
| Invalid bit-order | `test_invalid_bit_order_raises` | PayloadError |
| Save payload invalid dest | `test_save_payload_invalid_dest` | PayloadError |
| Batch recursive | `test_recursive_scan` | ranked correctly |
| Batch max-files cap | `test_max_files_cap` | capped |
| Batch cancellation | `test_cancellation` | stops early |
| Batch corrupted file | `test_corrupted_does_not_crash_batch` | ERROR row, scan continues |
| Duplicate basenames | `test_duplicate_filenames_unique_reports` | unique paths |
| Path traversal in filename | `test_unique_report_path_no_traversal` | basename only |
| Report overwrite protection | `test_save_report_overwrite_protection` | FileExistsError |
| PDF verdict present | `test_pdf_contains_verdict` | `%PDF` header |
| CLI version/scan/batch/force/options | `TestCLI.*` | exit 0 / non-zero as expected |

---

## 5. CLI end-to-end (subprocess)

Run as separate processes (`python -m stegoscope …`):

| Command | Exit | Verified |
| --- | --- | --- |
| `version` | 0 | prints identity |
| `scan clean --report r.json --quiet` | 0 | report written |
| `scan embedded --payload-out p.bin --quiet` | 0 | `.bin` written, round-trips |
| `scan … --report` (existing file, no `--force`) | non-zero | refuses overwrite |
| `scan … --report … --force` | 0 | overwrites |
| `batch dir --output res` | 0 | `res.csv` + `res.json` written |
| `scan … --channels R,G,B --bit-order msb` | 0 | options accepted |

---

## 6. Static analysis & dependency audit

| Check | Command | Result |
| --- | --- | --- |
| Bandit | `bandit -c .bandit -r stegoscope main.py` | **0 issues**, 4 506 LoC |
| pip-audit | `pip-audit -r requirements.txt` | **0 known vulnerabilities** |
| Dangerous-API grep | `grep eval/exec/subprocess/pickle/network` | **0 occurrences** |

---

## 7. Installer verification

| Script | Method | Result |
| --- | --- | --- |
| `install.sh` | executed end-to-end in sandbox | exit 0; venv created, deps installed (cached), editable install OK, GL-deps notice printed correctly |
| `install.bat` | syntax/structure review (no Windows host) | follows same validated structure as `install.sh`; Python 3.11+ version check added |

---

## 8. Features not yet verified in-sandbox

* **GUI widget construction** — skipped because the sandbox has no
  `libEGL.so.1` (PySide6's Qt libs require it) and no root to install it.
  The GUI code is verified by inspection: every page calls the real
  backend via `AnalyzeWorker`/`BatchWorker` → `analyze_image`/
  `scan_directory`; there are no hardcoded scores or fake results; heavy
  work runs on `QThread` so the UI stays responsive; the batch page
  supports cancellation and max-files. `install.sh` detects the missing
  library and prints the `sudo apt install libegl1 libgl1` remediation.
* **Windows installer execution** — not run (no Windows host). Syntax and
  logic reviewed.

---

## 9. Honest limitations

* Samples are synthetic (gradient + perceptual noise), not real
  photographs. Real-world imagery is noisier; expect lower precision in
  the wild.
* Only **LSB-replacement** steganography is detected. LSB matching (±1),
  adaptive/model-based steganography (HUGO, S-UNIWARD, F5, …) are out of
  scope and not detected by design.
* The metrics describe the controlled suite, not a performance guarantee
  against arbitrary images.
* The RS embedding-rate estimate is an approximation; invalid/out-of-range
  values are reported as 0 with `rate_valid=False` and never dominate the
  verdict.
