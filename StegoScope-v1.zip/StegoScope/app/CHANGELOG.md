# StegoScope — Change Log

## v1.0.0 — GitHub-ready stable release

This is the first public stable release line for the rebuilt StegoScope
application. It includes the classic 2D GUI, offline steganalysis pipeline,
install/uninstall scripts, bundled GUI assets, wheel packaging, and CI.

- Stable version identity: **1.0.0**
- 144 automated tests passing
- Linux and Windows launcher installers
- Linux and Windows uninstallers
- `pipx`-compatible `stegoscope` and `stegoscan` commands
- Bundled icons and logo for installed wheels

---

## v2.4.1 — Critical Cleaner Bug Fix + Lint Cleanup

This release fixes the critical cleaner bug reported by the user
("clean karne ke baad bhi same score rehta hai") and clears all
7 bandit security warnings + 66 unused-import warnings reported by
pylint.

### Fixed

- **CRITICAL cleaner bug** — the user's main complaint. The cleaner
  page's "Neutralise LSB plane" checkbox was **default UNCHECKED**,
  and even when the user turned it on, the per-channel checkboxes
  (R, G, B, A, L, P) were **default UNCHECKED**. This meant the
  cleaner silently ran with no operation enabled (or failed the
  "no channels selected" validation), so the cleaned image's LSB
  plane was untouched and the re-analyzed score was unchanged.
    - The "Neutralise LSB plane" checkbox is now **default ON** with
      a clearer label ("...DESTROYS any hidden payload") and a
      longer tooltip explaining *why* it's on by default ("this is
      the operation that actually lowers the Steganography Risk
      Score. Without it the cleaner only strips metadata...").
    - The per-channel checkboxes are now **auto-checked** whenever
      the LSB toggle is turned on. The user can still uncheck
      individual channels if they only want a subset.
    - Added an explicit `_on_lsb_toggled(True)` call at the end of
      `__init__` so the channel checkboxes start in the right state
      (constructor `setChecked(True)` does not fire `toggled`).
    - Verified end-to-end: `embedded_text.png` (score 70 / SUSPICIOUS)
      → cleaned with both options → re-analyzed → **score 21 / CLEAN**.

- **New "Analyze cleaned image" button** on the cleaner page. After
  a successful clean, this primary button becomes enabled; clicking
  it switches to the Image Analysis page, pre-fills the path with
  the cleaned file, and immediately runs the analysis pipeline so
  the user can see the score drop without manual navigation.

### Removed (lint cleanup)

- **All 7 bandit B110 try/except/pass warnings** — replaced each
  bare `except Exception: pass` with a `except Exception as _e:
  get_logger(...).debug(...)` call so the swallowed exception is
  at least logged. Bandit now reports **0 issues** (was 7).
- **All 66 pylint W0611 unused-import warnings** — cleaned up
  imports across:
    - `stegoscope/gui/main_window.py`
    - `stegoscope/gui/splash.py`
    - `stegoscope/gui/nav_button.py`
    - `stegoscope/gui/widgets.py`
    - `stegoscope/gui/icons.py`
    - `stegoscope/gui/session.py`
    - `stegoscope/gui/workers.py`
    - `stegoscope/gui/pages/{about,reports,visual,dashboard,
      image_analysis,settings,rs_analysis,payload,cleaner,
      chi_square,lsb}.py`
    - `stegoscope/core/{verdict,cleaner,batch}.py`
    - `stegoscope/reporting/report.py`
    - `stegoscope/cli/cli.py`

  Pylint now reports **0 unused imports** (was 66).

### Added

- **Regression test** `test_clean_drops_score_significantly` in
  `tests/test_cleaner.py` — guards against the cleaner bug
  recurring. Asserts that cleaning `embedded_text.png` (score >40)
  with both options produces a CLEAN image with a strictly lower
  score. **144 tests pass** (was 143 + 1 new).

### Verified

- Bandit: 0 issues (was 7).
- Pylint W0611: 0 issues (was 66).
- Pytest: 144 passed (was 143).
- End-to-end GUI flow: original (score 70 / SUSPICIOUS) → click
  Clean Image → click Analyze cleaned image → verdict card shows
  CLEAN with score 21 / 100.

---

## v2.4.0 — Classic Icons + Light/Dark Theme Toggle

This release adds a runtime **light/dark theme toggle** in the top bar,
redesigns every nav icon in a consistent classic flat-outline style,
and adds a Qt-aware ThemeManager that broadcasts changes to every
widget.

### Added

- **Light / Dark theme toggle in the top bar.** A new button (with a
  sun icon in dark mode, a moon icon in light mode) sits at the
  top-right of the top bar, next to the status pill. Clicking it flips
  the entire application between the two palettes immediately — no
  restart needed. A tooltip explains the difference:
  "Light: white content cards on cool-gray backdrop, classic deep-navy
  sidebar. Dark: deep-space slate surfaces throughout."

- **ThemeManager** (`stegoscope/gui/theme_manager.py`) — a Qt-aware
  singleton that wraps the new theme module. Emits a `theme_changed`
  Qt signal on every mode switch. The MainWindow connects to this
  signal and triggers a full repaint of the widget tree + clears the
  icon cache so nav icons get re-rendered in the new colors.

- **Dual-palette theme module** (`theme.py` rewritten). Two complete
  palettes (LIGHT and DARK) live in the same file. `set_mode(mode)`
  swaps the active palette; `get_palette()` and `get_qss()` return
  the live values. `APP_COLORS` is now a proxy object that always
  reads the current palette — existing widgets that use
  `APP_COLORS["key"]` keep working without changes.

- **New `QPushButton#ThemeToggle` QSS rule** for the toggle button —
  transparent background, hairline border, accent-color on hover.

- **`nav_sun.svg` and `nav_moon.svg`** — two new classic flat-outline
  icons used by the theme toggle button.

- **6 new tests** for the theme manager (`tests/test_theme_manager.py`)
  covering: initial mode is light, toggle flips mode, set_mode is
  idempotent, palette changes with mode, APP_COLORS proxy reflects
  live mode, get_qss() includes the current palette.

### Changed

- **All 12 nav icons redesigned** in a consistent classic flat-outline
  style (uniform `stroke-width="1.6"`, round caps/joins, simpler
  shapes, no fills, no decorative elements). Specifically:
    - Dashboard: 4-square grid (was 4 rounded squares)
    - Image Analysis: cleaner mountain/sun composition
    - Image Cleaner: pencil-with-eraser shape (was overlapping slash)
    - Advanced LSB: clean 3×3 grid
    - Chi-Square: 3-bar chart (was 4 bars with weird 1px bar)
    - RS Analysis: smooth two-wave line (was 3 dots + line)
    - Batch Scanner: stacked layers (cleaned)
    - Payload Inspector: document with "01" text (was dots inside)
    - Visual Forensics: magnifier-with-cross (cleaned)
    - Reports: document with 2 lines (cleaned)
    - Settings: classic gear (was a confusing slider-icon hybrid
      with invisible lines)
    - About: circle with "i" (cleaned)

- **Splash screen** — now reads the live palette via `get_palette()`
  at paint time. The same splash widget adapts to either theme mode
  without code changes: white card with dark text in light mode,
  deep-space slate with light text in dark mode.

- **`launch_gui`** — now binds the ThemeManager to the QApplication
  via `tm.set_app(app)` so the manager owns the application
  stylesheet and can re-apply it on every mode switch.

- Version bumped to **2.4.0**.

### Verified

- All 143 tests pass (was 137 + 6 new theme-manager tests).
- Light and dark modes both visually verified on Dashboard, About,
  Image Analysis (with verdict + risk-score explainer), Image Cleaner,
  and Settings pages.
- End-to-end theme toggle: clicking the "Dark" button in light mode
  instantly switches the entire UI to dark; clicking the "Light"
  button in dark mode switches back. Nav icons recolor correctly
  in both modes.
- Splash screen renders correctly in both modes.

---

## v2.3.0 — Light Classic Theme

This release replaces the dark theme with a clean **light classic**
theme: white content cards on a soft cool-gray page backdrop, deep
navy sidebar for classic professional contrast. The cleaner module,
risk-score explainer, boot splash and all v2.2.0 features carry over
unchanged.

### Changed

- **Theme** — `theme.py` rewritten for light classic:
    - Page backdrop is now `#F4F6FB` (cool soft gray).
    - Cards are pure white (`#FFFFFF`) on hairline slate-200 borders.
    - Sidebar remains deep navy `#1E293B` (slate-800) — classic
      professional contrast against the light body.
    - Sidebar text uses bright slate-100 / slate-400 — readable on
      the dark sidebar.
    - StatusPill, accent buttons, focus rings, table selections all
      re-tuned for light backgrounds.
    - One primary accent: classic indigo `#4F46E5`; secondary
      sky-blue `#0284C7` for links/highlights.
    - Status palette: emerald / amber / rose — all WCAG-AA against
      white surfaces.

- **`PLOT_PALETTE` in `visualization/plots.py`** synchronized to the
  light theme so matplotlib charts render correctly on white cards.

- **`splash.py`** — splash background is now flat white with a
  slate-200 hairline border. App name in dark slate-900, tagline in
  indigo-600, version in slate-600, status text in slate-600,
  progress bar fill in solid indigo-600.

- **`stegoscope_logo_pro.svg`** retuned for light background:
  magnifier lens fill switched from dark `#0F172A` to white
  `#FFFFFF` so the logo pops against the new white splash.

- **`nav_button.py`** — fixed icon and label color selection to use
  `sidebar_fg` (bright) and `sidebar_dim` (muted) consistently.
  The sidebar is always dark, so the nav button colors must be
  light regardless of body theme.

- Version bumped to **2.3.0**.

### Verified

- All 137 tests pass.
- Dashboard, About, Image Analysis (with verdict + risk score
  explainer card), Image Cleaner, Settings pages all visually
  verified on the new light theme.
- End-to-end analysis of `embedded_text.png` returns SUSPICIOUS
  verdict with the orange badge and "Steganography risk score: 70/100"
  label clearly visible on the light card.
- Splash screen text and progress bar readable on the new white
  background.

---

## v2.2.0 — Image Cleaner, Flat Theme & Risk Score Explainer

This release adds the missing "make image clean" feature, flattens
the GUI theme (no gradients), and makes the verdict score self-
explanatory.

### Added

- **Image Cleaner module** (`stegoscope/core/cleaner.py`) and
  **Image Cleaner page** (`stegoscope/gui/pages/cleaner.py`). The
  cleaner is the symmetric counterpart of the analyzer: it strips
  metadata and/or neutralises the LSB plane so a cleaned image can
  be re-shared safely.
    - **Strip metadata** — removes PNG text chunks (tEXt / zTXt /
      iTXt), EXIF, XMP, ICC profile, gamma, single-color transparency
      hints and the software tag. The visible pixel stream is
      preserved bit-for-bit; only the container's ancillary data is
      dropped.
    - **Neutralise LSB** — forces the LSB of every selected channel
      to 0. Destroys any LSB-replacement payload while keeping the
      high seven bits intact. After cleaning, the LSB plane of each
      channel becomes uniformly zero — any future LSB detector
      returns a 0/100 risk score.
    - Output is always written as PNG (lossless) regardless of the
      input format. The source file is never modified.
    - A "Last clean result" panel reports source / output paths,
      input/output sizes, the list of chunks removed, whether the LSB
      was neutralised, which channels were affected and the total
      bits cleared. An "Open output folder" button is provided.
    - Runs off the UI thread via `_CleanWorker` so the interface
      stays responsive during long operations.

- **Risk-score explainer card** on the Image Analysis page. A new
  always-visible `InfoCard` titled "What is the Steganography Risk
  Score?" explains the 0–100 banding (0–40 CLEAN, 41–70 SUSPICIOUS,
  71–100 LIKELY HIDDEN DATA), the detector weighting (LSB 20%,
  Chi-Square 40%, RS 40%), and explicitly notes the score is a
  statistical indicator, not proof of payload.

- **Tooltips on the risk-score label**. Hovering the "Steganography
  risk score" label shows the full banding explanation.

- **`nav_cleaner.svg`** — a new professional line-icon for the
  cleaner page (pencil-with-slash).

- **Sidebar grouping updated** to "Overview / Analysis / Clean &
  Investigate / System" to reflect the new cleaner entry.

### Changed

- **Flat theme.** Removed all `qlineargradient` declarations from
  `theme.py` (progress-bar chunk, slider sub-page) and from
  `nav_button.py` (active-state accent strip). The splash screen's
  background is now a flat solid color (the radial glow and the
  vertical background gradient were removed); the splash progress
  bar fill is now a single solid indigo. The whole interface is now
  genuinely 2-D / flat with no simulated depth, no glow, no
  gradients.

- **"Score" → "Steganography risk score"** everywhere in the UI:
    - Image Analysis verdict card label.
    - Image Analysis status-pill message (e.g. "embedded_text.png:
      SUSPICIOUS (risk score 70/100)").
    - Per-channel chart title ("Per-channel risk score breakdown").
    - Refresh-empty state.

- **About page capabilities matrix** updated to include the new
  Image Cleaner capability and the 100% local processing guarantee.

- Version bumped to **2.2.0**.

### Fixed

- **Critical QSS bug** (carried from v2.1.0): bare
  `setStyleSheet("background: transparent;")` calls were cascading
  to descendant widgets and stripping backgrounds off buttons inside
  Cards. All call-sites in the new Image Analysis and Cleaner pages
  now use the `_make_transparent()` helper which assigns a unique
  objectName and uses a targeted `QWidget#name` selector.

### Verified end-to-end

- `samples/embedded_text.png` (originally SUSPICIOUS, score 70/100)
  → cleaned with both metadata-strip + LSB-neutralise →
  re-analyzed → **CLEAN, score 21/100**.
- All 132 tests pass.

---

## v2.1.0 — Premium Theme, Boot Splash & About Overhaul

This release is a complete visual refresh of the StegoScope desktop
application. The detection engine, command-line interface, batch
scanner, payload extractor and reporting pipeline are unchanged; the
focus is entirely on the user experience.

### Added

- **3-second animated boot splash** (`stegoscope/gui/splash.py`).
  A custom-painted `BootSplash` widget runs at application start and
  plays a multi-stage animation: logo fade-in + scale-up, an outer
  progress ring that sweeps clockwise, the tagline and version fade-in,
  a horizontal progress bar that fills 0→100% with a cyan→indigo
  gradient, and rotating status messages ("Initializing detection
  engine", "Loading LSB · Chi-Square · RS detectors", "Preparing
  forensic interface", "Ready"). The splash uses the new SVG logo at
  `assets/icons/stegoscope_logo_pro.svg`.

- **Premium dark forensic theme** (`stegoscope/gui/theme.py`). The
  old light theme has been replaced with a deep-space slate-950 backdrop,
  pure-white content cards with hairline indigo borders, dual accents
  (indigo `#6366F1` + cyan `#06B6D4`), and emerald / amber / rose
  status colours that meet WCAG-AA against the dark surfaces.

- **11 professional SVG nav icons** (`assets/icons/nav_*.svg`). The
  Unicode-symbol nav icons have been replaced with hand-drawn, stroke-
  based line icons (dashboard, image, LSB grid, bar chart, waveform,
  layers, document, scope, list, sliders, info) that recolour
  dynamically for the active / hover / idle states.

- **Animated navigation buttons** (`stegoscope/gui/nav_button.py`).
  Each `NavButton` is a custom-painted widget that animates a left
  accent strip (gradient indigo→cyan→violet) and recolours its icon
  via `QPropertyAnimation` on `glow` and `hoverProgress` Qt
  properties. The sidebar is now organised into four section groups
  (Overview, Analysis, Investigation, System) with caption labels.

- **Page-transition fade animation** (`_FadeStack` in
  `main_window.py`). Switching between sidebar items animates the new
  page's opacity from 0 → 1 with an `OutCubic` easing curve (~220 ms)
  instead of an abrupt swap.

- **Comprehensive About page** (`stegoscope/gui/pages/about.py`).
  The About page is now a seven-section presentation: identity hero
  card (logo, version, developer, licence, build date), mission
  statement, detection methodology (three detector info-cards with
  citations), investigation workflow (five numbered stages),
  capabilities matrix (8 features in two columns), honest limitations
  + privacy & security posture, and references / acknowledgements
  (Westfeld-Pfitzmann 2000, Fridrich-Goljan-Du 2001, MIT licence).

- **Refreshed dashboard widgets** — `StatCard` now carries an
  optional SVG icon and a colored left accent strip; `InfoCard` for
  key/title/body layouts; an empty-state message replaces the
  previously-empty Recent Investigations table.

- **`stegoscope/gui/icons.py`** — a small in-memory SVG icon loader
  that recolours and caches nav icons per state.

### Fixed

- **Critical QSS bug**: bare `widget.setStyleSheet("background:
  transparent;")` was being applied in several places (QScrollArea,
  Card wrapper, StatCard body, About-page containers). Because a
  selector-less Qt stylesheet cascades to *all* descendants, this
  was silently stripping the indigo fill off `QPushButton#Primary`
  and other themed widgets. Introduced `_make_transparent(widget)`
  in `widgets.py` which assigns a unique objectName and uses a
  targeted `QWidget#name` selector. All call-sites updated.

- **Page-switch race condition**: the previous `_FadeStack` switched
  the underlying page only after the fade-out animation finished, so
  a screenshot / grab taken immediately after `setCurrentIndex(idx)`
  returned the *previous* page (or an empty widget). Rewritten to
  switch the underlying page immediately and fade the new widget's
  opacity from 0 → 1.

- **Tagline clipping**: the "STEGANOGRAPHY INTELLIGENCE" label in the
  sidebar overflowed its 240 px column. Shortened to "STEGANOGRAPHY
  INTEL" and reduced letter-spacing.

- **Top-bar subtitle**: the leading "·" character was rendering as a
  hyphen on some systems; the subtitle now reads cleanly without a
  leading separator.

### Changed

- `APP_COLORS` palette replaced with a dark-mode set; the previous
  light-mode colors are removed.
- `PLOT_PALETTE` in `visualization/plots.py` synchronized with the
  new theme so matplotlib charts render correctly on dark cards.
- `MatplotlibCanvas` now sets a transparent Qt background so the
  figure facecolor shows through, with `min/max` heights to prevent
  oversized empty-state canvases.
- Version bumped to **2.1.0** in both `stegoscope/__init__.py` and
  `pyproject.toml`.

### Compatibility

- The detection engine, CLI, reporting, batch scanner and payload
  extractor APIs are unchanged. Existing scripts, tests (132 passing)
  and reports continue to work without modification.
- `Python 3.11+`, `PySide6 >= 6.6`, `Pillow`, `numpy`, `scipy`,
  `matplotlib`, `reportlab` — same runtime dependencies as 2.0.0.
