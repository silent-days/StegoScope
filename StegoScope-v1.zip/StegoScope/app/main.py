#!/usr/bin/env python3
"""StegoScope application entry point.

Run with no arguments (or ``--gui``) to launch the desktop GUI::

    python main.py
    python main.py --gui

Run with a CLI subcommand to use the command-line interface::

    python main.py version
    python main.py scan image.png --extract
    python main.py batch ./images/ --output results

This dispatcher lets a single executable serve both interfaces; the
``stegoscope`` console script (see ``pyproject.toml``) routes here too.

The GUI requires PySide6. If PySide6 is not importable in the current
Python (e.g. the script was run with the system interpreter instead of
the project virtual environment created by ``install.sh``), ``main.py``
prints a clear, actionable message rather than a raw traceback. The CLI
does not require PySide6 and continues to work in that case.
"""

from __future__ import annotations

import sys


def _pyside_available() -> bool:
    """Return True if PySide6 is importable, without actually importing it.

    Uses ``importlib.util.find_spec`` so we never trigger PySide6's
    import-time side effects (or its GUI shared-library loads) just to
    probe for it.
    """
    try:
        import importlib.util
        return importlib.util.find_spec("PySide6") is not None
    except Exception:
        return False


def _gui_missing_message() -> None:
    sys.stderr.write(
        "StegoScope GUI could not start: PySide6 is not available in this "
        "Python interpreter.\n"
    )
    sys.stderr.write("\n")
    sys.stderr.write("The command-line interface still works, e.g.:\n")
    sys.stderr.write("    python -m stegoscope version\n")
    sys.stderr.write("    python -m stegoscope scan image.png --report report.pdf\n")
    sys.stderr.write("\n")
    sys.stderr.write("To launch the GUI, use the launcher that activates the\n")
    sys.stderr.write("project virtual environment created by install.sh:\n")
    sys.stderr.write("    Linux / macOS:   ./run.sh\n")
    sys.stderr.write("    Windows:         run.bat\n")
    sys.stderr.write("\n")
    sys.stderr.write("Or install PySide6 into this interpreter:\n")
    sys.stderr.write("    pip install PySide6\n")
    sys.stderr.write("\n")
    sys.stderr.write(
        "(If you ran install.sh, the venv at .venv/ already has PySide6 — "
        "run ./run.sh, or .venv/bin/python main.py, instead of plain "
        "'python main.py'.)\n"
    )


def _try_launch_gui() -> int:
    """Launch the GUI, or print an actionable message and exit non-zero."""
    if not _pyside_available():
        _gui_missing_message()
        return 6
    try:
        from stegoscope.gui import launch_gui
    except ImportError as exc:  # PySide6 present-but-broken (e.g. missing libs)
        sys.stderr.write(
            f"StegoScope GUI could not start: PySide6 failed to import "
            f"({exc.__class__.__name__}: {exc}).\n"
        )
        sys.stderr.write(
            "On Linux this usually means a missing system library such as "
            "libEGL / libGL. Install them with your package manager, e.g.:\n"
            "    Debian / Ubuntu / Kali:  sudo apt install libegl1 libgl1\n"
            "    Arch / BlackArch:        sudo pacman -S libegl libgl\n"
        )
        sys.stderr.write(
            "The CLI still works:  python -m stegoscope version\n"
        )
        return 6
    return launch_gui()


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    cli_commands = {"version", "scan", "batch", "--help", "-h"}
    if argv and (argv[0] in cli_commands or argv[0] == "gui" or argv[0] == "--gui"):
        if argv[0] in ("gui", "--gui"):
            return _try_launch_gui()
        from stegoscope.cli import main as cli_main
        return cli_main(argv)

    # Default: launch the desktop GUI.
    return _try_launch_gui()


if __name__ == "__main__":
    raise SystemExit(main())
