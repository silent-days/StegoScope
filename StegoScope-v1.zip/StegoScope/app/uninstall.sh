#!/usr/bin/env bash
# StegoScope — Linux uninstaller
# Removes the local application environment and launcher; source files remain.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PURGE=0
for arg in "$@"; do
  case "$arg" in
    --purge) PURGE=1 ;;
    -h|--help)
      cat <<'EOF'
Usage: ./uninstall.sh [--purge]

Removes the StegoScope desktop launcher and local .venv. The source tree,
samples and reports are kept. --purge also removes build/test caches.
EOF
      exit 0
      ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done
DESKTOP_FILE="${HOME}/.local/share/applications/StegoScope.desktop"
if [ -f "$DESKTOP_FILE" ]; then
  rm -f "$DESKTOP_FILE"
  echo "Removed desktop launcher: $DESKTOP_FILE"
else
  echo "Desktop launcher not present."
fi
if [ -d "$SCRIPT_DIR/.venv" ]; then
  rm -rf "$SCRIPT_DIR/.venv"
  echo "Removed local virtual environment: $SCRIPT_DIR/.venv"
else
  echo "Virtual environment not present."
fi
if [ "$PURGE" -eq 1 ]; then
  rm -rf "$SCRIPT_DIR/build" "$SCRIPT_DIR/dist" "$SCRIPT_DIR/.pytest_cache" \
         "$SCRIPT_DIR/.coverage" "$SCRIPT_DIR/stegoscope.egg-info"
  echo "Removed build and test caches. Source files were preserved."
fi
command -v update-desktop-database >/dev/null 2>&1 && \
  update-desktop-database "${HOME}/.local/share/applications" >/dev/null 2>&1 || true
echo "StegoScope uninstalled from this checkout. You can reinstall with ./install.sh."
