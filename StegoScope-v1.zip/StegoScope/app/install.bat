@echo off
REM
REM StegoScope - Windows installer (StegoScope)
REM Creates a virtual environment and installs dependencies.
REM
setlocal enabledelayedexpansion

cd /d "%~dp0"

set "PY=python"

echo ============================================================
echo   StegoScope : Windows installer
echo   Using interpreter: %PY%
echo ============================================================

REM ---- 1. sanity check ------------------------------------------------
%PY% --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: '%PY%' not found on PATH. 1>&2
    echo        Install Python 3.11+ from https://www.python.org/ 1>&2
    echo        (tick "Add python.exe to PATH" during install) and rerun. 1>&2
    exit /b 1
)

REM ---- 2. Python version validation (3.11+) --------------------------
for /f "tokens=*" %%V in ('%PY% -c "import sys;print(f'{sys.version_info[0]}.{sys.version_info[1]}')"') do set "PYVER=%%V"
for /f "tokens=1 delims=." %%A in ("%PYVER%") do set "PYMAJ=%%A"
for /f "tokens=2 delims=." %%B in ("%PYVER%") do set "PYMIN=%%B"
if !PYMAJ! LSS 3 goto :badversion
if !PYMAJ! EQU 3 if !PYMIN! LSS 11 goto :badversion
echo Detected Python %PYVER% - OK.
goto :continue

:badversion
echo ERROR: Python 3.11+ required, found %PYVER%. 1>&2
exit /b 1

:continue
REM ---- 3. virtual environment ----------------------------------------
if not exist ".venv" (
    echo [1/4] creating virtual environment (.venv^) ...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo ERROR: failed to create virtual environment. 1>&2
        exit /b 1
    )
)

echo [2/4] upgrading pip ...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip --quiet

echo [3/4] installing requirements ...
python -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: dependency installation failed. 1>&2
    echo        Check your internet connection and rerun. 1>&2
    exit /b 1
)

echo [4/4] installing stegoscope ...
python -m pip install . --quiet
if errorlevel 1 (
    echo ERROR: package install failed. 1^>2
    exit /b 1
)

echo.
echo ============================================================
echo   Installation complete.
echo   Launch the GUI with:    run.bat
echo   Run the CLI with:       .venv\Scripts\stegoscope version
echo   Run the test suite:     .venv\Scripts\python -m pytest tests\
echo ============================================================
echo.
echo Troubleshooting:
echo   - If the GUI fails to start, install the Microsoft Visual
echo     C++ Redistributable (x64) from Microsoft's download site.
echo   - If 'python' is not found, use the full path to python.exe
echo     or rerun the Python installer with "Add to PATH" enabled.
goto :eof
