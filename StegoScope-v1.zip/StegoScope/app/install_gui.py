#!/usr/bin/env python3
"""Native graphical installer/uninstaller for StegoScope."""
from __future__ import annotations
import os
import shutil
import subprocess
import sys
from pathlib import Path
from PySide6.QtCore import QProcess, Qt
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QMessageBox, QProgressBar, QPushButton, QPlainTextEdit, QVBoxLayout)

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
DESKTOP = Path.home() / ".local/share/applications/StegoScope.desktop"

def vpy() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

def vgui() -> Path:
    return VENV / ("Scripts/stegoscope-gui.exe" if os.name == "nt" else "bin/stegoscope-gui")

class Setup(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("StegoScope Setup")
        self.resize(760, 520)
        self.proc = None
        self.stage = 0
        root = QVBoxLayout(self)
        title = QLabel("StegoScope")
        title.setStyleSheet("font-size:26px;font-weight:700;color:#172554;")
        root.addWidget(title)
        self.status = QLabel("Install StegoScope v1.0.0")
        self.status.setStyleSheet("font-size:14px;font-weight:600;")
        root.addWidget(self.status)
        self.detail = QLabel("A private environment and desktop menu entry will be created.")
        root.addWidget(self.detail)
        self.progress = QProgressBar(); self.progress.setRange(0, 3); root.addWidget(self.progress)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); root.addWidget(self.log, 1)
        row = QHBoxLayout(); root.addLayout(row)
        self.install_btn = QPushButton("Install StegoScope"); self.install_btn.clicked.connect(self.install); row.addWidget(self.install_btn)
        self.launch_btn = QPushButton("Launch"); self.launch_btn.setEnabled(False); self.launch_btn.clicked.connect(self.launch); row.addWidget(self.launch_btn)
        self.uninstall_btn = QPushButton("Uninstall"); self.uninstall_btn.clicked.connect(self.uninstall); row.addWidget(self.uninstall_btn)
        close = QPushButton("Close"); close.clicked.connect(self.close); row.addWidget(close)

    def append(self, text): self.log.appendPlainText(str(text).rstrip())
    def install(self):
        self.install_btn.setEnabled(False); self.uninstall_btn.setEnabled(False); self.launch_btn.setEnabled(False)
        self.progress.setValue(0); self.stage = 0
        self.run([sys.executable, "-m", "venv", str(VENV)], "Creating private environment")

    def run(self, command, label):
        self.status.setText(label + "…"); self.append("$ " + " ".join(map(str, command)))
        self.proc = QProcess(self); self.proc.setWorkingDirectory(str(ROOT)); self.proc.setProcessChannelMode(QProcess.MergedChannels)
        self.proc.readyReadStandardOutput.connect(lambda: self.append(bytes(self.proc.readAllStandardOutput()).decode(errors="replace")))
        self.proc.finished.connect(self.next_step); self.proc.start(str(command[0]), [str(x) for x in command[1:]])

    def next_step(self, code, _status):
        if code != 0:
            self.status.setText("Operation failed"); self.detail.setText("See the installer log above."); self.install_btn.setEnabled(True); self.uninstall_btn.setEnabled(True); return
        self.stage += 1; self.progress.setValue(self.stage)
        if self.stage == 1: self.run([str(vpy()), "-m", "pip", "install", "-r", "requirements.txt"], "Installing dependencies")
        elif self.stage == 2: self.run([str(vpy()), "-m", "pip", "install", "."], "Installing StegoScope")
        else:
            self.write_desktop(); self.status.setText("Installation complete"); self.detail.setText("StegoScope is ready. Click Launch to open it."); self.launch_btn.setEnabled(True); self.install_btn.setEnabled(True); self.uninstall_btn.setEnabled(True)

    def write_desktop(self):
        if os.name == "nt": return
        DESKTOP.parent.mkdir(parents=True, exist_ok=True)
        run = ROOT / "run.sh"
        DESKTOP.write_text(f"[Desktop Entry]\nName=StegoScope\nComment=Steganography detection suite\nTryExec={run}\nExec=\"{run}\"\nIcon={ROOT / 'assets/icons/stegoscope_logo.png'}\nTerminal=false\nType=Application\nCategories=Security;Utility;\n")
        self.append("Desktop menu entry created.")

    def launch(self):
        if vgui().exists(): subprocess.Popen([str(vgui())], cwd=ROOT)
        else: QMessageBox.warning(self, "Not installed", "Install StegoScope first.")

    def uninstall(self):
        if QMessageBox.question(self, "Uninstall StegoScope", "Remove the private environment and desktop launcher?\nSource files will remain.") != QMessageBox.StandardButton.Yes: return
        try:
            if VENV.exists(): shutil.rmtree(VENV)
            if DESKTOP.exists(): DESKTOP.unlink()
            self.log.appendPlainText("Private environment and desktop launcher removed.")
            self.status.setText("StegoScope uninstalled"); self.launch_btn.setEnabled(False)
        except Exception as exc: QMessageBox.critical(self, "Uninstall failed", str(exc))

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyleSheet("QPushButton{padding:7px 14px;} QPlainTextEdit{background:#0f172a;color:#dbeafe;}")
    dlg = Setup(); dlg.show(); sys.exit(app.exec())
