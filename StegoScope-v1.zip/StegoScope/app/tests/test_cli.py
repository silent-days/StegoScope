"""Tests for the CLI interface."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from stegoscope.cli import main as cli_main


def test_cli_version(capsys):
    rc = cli_main(["version"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "StegoScope" in out
    from stegoscope import __version__
    assert __version__ in out


def test_cli_scan_writes_report(samples, tmp_path, capsys):
    out = tmp_path / "report.json"
    rc = cli_main(["scan", str(samples["embedded_text"]),
                   "--report", str(out), "--quiet"])
    assert rc == 0
    assert out.exists()
    data = json.loads(out.read_text())
    assert data["info"]["filename"] == "embedded_text.png"


def test_cli_scan_extract_payload(samples, tmp_path, capsys):
    payload = tmp_path / "candidate.bin"
    rc = cli_main(["scan", str(samples["embedded_text"]),
                   "--payload-out", str(payload), "--quiet"])
    assert rc == 0
    assert payload.exists()
    assert b"STEGOSCOPE-FORENSIC-MARKER" in payload.read_bytes()


def test_cli_scan_missing_file(tmp_path, capsys):
    rc = cli_main(["scan", str(tmp_path / "nope.png")])
    assert rc == 2


def test_cli_scan_unsupported_format(samples, tmp_path, capsys):
    rc = cli_main(["scan", str(samples["jpeg"])])
    assert rc == 3


def test_cli_scan_pdf_report(samples, tmp_path):
    out = tmp_path / "report.pdf"
    rc = cli_main(["scan", str(samples["clean_rgb"]),
                   "--report", str(out), "--quiet"])
    assert rc == 0
    assert out.exists()
    assert out.read_bytes()[:4] == b"%PDF"


def test_cli_batch_writes_csv_json(samples, tmp_path, capsys):
    d = samples["clean_rgb"].parent
    stem = tmp_path / "batch_results"
    rc = cli_main(["batch", str(d), "--output", str(stem)])
    assert rc == 0
    assert stem.with_suffix(".csv").exists()
    assert stem.with_suffix(".json").exists()


def test_cli_batch_rejects_nonexistent(tmp_path, capsys):
    rc = cli_main(["batch", str(tmp_path / "nope")])
    assert rc == 2


def test_cli_scan_txt_to_stdout(samples, capsys):
    rc = cli_main(["scan", str(samples["clean_rgb"])])
    assert rc == 0
    out = capsys.readouterr().out
    assert "StegoScope" in out
    assert "VERDICT" in out


def test_cli_no_command_prints_help(capsys):
    with pytest.raises(SystemExit):
        cli_main([])  # argparse requires a subcommand
