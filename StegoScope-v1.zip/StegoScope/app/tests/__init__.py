"""StegoScope test suite."""
