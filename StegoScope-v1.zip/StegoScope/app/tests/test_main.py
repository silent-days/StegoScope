"""Tests for the main.py entry-point dispatcher.

Covers the GUI-fallback behaviour: when PySide6 is not importable,
``main.py`` must print an actionable message and return a non-zero
exit code instead of raising a traceback. This is the regression guard
for the real-world failure where the script is run with the system
interpreter (no PySide6) rather than the project virtual environment.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def main_module():
    """Load main.py as an isolated module (avoids the generic name clash)."""
    spec = importlib.util.spec_from_file_location(
        "stegoscope_main", ROOT / "main.py")
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_pyside_available_when_installed(main_module):
    """The test environment has PySide6, so the probe must return True."""
    assert main_module._pyside_available() is True


def test_gui_fallback_when_pyside_absent(main_module, capsys, monkeypatch):
    monkeypatch.setattr(main_module, "_pyside_available", lambda: False)
    rc = main_module.main([])          # no args -> GUI path
    assert rc == 6
    err = capsys.readouterr().err
    assert "PySide6" in err
    assert "./run.sh" in err
    assert "pip install PySide6" in err
    # must NOT have raised a traceback
    assert "Traceback" not in err


def test_gui_fallback_on_import_error(main_module, capsys, monkeypatch):
    """If PySide6 is 'present' per find_spec but breaks at import time
    (e.g. missing libEGL), the fallback still fires with a helpful hint."""
    monkeypatch.setattr(main_module, "_pyside_available", lambda: True)
    import builtins
    real_import = builtins.__import__

    def _boom(name, *a, **k):
        if name.startswith("stegoscope.gui"):
            raise ImportError("libEGL.so.1: cannot open shared object file")
        return real_import(name, *a, **k)

    monkeypatch.setattr(builtins, "__import__", _boom)
    rc = main_module.main([])
    assert rc == 6
    err = capsys.readouterr().err
    assert "libEGL" in err or "libegl" in err.lower() or "PySide6" in err
    assert "Traceback" not in err


def test_cli_dispatch_still_works(main_module, capsys):
    rc = main_module.main(["version"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "StegoScope" in out


def test_explicit_gui_flag_routes_to_launcher(main_module, monkeypatch):
    """`main.py --gui` must route through the guarded launcher, not the CLI
    and not a direct PySide6 import. We stub the launcher so no GUI is
    actually started."""
    called = {"n": 0}

    def _fake_launch():
        called["n"] += 1
        return 0

    monkeypatch.setattr(main_module, "_try_launch_gui", _fake_launch)
    rc = main_module.main(["--gui"])
    assert rc == 0
    assert called["n"] == 1


def test_no_args_routes_to_launcher(main_module, monkeypatch):
    """No arguments at all also routes to the GUI launcher."""
    called = {"n": 0}
    monkeypatch.setattr(main_module, "_try_launch_gui",
                        lambda: called.__setitem__("n", called["n"] + 1) or 0)
    rc = main_module.main([])
    assert rc == 0
    assert called["n"] == 1
