"""Tests for the theme manager (light / dark switching)."""
from __future__ import annotations

import pytest


def test_theme_manager_initial_mode_is_light():
    """The default mode on first import is LIGHT."""
    from stegoscope.gui import theme
    assert theme.get_mode() == theme.Mode.LIGHT


def test_theme_manager_toggle_flips_mode():
    """Toggling the mode flips between LIGHT and DARK."""
    from stegoscope.gui import theme
    from stegoscope.gui.theme_manager import ThemeManager

    initial = theme.get_mode()
    tm = ThemeManager()
    tm.toggle()
    assert theme.get_mode() != initial
    # Toggle back to leave the global state clean.
    tm.toggle()
    assert theme.get_mode() == initial


def test_theme_manager_set_mode_same_mode_noop():
    """Setting the same mode is a no-op."""
    from stegoscope.gui import theme
    from stegoscope.gui.theme_manager import ThemeManager

    initial = theme.get_mode()
    tm = ThemeManager()
    tm.set_mode(initial)
    assert theme.get_mode() == initial


def test_theme_palette_changes_with_mode():
    """The palette returned by get_palette reflects the current mode."""
    from stegoscope.gui import theme

    theme.set_mode(theme.Mode.LIGHT)
    light_palette = theme.get_palette()
    assert light_palette["bg"] == "#F4F6FB"

    theme.set_mode(theme.Mode.DARK)
    dark_palette = theme.get_palette()
    assert dark_palette["bg"] == "#0B1020"

    # Reset for other tests.
    theme.set_mode(theme.Mode.LIGHT)


def test_palette_proxy_reflects_live_mode():
    """APP_COLORS (the proxy) always reads the current palette."""
    from stegoscope.gui import theme

    theme.set_mode(theme.Mode.LIGHT)
    assert theme.APP_COLORS["bg"] == "#F4F6FB"

    theme.set_mode(theme.Mode.DARK)
    assert theme.APP_COLORS["bg"] == "#0B1020"

    # Reset.
    theme.set_mode(theme.Mode.LIGHT)
    assert theme.APP_COLORS["bg"] == "#F4F6FB"


def test_qss_reflects_current_palette():
    """get_qss() includes the current palette's background color."""
    from stegoscope.gui import theme

    theme.set_mode(theme.Mode.LIGHT)
    light_qss = theme.get_qss()
    assert "#F4F6FB" in light_qss

    theme.set_mode(theme.Mode.DARK)
    dark_qss = theme.get_qss()
    assert "#0B1020" in dark_qss

    # Reset for other tests.
    theme.set_mode(theme.Mode.LIGHT)
