"""Tests for candidate payload extraction."""

from __future__ import annotations

from stegoscope.core.image_loader import ImageLoader
from stegoscope.extraction.payload import extract_payload, save_payload


def test_extract_returns_bytes(samples):
    img = ImageLoader().load(samples["embedded_text"])
    res = extract_payload(img, max_bytes=4096)
    assert res.byte_count > 0
    assert res.byte_count <= 4096
    assert len(res.data) == res.byte_count
    assert res.bits_used <= res.total_bits_available
    assert res.channel_order == list(img.channels)


def test_known_marker_round_trips(samples):
    """The plaintext marker embedded by the sample generator must be
    recovered verbatim from the extracted candidate stream."""
    img = ImageLoader().load(samples["embedded_text"])
    res = extract_payload(img, max_bytes=8192)
    marker = b"STEGOSCOPE-FORENSIC-MARKER"
    assert marker in res.data, "embedded marker not recovered"


def test_extract_truncation_respects_cap(samples):
    img = ImageLoader().load(samples["embedded_full"])
    res = extract_payload(img, max_bytes=16)
    assert res.byte_count <= 16
    assert res.truncated is True


def test_save_payload_writes_bin(tmp_path, samples):
    img = ImageLoader().load(samples["embedded_text"])
    res = extract_payload(img, max_bytes=512)
    out = save_payload(res, tmp_path / "candidate.txt")
    assert out.suffix == ".bin"
    assert out.exists()
    assert out.read_bytes() == res.data


def test_extract_from_clean_image_is_safe(samples):
    """Extracting from a clean image must not raise; it just yields
    candidate bytes that are not interpreted in any way."""
    img = ImageLoader().load(samples["clean_rgb"])
    res = extract_payload(img, max_bytes=256)
    assert res.byte_count == 256
    # Hex/ascii previews are present and printable-only.
    assert all(c in "0123456789abcdef " for c in res.hex_preview)


def test_payload_never_executed(samples):
    """Sanity: the extraction API exposes data only — there is no code
    path that interprets or executes the bytes. We assert the module
    has no 'eval' / 'exec' / 'system' / 'Popen' references."""
    import stegoscope.extraction.payload as mod
    import inspect
    src = inspect.getsource(mod)
    for forbidden in ("eval(", "exec(", "os.system", "subprocess.",
                      "Popen", "os.popen"):
        assert forbidden not in src, f"forbidden call in payload module: {forbidden}"
