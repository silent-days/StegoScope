"""Tests for LSB-plane analysis."""

from __future__ import annotations

import numpy as np

from stegoscope.core.image_loader import ImageLoader
from stegoscope.analysis.lsb import run_lsb_analysis


def test_lsb_returns_one_stats_per_channel(samples):
    for key, expected_channels in [
        ("clean_rgb", ("R", "G", "B")),
        ("clean_rgba", ("R", "G", "B", "A")),
        ("clean_gray", ("L",)),
    ]:
        img = ImageLoader().load(samples[key])
        res = run_lsb_analysis(img)
        names = tuple(c.channel for c in res.channels)
        assert names == expected_channels


def test_lsb_percentages_sum_to_100(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_lsb_analysis(img)
    for c in res.channels:
        assert abs(c.zero_pct + c.one_pct - 100.0) < 1e-3
        assert c.zero_count + c.one_count == c.total_bits


def test_lsb_mean_in_range(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_lsb_analysis(img)
    for c in res.channels:
        assert 0.0 <= c.lsb_mean <= 1.0


def test_lsb_longest_run_positive(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_lsb_analysis(img)
    for c in res.channels:
        assert c.longest_run >= 1
        assert c.longest_run_value in (0, 1)


def test_embedded_image_has_balanced_lsb(samples):
    """A fully random-embedded channel has an LSB mean near 0.5."""
    img = ImageLoader().load(samples["embedded_full"])
    res = run_lsb_analysis(img)
    for c in res.channels:
        # random fill -> mean within ~0.02 of 0.5 for 65k pixels
        assert abs(c.lsb_mean - 0.5) < 0.05


def test_lsb_imbalance_nonneg(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_lsb_analysis(img)
    assert res.channel_imbalance >= 0.0
