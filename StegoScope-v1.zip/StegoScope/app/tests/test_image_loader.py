"""Tests for the image loader."""

from __future__ import annotations

import pytest

from stegoscope.core.image_loader import (ImageData, ImageLoader,
                                           UnsupportedFormatError)
from stegoscope.utils.limits import ImageTooLargeError


def test_load_png_rgb(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    assert isinstance(img, ImageData)
    assert img.format == "PNG"
    assert img.mode == "RGB"
    assert img.channels == ("R", "G", "B")
    assert img.width == 256 and img.height == 256
    assert img.array.shape == (256, 256, 3)
    assert img.array.dtype.name == "uint8"


def test_load_png_rgba(samples):
    img = ImageLoader().load(samples["clean_rgba"])
    assert img.mode == "RGBA"
    assert img.channels == ("R", "G", "B", "A")
    assert img.array.shape[2] == 4


def test_load_png_grayscale(samples):
    img = ImageLoader().load(samples["clean_gray"])
    assert img.mode == "L"
    assert img.channels == ("L",)
    # grayscale is stored with a channel axis for uniform indexing
    assert img.array.shape == (256, 256, 1)


def test_load_bmp(samples):
    img = ImageLoader().load(samples["clean_bmp"])
    assert img.format == "BMP"
    assert img.mode == "RGB"


def test_reject_jpeg(samples):
    with pytest.raises(UnsupportedFormatError):
        ImageLoader().load(samples["jpeg"])


def test_reject_corrupted(samples):
    with pytest.raises(UnsupportedFormatError):
        ImageLoader().load(samples["corrupted"])


def test_reject_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        ImageLoader().load(tmp_path / "does_not_exist.png")


def test_enforce_limits_rejects_huge():
    from stegoscope.utils.limits import enforce_limits, ImageLimits
    with pytest.raises(ImageTooLargeError):
        enforce_limits(width=100000, height=100000, file_size=1000)


def test_channel_arrays_consistent(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    ch = img.channel_arrays
    assert set(ch.keys()) == {"R", "G", "B"}
    for plane in ch.values():
        assert plane.shape == (256, 256)
