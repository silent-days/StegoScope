"""Pytest configuration and shared fixtures for StegoScope tests."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Make the stegoscope package importable when pytest runs from the
# project root (no install required).
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tests.helpers.make_samples import generate_sample_suite  # noqa: E402


@pytest.fixture(scope="session")
def sample_dir(tmp_path_factory) -> Path:
    """A session-scoped directory containing the controlled sample suite."""

    d = tmp_path_factory.mktemp("stegoscope_samples")
    generate_sample_suite(d)
    return d


@pytest.fixture(scope="session")
def samples(sample_dir) -> dict:
    """The full sample suite as a dict of logical-name -> Path/payload."""

    return generate_sample_suite(sample_dir)
