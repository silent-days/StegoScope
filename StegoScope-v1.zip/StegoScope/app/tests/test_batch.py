"""Tests for the batch scanner."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from stegoscope.core.batch import (batch_to_csv, batch_to_json,
                                    save_batch_results, scan_directory)


def test_scan_directory_returns_ranked_results(samples):
    results = scan_directory(samples["embedded_full"].parent)
    assert len(results) > 0
    # ranked by score descending
    scores = [r.score for r in results]
    assert scores == sorted(scores, reverse=True)


def test_scan_directory_handles_corrupt_and_unsupported(samples):
    results = scan_directory(samples["embedded_full"].parent)
    verdicts = {r.filename: r.verdict for r in results}
    # A corrupt PNG (right extension, bad content) is reported as ERROR.
    assert verdicts.get("corrupted.png") == "ERROR"
    # A JPEG is simply skipped — the batch scanner only collects PNG/BMP
    # by extension, so it never appears in the results at all.
    assert "unsupported.jpg" not in verdicts


def test_batch_to_csv_and_json_roundtrip(samples, tmp_path):
    results = scan_directory(samples["embedded_full"].parent)
    written = save_batch_results(results, tmp_path / "batch")
    assert Path(written["csv"]).exists()
    assert Path(written["json"]).exists()

    csv_text = batch_to_csv(results)
    reader = list(csv.reader(csv_text.splitlines()))
    assert any("filename" in row for row in reader)

    json_text = batch_to_json(results)
    data = json.loads(json_text)
    assert isinstance(data, list)
    assert len(data) == len(results)


def test_scan_recursive(samples, tmp_path):
    # Build a nested directory with one clean and one embedded image.
    sub = tmp_path / "sub"
    sub.mkdir()
    import shutil
    shutil.copy(samples["clean_rgb"], tmp_path / "top.png")
    shutil.copy(samples["embedded_full"], sub / "deep.png")
    flat = scan_directory(tmp_path, recursive=False)
    deep = scan_directory(tmp_path, recursive=True)
    assert len(flat) == 1
    assert len(deep) == 2


def test_scan_directory_rejects_nonexistent(tmp_path):
    import pytest
    with pytest.raises(FileNotFoundError):
        scan_directory(tmp_path / "nope")
