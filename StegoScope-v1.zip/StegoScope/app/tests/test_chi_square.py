"""Tests for the Chi-Square (Westfeld-Pfitzmann) detector."""

from __future__ import annotations

import pytest

from stegoscope.core.image_loader import ImageLoader
from stegoscope.analysis.chi_square import run_chi_square


def test_chi_returns_one_per_channel(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_chi_square(img)
    assert len(res.channels) == 3
    for c in res.channels:
        assert 0.0 <= c.embedding_probability <= 1.0
        assert 0.0 <= c.p_value <= 1.0
        assert c.dof >= 0
        assert c.statistic >= 0.0


def test_embedded_has_higher_chi_than_clean(samples):
    """Random LSB embedding balances value pairs, raising the p-value
    (embedding probability) relative to a structured clean image."""
    clean = run_chi_square(ImageLoader().load(samples["clean_rgb"]))
    embedded = run_chi_square(ImageLoader().load(samples["embedded_full"]))
    assert embedded.max_embedding_probability > clean.max_embedding_probability
    # The embedded image's best channel should be meaningfully elevated.
    assert embedded.max_embedding_probability > 0.1


def test_chi_max_probability_consistent(samples):
    img = ImageLoader().load(samples["embedded_text"])
    res = run_chi_square(img)
    per_channel = [c.embedding_probability for c in res.channels]
    assert abs(res.max_embedding_probability - max(per_channel)) < 1e-6


def test_chi_direction_is_correct(samples):
    """Embedding probability must RISE under embedding, not fall.

    Regression guard for the formula direction: the p-value of the
    goodness-of-fit test against balanced pairs IS the embedding
    probability, so embedding (which balances pairs) raises it.
    """
    clean = run_chi_square(ImageLoader().load(samples["clean_gray"]))
    emb = run_chi_square(ImageLoader().load(samples["embedded_gray"]))
    assert emb.max_embedding_probability >= clean.max_embedding_probability
