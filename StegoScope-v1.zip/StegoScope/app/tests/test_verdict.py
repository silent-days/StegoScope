"""Tests for the verdict engine — detection accuracy against ground truth."""

from __future__ import annotations

import pytest

from stegoscope import analyze_image


CLEAN_KEYS = ["clean_rgb", "clean_rgba", "clean_gray", "clean_bmp"]
EMBEDDED_KEYS = ["embedded_full", "embedded_half", "embedded_rgba",
                 "embedded_gray", "embedded_small", "embedded_text"]


def test_analyze_image_returns_full_report(samples):
    rep = analyze_image(samples["clean_rgb"], extract=False)
    assert rep.info.filename == "clean_rgb.png"
    assert rep.app_name == "StegoScope"
    assert rep.verdict.score is not None
    assert rep.verdict.verdict in ("CLEAN", "SUSPICIOUS", "LIKELY HIDDEN DATA")
    assert rep.lsb.channels and rep.chi.channels and rep.rs.channels
    assert rep.limitations  # always non-empty


@pytest.mark.parametrize("key", CLEAN_KEYS)
def test_clean_images_not_likely_hidden(samples, key):
    """No clean image may be classified LIKELY HIDDEN DATA.

    A SUSPICIOUS verdict on a clean image is tolerable (and documented
    as possible on synthetic imagery) but LIKELY HIDDEN DATA is a
    strong claim we must not make about a clean image.
    """
    rep = analyze_image(samples[key])
    assert rep.verdict.verdict != "LIKELY HIDDEN DATA", (
        f"false positive: clean image {key} scored {rep.verdict.score}")


@pytest.mark.parametrize("key", EMBEDDED_KEYS)
def test_embedded_images_are_flagged(samples, key):
    """Every embedded image must be flagged at least SUSPICIOUS."""
    rep = analyze_image(samples[key])
    assert rep.verdict.verdict in ("SUSPICIOUS", "LIKELY HIDDEN DATA"), (
        f"false negative: embedded image {key} scored "
        f"{rep.verdict.score} ({rep.verdict.verdict})")


def test_full_embedded_is_likely_hidden(samples):
    """A fully random-embedded RGB image is the strongest signal and
    must reach the LIKELY HIDDEN DATA band."""
    rep = analyze_image(samples["embedded_full"])
    assert rep.verdict.verdict == "LIKELY HIDDEN DATA"
    assert rep.verdict.score >= 70


def test_verdict_channels_match_image(samples):
    rep = analyze_image(samples["clean_rgba"])
    assert set(rep.info.channels) == {"R", "G", "B", "A"}
    findings = {f.channel for f in rep.verdict.channel_findings}
    assert findings == set(rep.info.channels)


def test_verdict_reasons_are_nonempty_when_suspicious(samples):
    rep = analyze_image(samples["embedded_full"])
    assert rep.verdict.reasons, "expected detection reasons for embedded image"


def test_thresholds_in_report(samples):
    rep = analyze_image(samples["clean_rgb"])
    t = rep.verdict.thresholds
    assert t["clean_max"] == 40
    assert t["suspicious_max"] == 70
    assert abs(t["weight_lsb"] + t["weight_chi"] + t["weight_rs"] - 1.0) < 1e-6


def test_no_hardcoded_results(samples):
    """The same image analysed twice must yield identical scores —
    i.e. the engine is deterministic, not randomised or hardcoded."""
    r1 = analyze_image(samples["embedded_text"]).verdict.score
    r2 = analyze_image(samples["embedded_text"]).verdict.score
    assert r1 == r2


def test_false_positive_rate_within_tolerance(samples):
    """Across the controlled suite, no more than 25% of clean images
    may be SUSPICIOUS (we tolerate synthetic-image noise)."""
    flagged = 0
    for key in CLEAN_KEYS:
        rep = analyze_image(samples[key])
        if rep.verdict.verdict != "CLEAN":
            flagged += 1
    rate = flagged / len(CLEAN_KEYS)
    assert rate <= 0.25, f"false-positive rate {rate:.0%} exceeds tolerance"


def test_detection_rate_within_tolerance(samples):
    """At least 70% of embedded images must be flagged SUSPICIOUS or
    higher (small / partial payloads are inherently harder)."""
    flagged = sum(
        1 for key in EMBEDDED_KEYS
        if analyze_image(samples[key]).verdict.verdict in
        ("SUSPICIOUS", "LIKELY HIDDEN DATA")
    )
    rate = flagged / len(EMBEDDED_KEYS)
    assert rate >= 0.70, f"detection rate {rate:.0%} below tolerance"
