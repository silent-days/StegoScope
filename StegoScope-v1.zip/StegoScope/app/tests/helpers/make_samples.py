"""Generate controlled laboratory test images for StegoScope.

This module is **test infrastructure only** — it is never shipped as a
user-facing feature.  It produces PNG/BMP images with known ground
truth so the test suite can verify the detector against:

* clean natural-ish imagery (gradient + perceptual noise),
* images with a known LSB-replacement payload of a given size,
* different colour modes (RGB, RGBA, grayscale),
* a deliberately corrupted file,
* a deliberately unsupported (lossy) format.

The embedding is naive LSB replacement, exactly the attack the
Chi-Square and RS detectors are designed to catch, so a correct
detector should flag the embedded samples and pass the clean ones
(within the documented false-positive / false-negative tolerances).
"""

from __future__ import annotations

import os
import struct
from pathlib import Path

import numpy as np
from PIL import Image


def _natural_image(width: int, height: int, mode: str,
                   seed: int) -> np.ndarray:
    """Build a synthetic but natural-ish image.

    A smooth horizontal+vertical gradient is combined with low-amplitude
    perceptual noise so the LSB plane has realistic structure (not flat,
    not perfectly random).
    """

    rng = np.random.default_rng(seed)
    xs = np.linspace(0, 255, width, dtype=np.float32)
    ys = np.linspace(0, 255, height, dtype=np.float32)
    base = (xs[None, :] + ys[:, None]) / 2.0
    # Add gentle noise — amplitude ~8 so LSBs are not trivially flat.
    noise = rng.normal(0, 8, size=(height, width)).astype(np.float32)
    grey = np.clip(base + noise, 0, 255).astype(np.uint8)

    if mode in ("L",):
        return grey
    if mode in ("LA",):
        alpha = np.full((height, width), 255, dtype=np.uint8)
        return np.stack([grey, alpha], axis=-1)
    if mode in ("RGB",):
        r = np.clip(grey.astype(np.int16) + rng.normal(0, 6, grey.shape), 0, 255).astype(np.uint8)
        g = np.clip(grey.astype(np.int16) + rng.normal(0, 6, grey.shape), 0, 255).astype(np.uint8)
        b = np.clip(grey.astype(np.int16) + rng.normal(0, 6, grey.shape), 0, 255).astype(np.uint8)
        return np.stack([r, g, b], axis=-1)
    if mode in ("RGBA",):
        rgb = _natural_image(width, height, "RGB", seed)
        alpha = np.full((height, width), 255, dtype=np.uint8)
        return np.concatenate([rgb, alpha[..., None]], axis=-1)
    raise ValueError(f"unsupported mode {mode}")


def embed_lsb_payload(image: np.ndarray, payload: bytes,
                      *, channels: tuple[int, ...] | None = None,
                      fill: bool = True) -> np.ndarray:
    """Naive LSB-replacement embedding.

    The payload bytes are written, MSB-first, into the LSBs of the
    specified channels in order.  If ``fill`` is True and the payload is
    shorter than the available capacity, the *remaining* LSBs are filled
    with random data so the embedded region looks like a full random
    payload — the worst case for the cover image and the best case for
    the detector.
    """

    out = image.copy()
    was_2d = out.ndim == 2
    if was_2d:
        out = out[:, :, None]
    n_channels = out.shape[2]
    if channels is None:
        channels = tuple(range(n_channels))
    rng = np.random.default_rng(0xC0FFEE)

    # Payload bit stream, MSB-first (matches the extractor's bitorder="big").
    payload_bits = np.unpackbits(
        np.frombuffer(payload, dtype=np.uint8), bitorder="big"
    )
    bits_needed = payload_bits.size
    capacity = out.shape[0] * out.shape[1] * len(channels)
    if bits_needed > capacity:
        raise ValueError(
            f"payload ({bits_needed} bits) larger than channel capacity "
            f"({capacity} bits)"
        )

    # Walk the chosen channels in order, row-major.  Payload bits are
    # written into the first ``bits_needed`` LSBs; the remaining LSBs of
    # every touched channel are either random-filled (``fill=True``) or
    # LEFT AT THEIR ORIGINAL COVER VALUES (``fill=False``).  The previous
    # implementation zeroed the remainder, which destroyed the cover's LSB
    # structure and produced malformed test samples.
    idx = 0
    for ch in channels:
        plane = out[:, :, ch]
        flat = plane.reshape(-1)
        cap = flat.size
        take = min(cap, bits_needed - idx)        # payload bits here
        if take > 0:
            flat[:take] = (flat[:take] & 0xFE) | payload_bits[idx:idx + take]
            idx += take
        remaining = cap - take
        if remaining > 0 and fill:
            fill_bits = rng.integers(0, 2, size=remaining, dtype=np.uint8)
            flat[take:] = (flat[take:] & 0xFE) | fill_bits
        # fill=False: leave the cover LSBs untouched.
    if was_2d:
        out = out[:, :, 0]
    return out


# --------------------------------------------------------------------- #
# High-level sample factory
# --------------------------------------------------------------------- #
def make_clean_sample(path: str | Path, *,
                      width: int = 256, height: int = 256,
                      mode: str = "RGB", seed: int = 1,
                      fmt: str = "PNG") -> Path:
    arr = _natural_image(width, height, mode, seed)
    Image.fromarray(arr).save(path, format=fmt)
    return Path(path)


def make_embedded_sample(path: str | Path, *,
                         payload: bytes | None = None,
                         payload_len: int = 0,
                         embed_ratio: float = 0.5,
                         width: int = 256, height: int = 256,
                         mode: str = "RGB", seed: int = 1,
                         fmt: str = "PNG") -> tuple[Path, bytes]:
    """Create a sample with a known LSB payload.

    Either supply ``payload`` explicitly, or ``payload_len`` to embed a
    random payload of that many bytes.  ``embed_ratio`` controls how
    much of the channel capacity is filled with random data after the
    payload (0..1).
    """

    if payload is None:
        if payload_len <= 0:
            raise ValueError("supply payload or payload_len")
        rng = np.random.default_rng(seed + 99)
        payload = rng.bytes(payload_len)

    arr = _natural_image(width, height, mode, seed)
    if embed_ratio >= 1.0:
        # Full random fill: the strongest detector signal.
        arr = embed_lsb_payload(arr, payload, fill=True)
    else:
        # Partial fill: embed payload only, leave the rest of the LSBs
        # at their natural values.
        arr = embed_lsb_payload(arr, payload, fill=False)
    Image.fromarray(arr).save(path, format=fmt)
    return Path(path), payload


def make_corrupted_png(path: str | Path) -> Path:
    """Write a file that looks like a PNG header but is truncated/corrupt."""

    p = Path(path)
    # Valid PNG signature + a mangled IHDR chunk that Pillow will reject.
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr_len = struct.pack(">I", 13)
    ihdr_type = b"IHDR"
    ihdr_data = b"\x00\x00\x01\x00\x00\x00\x01\x00\x08\x02\x00\x00\x00"
    ihdr_crc = struct.pack(">I", 0xDEADBEEF)  # wrong CRC
    p.write_bytes(sig + ihdr_len + ihdr_type + ihdr_data + ihdr_crc + b"\x00\x00")
    return p


def make_unsupported_jpeg(path: str | Path) -> Path:
    """Write a tiny valid JPEG so the loader rejects it by format."""

    # Minimal valid JPEG (1x1, grayscale) — bytes courtesy of the JPEG spec.
    jpeg = bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1, 0xF0, 0x24, 0x33, 0x62, 0x72,
        0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7B, 0x40,
        0x1B, 0xFF, 0xD9,
    ])
    Path(path).write_bytes(jpeg)
    return Path(path)


def generate_sample_suite(target_dir: str | Path) -> dict[str, Path]:
    """Generate the full controlled sample set into *target_dir*.

    Returns a dict mapping a logical name to the file path.  Used by the
    test suite and by ``stegoscope-make-samples`` for manual inspection.
    """

    d = Path(target_dir)
    d.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}

    paths["clean_rgb"] = make_clean_sample(d / "clean_rgb.png",
                                           mode="RGB", seed=1)
    paths["clean_rgba"] = make_clean_sample(d / "clean_rgba.png",
                                            mode="RGBA", seed=2)
    paths["clean_gray"] = make_clean_sample(d / "clean_gray.png",
                                            mode="L", seed=3)
    paths["clean_bmp"] = make_clean_sample(d / "clean.bmp",
                                           mode="RGB", seed=4, fmt="BMP")

    paths["embedded_full"], _ = make_embedded_sample(
        d / "embedded_full.png", payload_len=8192,
        embed_ratio=1.0, mode="RGB", seed=10)
    paths["embedded_half"], _ = make_embedded_sample(
        d / "embedded_half.png", payload_len=2048,
        embed_ratio=1.0, mode="RGB", seed=11)
    paths["embedded_rgba"], _ = make_embedded_sample(
        d / "embedded_rgba.png", payload_len=4096,
        embed_ratio=1.0, mode="RGBA", seed=12)
    paths["embedded_gray"], _ = make_embedded_sample(
        d / "embedded_gray.png", payload_len=2048,
        embed_ratio=1.0, mode="L", seed=13)
    paths["embedded_small"], _ = make_embedded_sample(
        d / "embedded_small.png", payload_len=64,
        embed_ratio=1.0, mode="RGB", seed=14)
    paths["embedded_text"], text_payload = make_embedded_sample(
        d / "embedded_text.png",
        payload=b"STEGOSCOPE-FORENSIC-MARKER-"
                b"This is a known plaintext payload used to verify the "
                b"candidate extraction pipeline end-to-end.",
        embed_ratio=1.0, mode="RGB", seed=15)
    paths["embedded_text_payload"] = text_payload  # type: ignore[assignment]

    paths["corrupted"] = make_corrupted_png(d / "corrupted.png")
    paths["jpeg"] = make_unsupported_jpeg(d / "unsupported.jpg")
    return paths


if __name__ == "__main__":  # pragma: no cover
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "samples"
    suite = generate_sample_suite(out)
    for name, p in suite.items():
        if isinstance(p, Path):
            print(f"{name:18s} -> {p}")
