"""Tests for the image cleaner module."""
from __future__ import annotations

import pytest
from pathlib import Path

from stegoscope.core.cleaner import clean_image
from stegoscope.core.verdict import analyze_image


def test_clean_drops_score_significantly(samples, tmp_path):
    """Regression test: cleaning must actually lower the risk score.

    Previously the LSB-neutralise checkbox was default-OFF and the
    channel checkboxes were default-UNCHECKED, so the cleaner would
    silently run with no operation enabled (or fail validation) and
    the re-analyzed score would be unchanged. This test guards against
    that regression: when strip_metadata + neutralise_lsb are both
    explicitly enabled, the score must drop substantially.
    """
    src = samples["embedded_text"]
    out = tmp_path / "regression.png"

    before = analyze_image(src)
    assert before.verdict.score > 40, \
        f"Test setup error: source score {before.verdict.score} should be > 40"

    res = clean_image(src, out, strip_metadata=True, neutralise_lsb=True)
    assert res.success, f"clean failed: {res.error}"

    after = analyze_image(out)
    assert after.verdict.score < before.verdict.score, \
        f"Score did not drop: before={before.verdict.score}, " \
        f"after={after.verdict.score}"
    assert after.verdict.verdict == "CLEAN", \
        f"After-clean verdict should be CLEAN, got {after.verdict.verdict}"


def test_clean_strips_metadata_only(samples, tmp_path):
    """Strip metadata, keep the pixel stream — output should be valid PNG
    and the visible image should be unchanged (dimensions, mode)."""
    src = samples["clean_rgb"]
    out = tmp_path / "cleaned.png"

    res = clean_image(src, out, strip_metadata=True, neutralise_lsb=False)

    assert res.success, f"clean failed: {res.error}"
    assert Path(out).exists()
    assert res.output_format == "PNG"
    assert res.input_format == "PNG"
    # Strip metadata should report the chunks it removed
    assert "tEXt" in res.metadata_chunks_removed
    assert "exif" in res.metadata_chunks_removed
    # LSB neutralisation should be off
    assert res.lsb_neutralised is False
    assert res.bits_cleared == 0


def test_clean_neutralises_lsb(samples, tmp_path):
    """Neutralise LSB on an embedded image — the cleaned image should
    re-analyze as CLEAN (or much lower score)."""
    src = samples["embedded_text"]
    out = tmp_path / "neut_lsb.png"

    # First analyze the original — should be SUSPICIOUS or LIKELY.
    before = analyze_image(src)
    assert before.verdict.score > 40, \
        f"Test setup error: source should be >40, got {before.verdict.score}"

    res = clean_image(src, out, strip_metadata=False, neutralise_lsb=True)

    assert res.success, f"clean failed: {res.error}"
    assert res.lsb_neutralised is True
    assert "R" in res.channels_neutralised
    assert "G" in res.channels_neutralised
    assert "B" in res.channels_neutralised
    assert res.bits_cleared > 0

    # Re-analyze the cleaned image — score should drop significantly.
    after = analyze_image(out)
    assert after.verdict.score < before.verdict.score, \
        f"Score did not drop: before={before.verdict.score}, " \
        f"after={after.verdict.score}"


def test_clean_full_pipeline(samples, tmp_path):
    """Both strip metadata + neutralise LSB — output should re-analyze
    as CLEAN and the output file should be smaller (no metadata chunks)."""
    src = samples["embedded_text"]
    out = tmp_path / "fully_clean.png"

    res = clean_image(src, out, strip_metadata=True, neutralise_lsb=True)

    assert res.success, f"clean failed: {res.error}"
    assert res.lsb_neutralised is True
    assert len(res.metadata_chunks_removed) > 0
    assert res.bits_cleared > 0

    # Output should be valid PNG.
    from PIL import Image
    with Image.open(out) as img:
        assert img.format == "PNG"
        # Dimensions preserved.
        with Image.open(src) as src_img:
            assert img.size == src_img.size

    # Re-analyze — should be CLEAN now.
    after = analyze_image(out)
    assert after.verdict.verdict == "CLEAN", \
        f"After-clean verdict should be CLEAN, got {after.verdict.verdict} " \
        f"(score {after.verdict.score})"


def test_clean_no_source_returns_failure(tmp_path):
    """A missing source file should produce a failed result, not raise."""
    src = tmp_path / "does_not_exist.png"
    out = tmp_path / "out.png"
    res = clean_image(src, out)
    assert not res.success
    assert res.error is not None
    assert "not found" in res.error.lower()


def test_clean_idempotent(samples, tmp_path):
    """Cleaning an already-clean image should clear ~0 bits (idempotent)."""
    src = samples["clean_rgb"]
    out1 = tmp_path / "first.png"
    out2 = tmp_path / "second.png"

    # First clean — neutralise LSB on the (already clean) source.
    res1 = clean_image(src, out1, strip_metadata=True, neutralise_lsb=True)
    assert res1.success
    bits_first = res1.bits_cleared

    # Second clean — run on the already-cleaned output.
    res2 = clean_image(out1, out2, strip_metadata=True, neutralise_lsb=True)
    assert res2.success
    bits_second = res2.bits_cleared

    # The second clean should clear very few bits (the LSBs were already 0).
    assert bits_second <= bits_first, \
        f"Second clean should clear fewer bits; first={bits_first}, " \
        f"second={bits_second}"
