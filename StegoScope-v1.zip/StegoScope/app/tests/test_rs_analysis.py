"""Tests for RS-analysis."""

from __future__ import annotations

from stegoscope.core.image_loader import ImageLoader
from stegoscope.analysis.rs_analysis import run_rs_analysis


def test_rs_returns_one_per_channel(samples):
    img = ImageLoader().load(samples["clean_rgb"])
    res = run_rs_analysis(img)
    assert len(res.channels) == 3
    for c in res.channels:
        assert 0.0 <= c.rm <= 1.0
        assert 0.0 <= c.sm <= 1.0
        assert 0.0 <= c.r_negm <= 1.0
        assert 0.0 <= c.s_negm <= 1.0
        assert c.imbalance >= 0.0
        assert 0.0 <= c.estimated_rate <= 1.0
        assert c.total_groups > 0


def test_embedded_has_larger_imbalance_than_clean(samples):
    """LSB replacement breaks the R_M/S_M vs R_-M/S_-M symmetry, so the
    embedded image's max imbalance should exceed the clean baseline."""
    clean = run_rs_analysis(ImageLoader().load(samples["clean_rgb"]))
    embedded = run_rs_analysis(ImageLoader().load(samples["embedded_full"]))
    assert embedded.max_imbalance > clean.max_imbalance
    # And meaningfully so — not a marginal 1e-4 difference.
    assert embedded.max_imbalance > 0.05


def test_constant_channel_is_degenerate(tmp_path):
    """An all-opaque alpha plane must not produce a spurious imbalance."""
    import numpy as np
    from PIL import Image
    arr = np.full((64, 64, 4), 255, dtype=np.uint8)
    p = tmp_path / "const.png"
    Image.fromarray(arr).save(p)
    res = run_rs_analysis(ImageLoader().load(p))
    alpha = [c for c in res.channels if c.channel == "A"][0]
    assert alpha.imbalance == 0.0
    assert alpha.rate_valid is False


def test_rs_f1_does_not_overflow_boundary(tmp_path):
    """F-1 at value 255 must clamp into [0,255] (regression for the
    alpha-channel overflow that once produced imbalance > 1)."""
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(7)
    arr = rng.integers(250, 256, size=(64, 64, 3), dtype=np.uint8)
    p = tmp_path / "high.png"
    Image.fromarray(arr).save(p)
    res = run_rs_analysis(ImageLoader().load(p))
    for c in res.channels:
        assert c.imbalance <= 1.0
