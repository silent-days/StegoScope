"""Tests for report generation (TXT / JSON / CSV / PDF)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from stegoscope import analyze_image
from stegoscope.reporting import (REPORT_FORMATS, ReportFormatError,
                                   generate_pdf, save_report, to_csv,
                                   to_json, to_txt)


@pytest.fixture(scope="module")
def report(samples):
    return analyze_image(samples["embedded_text"], extract=True,
                         max_payload_bytes=4096)


def test_txt_report_has_sections(report):
    txt = to_txt(report)
    assert "STEGOSCOPE" in txt
    assert "FILE INFORMATION" in txt
    assert "LSB ANALYSIS" in txt
    assert "CHI-SQUARE ANALYSIS" in txt
    assert "RS ANALYSIS" in txt
    assert "VERDICT" in txt
    assert "PAYLOAD EXTRACTION" in txt
    assert "ANALYSIS LIMITATIONS" in txt
    assert report.info.filename in txt
    assert report.verdict.verdict in txt


def test_json_report_round_trips(report):
    data = json.loads(to_json(report))
    assert data["app_name"] == "StegoScope"
    assert data["info"]["filename"] == report.info.filename
    assert data["verdict"]["verdict"] == report.verdict.verdict
    assert isinstance(data["lsb"]["channels"], list)


def test_csv_report_has_summary_and_detail(report):
    csv_text = to_csv(report)
    rows = list(csv.reader(csv_text.splitlines()))
    # summary header + per-channel detail header
    joined = [" ".join(r) for r in rows]
    assert any("verdict" in r.lower() for r in joined)
    assert any("channel" in r.lower() and "lsb_mean" in r.lower() for r in joined)


def test_pdf_report_generates_file(report, tmp_path):
    out = generate_pdf(report, tmp_path / "report.pdf")
    assert out.exists()
    assert out.stat().st_size > 1000
    # PDF magic header
    assert out.read_bytes()[:4] == b"%PDF"


@pytest.mark.parametrize("fmt", REPORT_FORMATS)
def test_save_report_all_formats(report, tmp_path, fmt):
    out = save_report(report, tmp_path / f"report.{fmt}", fmt=fmt)
    assert out.exists()
    assert out.suffix.lstrip(".") == fmt
    assert out.stat().st_size > 0


def test_save_report_rejects_unknown_format(report, tmp_path):
    with pytest.raises(ReportFormatError):
        save_report(report, tmp_path / "report.xyz", fmt="xyz")


def test_save_report_infers_format_from_suffix(report, tmp_path):
    out = save_report(report, tmp_path / "inferred.json")
    assert out.suffix == ".json"
    json.loads(out.read_text())  # valid JSON


def test_report_payload_is_sanitised(report):
    """PDF/TXT must not carry raw non-printable bytes from the payload."""
    txt = to_txt(report)
    # No NUL or control chars (other than newline/tab) in the text body.
    for ch in txt:
        if ch not in "\n\t":
            assert ord(ch) >= 0x20, f"control char {ord(ch):#x} in report"
