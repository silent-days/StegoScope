#!/usr/bin/env bash
#
# StegoScope — Linux launcher
# Activates the project virtual environment and starts the GUI.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -d ".venv" ]; then
    echo "Virtual environment not found. Run ./install.sh first." >&2
    exit 1
fi

# shellcheck disable=SC1091
source .venv/bin/activate

# Pass any CLI arguments through to the dispatcher: if the first arg is a
# CLI subcommand (version/scan/batch) run the CLI, otherwise launch the GUI.
exec python main.py "$@"
