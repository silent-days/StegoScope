#!/usr/bin/env bash
#
# StegoScope — Linux installer (StegoScope)
# Creates a virtual environment, installs dependencies, installs the
# package as a normal wheel, and registers a desktop launcher.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PY="${PYTHON:-python3}"

echo "============================================================"
echo "  StegoScope : Linux installer"
echo "  Using interpreter: $PY  ($($PY --version 2>&1))"
echo "============================================================"

# ---- 1. sanity check --------------------------------------------------
if ! command -v "$PY" >/dev/null 2>&1; then
    echo "ERROR: '$PY' not found. Install Python 3.11+ and rerun." >&2
    exit 1
fi

PY_VERSION="$($PY -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
PY_MAJOR="${PY_VERSION%%.*}"
PY_MINOR="${PY_VERSION#*.}"
if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 11 ]; }; then
    echo "ERROR: Python 3.11+ required, found $PY_VERSION." >&2
    echo "       Install it from https://www.python.org/ or your distro." >&2
    exit 1
fi

# ---- 2. virtual environment ------------------------------------------
if [ ! -d ".venv" ]; then
    echo "[1/4] creating virtual environment (.venv) ..."
    if ! "$PY" -m venv .venv; then
        echo "ERROR: failed to create virtual environment." >&2
        echo "       On Debian/Ubuntu install: sudo apt install python3-venv" >&2
        exit 1
    fi
fi

# shellcheck disable=SC1091
source .venv/bin/activate

echo "[2/4] upgrading pip ..."
python -m pip install --upgrade pip --quiet

echo "[3/4] installing requirements ..."
if ! python -m pip install -r requirements.txt --quiet; then
    echo "ERROR: dependency installation failed." >&2
    echo "       Check your internet connection and rerun." >&2
    exit 1
fi

echo "[4/4] installing stegoscope ..."
if ! python -m pip install . --quiet; then
    echo "ERROR: package install failed." >&2
    exit 1
fi

# ---- 3. GUI system-library notice (Linux) ----------------------------
# PySide6 needs libEGL/libGL at runtime on Linux; they are not pip deps.
if ! ldconfig -p 2>/dev/null | grep -q "libEGL.so.1"; then
    echo ""
    echo "NOTE: The GUI needs system OpenGL libraries that are not installed."
    echo "      On Debian/Ubuntu/Kali:  sudo apt install libegl1 libgl1"
    echo "      On Fedora/RHEL:         sudo dnf install libglvnd-opengl"
    echo "      The CLI works without them:  .venv/bin/stegoscope version"
fi

# ---- 4. desktop launcher ---------------------------------------------
APP_DIR="${HOME}/.local/share/applications"
mkdir -p "$APP_DIR"
DESKTOP_FILE="$APP_DIR/StegoScope.desktop"
cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Name=StegoScope
Comment=StegoScope — Steganography detection suite
TryExec=${SCRIPT_DIR}/run.sh
Exec="${SCRIPT_DIR}/run.sh"
Icon=${SCRIPT_DIR}/assets/icons/stegoscope_logo.png
Terminal=false
Type=Application
Categories=Security;Utility;
EOF
chmod 644 "$DESKTOP_FILE"

echo ""
echo "============================================================"
echo "  Installation complete."
echo "  Launch the GUI with:    ./run.sh"
echo "  Run the CLI with:       .venv/bin/stegoscope version"
echo "  Run the test suite:     .venv/bin/python -m pytest tests/"
echo "  Desktop menu entry:     StegoScope"
echo "============================================================"
