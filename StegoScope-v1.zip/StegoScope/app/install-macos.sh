#!/usr/bin/env bash
# StegoScope — macOS installer
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "Python 3.11+ is required. Install it from python.org or Homebrew." >&2
  exit 1
fi
PYVER="$($PY -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
if ! "$PY" -m venv .venv 2>/dev/null; then
  echo "Could not create .venv. Install Python with venv support and retry." >&2
  exit 1
fi
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pip install .
cat > StegoScope.command <<EOF
#!/usr/bin/env bash
cd "$(dirname "$0")"
exec .venv/bin/stegoscope-gui
EOF
chmod +x StegoScope.command
printf '\nStegoScope installed for macOS (Python %s).\nLaunch with: ./StegoScope.command\n' "$PYVER"
