"""Chi-Square (Westfeld-Pfitzmann) statistical steganalysis.

The attack, due to Andreas Westfeld and Andreas Pfitzmann (1999/2000),
exploits a property of **LSB replacement** steganography: when an
embedded payload is random (encrypted / compressed), the histogram of
pixel values within each channel becomes *pair-wise balanced*.  That is,
for every adjacent value pair ``(2k, 2k+1)`` the two counts become
roughly equal, because LSB replacement only ever swaps a value between
its own pair.

We compute, per channel:

* the chi-square goodness-of-fit statistic over the pair-value histogram,
* the degrees of freedom (number of non-empty pairs − 1),
* the **p-value** of that goodness-of-fit test,
* the Westfeld-Pfitzmann **embedding probability** heuristic.

Statistical definitions
-----------------------
For every adjacent pair ``k = (2k, 2k+1)`` let ``n_even`` and ``n_odd``
be the observed counts and ``total = n_even + n_odd``.  Under the null
hypothesis ``H₀`` ("the pair histogram is balanced, as a full random
LSB-replacement payload would produce"), the expected count for each
member of the pair is ``total / 2``.  The chi-square statistic is ::

    χ² = Σ_k (n_even − n_odd)² / total_k          (over non-empty pairs)

which is the standard 2-category goodness-of-fit form
``Σ (observed − expected)² / expected`` simplified algebraically.  The
degrees of freedom are ``k* − 1`` where ``k*`` is the number of
non-empty pairs (empty cells are dropped, the standard practice).

The **p-value** is the upper-tail probability ::

    p = P(χ² ≥ χ²_observed | dof) = scipy.stats.chi2.sf(χ², dof)

* A **large** p-value (small χ²) means the pair histogram is consistent
  with the balanced-pairs null — i.e. consistent with random LSB
  embedding.  We *fail to reject* ``H₀``.
* A **small** p-value (large χ²) means the histogram deviates from
  balanced — i.e. the channel looks natural / clean.  We *reject* ``H₀``.

The **embedding probability** (``embedding_probability``) is the
Westfeld-Pfitzmann heuristic detection score.  Numerically it equals the
survival-function p-value above (this *is* the WP definition), and it is
read as "how consistent the channel is with random LSB embedding":
close to ``1.0`` → strongly consistent, close to ``0.0`` → not
consistent.

CRITICAL interpretation caveat
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**Neither the p-value nor the embedding probability is the probability
that the image actually contains hidden data.**  The p-value is a tail
probability under a specific null hypothesis; the embedding probability
is a heuristic detection score derived from it.  Both measure *histogram
consistency with random LSB replacement* and nothing more.  Steganalysis
is probabilistic — a high score is a statistical indicator, not a
confirmation, and a low score is not proof of absence.

Assumptions
-----------
* The payload is **random** (encrypted/compressed) LSB **replacement**,
  embedded **sequentially from the start** of the pixel stream.
* The chi-square approximation is reasonable when expected counts per
  cell are ≥ 5; sparse histograms (small images / few colours) violate
  this and are flagged via ``insufficient_sample``.
* Only the *contiguous region from the start* of the stream is tested in
  the classic attack; here we test the whole channel flattened row-major,
  which is the common practical variant.

Limitations
-----------
The Chi-Square attack is *blind* to:

* LSB **matching** (±1 steganography), which does not pair-balance,
* sequential payloads that start mid-image,
* payloads smaller than ~1 % of the image (insufficient sample),
* encrypted payloads embedded in only one channel (per-channel tests
  still catch the channel that carries them).

So a low Chi-Square score does **not** prove an image is clean.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats

from ..core.image_loader import ImageData


@dataclass
class ChannelChiSquareStats:
    channel: str
    statistic: float
    dof: int
    p_value: float
    embedding_probability: float
    sample_pairs: int
    """Number of value-pairs ``(2k, 2k+1)`` with a non-empty histogram."""
    insufficient_sample: bool
    """True when too few populated pairs exist for a reliable test."""


@dataclass
class ChiSquareResult:
    channels: list[ChannelChiSquareStats]
    max_embedding_probability: float


# Minimum populated pairs required for the chi-square approximation to be
# meaningful.  Below this the channel is flagged ``insufficient_sample``
# and the embedding probability is reported as 0 (no positive evidence)
# rather than a misleading 1.0.
_MIN_PAIRS = 2


def _channel_chi_square(name: str, plane: np.ndarray) -> ChannelChiSquareStats:
    flat = plane.reshape(-1).astype(np.int64)
    hist = np.bincount(flat, minlength=256)[:256].astype(np.float64)

    # Adjacent-value pairing: pair k uses histogram bins (2k, 2k+1).
    even = hist[0::2]
    odd = hist[1::2]
    pair_totals = even + odd
    nonzero = pair_totals > 0
    n_pairs = int(nonzero.sum())

    # Insufficient sample: not enough populated pairs to form a
    # distribution.  We report p_value = 1.0 (the test is inconclusive —
    # we cannot reject the balanced null) but embedding_probability = 0.0
    # (no *positive* evidence of embedding), and flag it so the verdict
    # engine and report do not over-interpret.
    if n_pairs < _MIN_PAIRS:
        return ChannelChiSquareStats(
            channel=name, statistic=0.0, dof=0, p_value=1.0,
            embedding_probability=0.0, sample_pairs=n_pairs,
            insufficient_sample=True,
        )

    obs_even = even[nonzero]
    obs_odd = odd[nonzero]
    totals = pair_totals[nonzero]

    # Chi-square statistic for the 2-category goodness-of-fit against the
    # "balanced pairs" null (expected = total/2 per cell).  The standard
    # form Σ (o−e)²/e simplifies, for a symmetric pair, to (even−odd)²/total.
    stat = float(np.sum((obs_even - obs_odd) ** 2 / totals))
    # Note: n_pairs >= _MIN_PAIRS (==2) is guaranteed by the early-return
    # above, so dof = n_pairs - 1 >= 1 is always positive here. The
    # previous `if dof <= 0` branch was unreachable dead code; removed.
    dof = n_pairs - 1

    # Goodness-of-fit p-value = upper tail under the balanced-pairs null.
    p_value = float(stats.chi2.sf(stat, dof))

    # Westfeld-Pfitzmann embedding-probability heuristic.  By definition
    # this equals the survival-function p-value: a large value means the
    # histogram is consistent with random LSB embedding.  It is a
    # *heuristic detection score*, NOT the probability of hidden data.
    embed_prob = float(max(0.0, min(1.0, p_value)))

    # Flag borderline samples: if any expected cell count is < 5 the
    # chi-square approximation is unreliable.  We still report a number
    # but mark it insufficient so downstream consumers can downgrade it.
    expected = totals / 2.0
    insufficient = bool(np.any(expected < 5.0)) or (n_pairs < _MIN_PAIRS)

    return ChannelChiSquareStats(
        channel=name,
        statistic=round(stat, 4),
        dof=dof,
        p_value=round(p_value, 6),
        embedding_probability=round(embed_prob, 6),
        sample_pairs=n_pairs,
        insufficient_sample=insufficient,
    )


def run_chi_square(image: ImageData) -> ChiSquareResult:
    """Run the Westfeld-Pfitzmann Chi-Square attack on every channel."""

    channels = image.channel_arrays
    stats_list = [_channel_chi_square(name, plane)
                  for name, plane in channels.items()]
    # Only genuine (non-insufficient) probabilities count toward the max.
    max_prob = max(
        (s.embedding_probability for s in stats_list
         if not s.insufficient_sample),
        default=0.0,
    )
    return ChiSquareResult(channels=stats_list,
                           max_embedding_probability=round(max_prob, 6))
