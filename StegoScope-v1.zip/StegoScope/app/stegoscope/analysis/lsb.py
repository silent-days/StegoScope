"""Least-Significant-Bit plane analysis.

For every colour channel we extract the LSB plane (``pixel & 1``) and
compute a small set of statistics that are useful as steganalysis
features:

* the fraction of 0-bits and 1-bits,
* the mean LSB value (0.5 == perfectly balanced),
* the longest run of equal bits in row-major order,
* the per-channel imbalance relative to the other channels.

A perfectly random LSB stream (e.g. encrypted/compressed payload) has a
mean of ~0.5 and a longest run of ~log2(N).  Natural imagery has a
structured LSB plane whose mean wanders away from 0.5 — so an LSB mean
that is *suspiciously close* to 0.5 is a (weak) stego indicator.  LSB
balance alone is **not** conclusive; the verdict engine combines it with
the Chi-Square and RS detectors.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.image_loader import ImageData


@dataclass
class ChannelLSBStats:
    channel: str
    zero_count: int
    one_count: int
    total_bits: int
    zero_pct: float
    one_pct: float
    lsb_mean: float
    longest_run: int
    longest_run_value: int  # which bit (0 or 1) the longest run consists of


@dataclass
class LSBResult:
    channels: list[ChannelLSBStats]
    channel_imbalance: float
    """max(lsb_mean) - min(lsb_mean) across channels; 0 for single-channel."""


def _longest_equal_run(bits: np.ndarray) -> tuple[int, int]:
    """Return (length, value) of the longest run of equal bits.

    Implemented without a Python-level loop over every bit: we use
    ``np.diff`` to find the change points and measure the gaps between
    them, which is O(n) and vectorised.
    """

    flat = bits.reshape(-1).astype(np.int8)
    if flat.size == 0:
        return 0, 0
    # Positions where the value changes.
    change = np.flatnonzero(np.diff(flat)) + 1
    # Boundaries: 0, change..., len
    bounds = np.concatenate(([0], change, [flat.size]))
    lengths = np.diff(bounds)
    idx = int(np.argmax(lengths))
    longest = int(lengths[idx])
    value = int(flat[bounds[idx]])
    return longest, value


def _channel_stats(name: str, plane: np.ndarray) -> ChannelLSBStats:
    bits = (plane & 1).astype(np.uint8)
    total = int(bits.size)
    ones = int(bits.sum())
    zeros = total - ones
    mean = ones / total if total else 0.0
    longest, value = _longest_equal_run(bits)
    return ChannelLSBStats(
        channel=name,
        zero_count=zeros,
        one_count=ones,
        total_bits=total,
        zero_pct=round(zeros / total * 100, 4) if total else 0.0,
        one_pct=round(ones / total * 100, 4) if total else 0.0,
        lsb_mean=round(mean, 6),
        longest_run=longest,
        longest_run_value=value,
    )


def run_lsb_analysis(image: ImageData) -> LSBResult:
    """Run LSB-plane analysis on every channel of *image*."""

    channels = image.channel_arrays
    stats = [_channel_stats(name, plane) for name, plane in channels.items()]
    means = [s.lsb_mean for s in stats]
    imbalance = round(max(means) - min(means), 6) if len(means) > 1 else 0.0
    return LSBResult(channels=stats, channel_imbalance=imbalance)
