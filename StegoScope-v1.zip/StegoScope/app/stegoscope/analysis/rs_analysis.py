"""RS-Analysis (Fridrich, Goljan & Du, 2001).

RS-analysis is a structural steganalytic attack that detects LSB
replacement by measuring how the *smoothness* of pixel groups changes
under two complementary bit-flipping operations.

Algorithm (per channel)
-----------------------
1. Flatten the channel row-major and partition it into non-overlapping
   groups of ``group_size`` pixels (default 4).
2. Define a discrimination function ``f`` = sum of absolute consecutive
   differences within a group (a smoothness measure).
3. Define two flipping operations:

   * ``F1``  (the *positive* mask ``M`` partner): ``x -> x XOR 1`` —
     flips the LSB, swapping 0<->1, 2<->3, ...
   * ``F-1`` (the *negative* mask ``-M`` partner): ``x -> ((x+1) XOR 1) - 1``
     which swaps -1<->0, 1<->2, 3<->4, ...  Values that would go
     negative are clamped to 0.

4. For a mask ``M = (0, 1, 1, 1)`` apply ``F1`` to the last three
   positions of each group; classify each group as:

   * **Regular** (R): smoothness *increases* after flipping,
   * **Singular** (S): smoothness *decreases*,
   * **Unusable** (U): unchanged.

   Repeat with ``-M = (0, -1, -1, -1)`` using ``F-1`` to obtain
   ``R_-M`` and ``S_-M``.

5. The four fractions ``R_M, S_M, R_-M, S_-M`` characterise the image.
   For a clean natural image the two masks give *similar* imbalances
   (``R_M - S_M`` ≈ ``R_-M - S_-M``); LSB replacement breaks this
   symmetry, so the divergence is the detection signal.

Embedding-rate estimate
-----------------------
We additionally simulate "fully embedded" by applying ``F1`` to every
pixel and re-measuring under mask ``M`` to obtain ``R'_M, S'_M``.  The
three observed imbalances ``(d0, d_-1, d1)`` define a parabola whose
non-trivial root is the classic RS estimate of the embedding rate::

    a = 2*(d0 + d1 - 2*d_-1)
    b = (d_-1 - d1)            # see derivation in docs/DETECTION_METHODOLOGY.md
    c = (d0 - d_-1)
    root = (-b - sqrt(b^2 - 4ac)) / (2a)   # smaller root, when real

The estimate is clamped to ``[0, 1]`` and reported alongside the
imbalance.  Out-of-range or degenerate results are reported as ``0.0``
with a flag.

Limitations
-----------
* Assumes **random, sequential LSB replacement** — misses LSB matching
  and adaptive steganography.
* Sensitive to image content (synthetic / flat images give noisy
  estimates).
* The embedding-rate quadratic is an approximation and frequently
  produces meaningless values on natural images; treat the
  ``imbalance`` as the primary signal and the ``estimated_rate`` as a
  secondary, indicative number only.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.image_loader import ImageData

_GROUP_SIZE = 4
_MASK = np.array([0, 1, 1, 1], dtype=np.int8)     # positive mask M
_NEG_MASK = np.array([0, -1, -1, -1], dtype=np.int8)  # negative mask -M


@dataclass
class ChannelRSStats:
    channel: str
    rm: float
    sm: float
    r_negm: float
    s_negm: float
    d0: float             # R_M - S_M
    d_neg1: float          # R_-M - S_-M
    imbalance: float       # |d0 - d_neg1|
    estimated_rate: float  # RS quadratic root, clamped to [0, 1]
    rate_valid: bool       # False when the quadratic was degenerate
    total_groups: int
    channel_pixels: int
    """Number of pixels in this channel (the LSB capacity basis)."""
    estimated_payload_bytes: int
    """Approximate embedded bytes in this channel =
    ``round(rate * channel_pixels / 8)`` when ``rate_valid``, else 0."""


@dataclass
class RSResult:
    channels: list[ChannelRSStats]
    max_imbalance: float
    max_estimated_rate: float
    """Highest valid per-channel embedding rate (0 if none valid)."""
    estimated_payload_bytes: int
    """Approximate total embedded payload length in bytes, summed over the
    channels with a valid RS rate.  An *indicative* number only — see the
    module docstring's limitations."""


# --------------------------------------------------------------------- #
def _flatten_groups(plane: np.ndarray, group_size: int) -> np.ndarray:
    """Reshape a 2-D channel into an ``(n_groups, group_size)`` array,
    dropping the trailing pixels that do not fill a complete group."""

    flat = plane.reshape(-1).astype(np.int16)
    n_groups = flat.size // group_size
    flat = flat[: n_groups * group_size]
    return flat.reshape(n_groups, group_size)


def _discrimination(groups: np.ndarray) -> np.ndarray:
    """f(x1..xn) = sum |x_{i+1} - x_i|, per group."""

    return np.abs(np.diff(groups, axis=1)).sum(axis=1)


def _apply_f1(groups: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply F1 (XOR 1) only where mask != 0."""

    flipped = groups.copy()
    sel = mask != 0
    flipped[:, sel] = groups[:, sel] ^ 1
    return flipped


def _apply_f_neg1(groups: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply F-1 = ((x+1) XOR 1) - 1, clamped to the valid [0, 255] range.

    Implemented vectorised: only positions where mask != 0 are altered.
    The boundary values map as -1 -> 0 and 256 -> 255 (the standard
    boundary handling used in RS implementations).
    """

    flipped = groups.copy()
    sel = mask != 0
    sub = groups[:, sel]
    transformed = ((sub + 1) ^ 1) - 1
    # Clamp both boundaries into the valid pixel range.
    transformed = np.clip(transformed, 0, 255)
    flipped[:, sel] = transformed
    return flipped


def _classify(f_orig: np.ndarray, f_flipped: np.ndarray) -> tuple[float, float, int]:
    """Return (R, S, total) fractions for one mask direction."""

    total = f_orig.size
    if total == 0:
        return 0.0, 0.0, 0
    diff = f_flipped.astype(np.int32) - f_orig.astype(np.int32)
    regular = int(np.count_nonzero(diff > 0))
    singular = int(np.count_nonzero(diff < 0))
    return regular / total, singular / total, total


def _estimate_rate(d0: float, d_neg1: float, d1: float) -> tuple[float, bool]:
    """Solve the RS quadratic for the embedding rate.

    Returns (rate, valid).  ``valid`` is False when the leading
    coefficient is ~0 (degenerate) or the discriminant is negative,
    in which case ``rate`` is 0.0.
    """

    a = 2.0 * (d0 + d1 - 2.0 * d_neg1)
    b = d_neg1 - d1
    c = d0 - d_neg1
    if abs(a) < 1e-12:
        # Linear or constant; degenerate.
        return 0.0, False
    disc = b * b - 4.0 * a * c
    if disc < 0:
        return 0.0, False
    sqrt_disc = float(np.sqrt(disc))
    root1 = (-b + sqrt_disc) / (2.0 * a)
    root2 = (-b - sqrt_disc) / (2.0 * a)
    # Pick the root in [0, 1]; prefer the smaller valid one.
    candidates = [r for r in (root1, root2) if 0.0 <= r <= 1.0]
    if not candidates:
        # No physical root — natural-image noise. Report 0, flag invalid.
        return 0.0, False
    return float(min(candidates)), True


def _channel_rs(name: str, plane: np.ndarray) -> ChannelRSStats:
    groups = _flatten_groups(plane, _GROUP_SIZE)
    channel_pixels = int(plane.size)
    if groups.shape[0] == 0:
        return ChannelRSStats(
            channel=name, rm=0.0, sm=0.0, r_negm=0.0, s_negm=0.0,
            d0=0.0, d_neg1=0.0, imbalance=0.0, estimated_rate=0.0,
            rate_valid=False, total_groups=0,
            channel_pixels=channel_pixels, estimated_payload_bytes=0,
        )

    # A constant (zero-variance) channel — e.g. an all-opaque alpha
    # plane — has no structure for RS to measure.  Flipping always
    # increases the discrimination, producing a spurious imbalance of
    # ~1.0.  Detect and short-circuit so degenerate channels do not
    # poison the verdict.
    if float(plane.std()) == 0.0:
        return ChannelRSStats(
            channel=name, rm=0.0, sm=0.0, r_negm=0.0, s_negm=0.0,
            d0=0.0, d_neg1=0.0, imbalance=0.0, estimated_rate=0.0,
            rate_valid=False, total_groups=int(groups.shape[0]),
            channel_pixels=channel_pixels, estimated_payload_bytes=0,
        )

    f_orig = _discrimination(groups)

    # Mask M (positive).
    f_m = _discrimination(_apply_f1(groups, _MASK))
    rm, sm, total = _classify(f_orig, f_m)

    # Mask -M (negative).
    f_nm = _discrimination(_apply_f_neg1(groups, _NEG_MASK))
    r_nm, s_nm, _ = _classify(f_orig, f_nm)

    d0 = rm - sm
    d_neg1 = r_nm - s_nm
    imbalance = abs(d0 - d_neg1)

    # Simulate full embedding: flip every LSB with F1 and re-measure
    # under mask M to obtain R'_M, S'_M.
    full_flipped = groups ^ 1
    f_full = _discrimination(full_flipped)
    f_full_m = _discrimination(_apply_f1(full_flipped, _MASK))
    rm_full, sm_full, _ = _classify(f_full, f_full_m)
    d1 = rm_full - sm_full

    rate, valid = _estimate_rate(d0, d_neg1, d1)
    # Approximate embedded bytes in this channel: rate is the fraction of
    # this channel's pixels whose LSB was replaced, so payload bits ≈
    # rate * channel_pixels, bytes ≈ that / 8.  Only meaningful when the
    # quadratic produced a valid root.
    est_bytes = int(round(rate * channel_pixels / 8.0)) if valid else 0

    return ChannelRSStats(
        channel=name,
        rm=round(rm, 6),
        sm=round(sm, 6),
        r_negm=round(r_nm, 6),
        s_negm=round(s_nm, 6),
        d0=round(d0, 6),
        d_neg1=round(d_neg1, 6),
        imbalance=round(imbalance, 6),
        estimated_rate=round(rate, 6),
        rate_valid=valid,
        total_groups=total,
        channel_pixels=channel_pixels,
        estimated_payload_bytes=est_bytes,
    )


def run_rs_analysis(image: ImageData) -> RSResult:
    """Run RS-analysis on every channel of *image*."""

    channels = image.channel_arrays
    stats_list = [_channel_rs(name, plane)
                  for name, plane in channels.items()]
    max_imb = max((s.imbalance for s in stats_list), default=0.0)
    valid_rates = [s.estimated_rate for s in stats_list if s.rate_valid]
    max_rate = max(valid_rates, default=0.0)
    # Total payload-length estimate: sum the per-channel byte estimates.
    # For a single-channel payload only that channel contributes; for a
    # payload spread across channels each contributes its share.
    total_bytes = sum(s.estimated_payload_bytes for s in stats_list)
    return RSResult(
        channels=stats_list,
        max_imbalance=round(max_imb, 6),
        max_estimated_rate=round(max_rate, 6),
        estimated_payload_bytes=total_bytes,
    )
