"""Forensic visualisations for StegoScope.

Every function returns a backend-independent :class:`matplotlib.figure.Figure`
so the same figure can be either:

* embedded in the PySide6 GUI via ``FigureCanvasQTAgg(fig)``, or
* saved to disk via ``fig.savefig(path)``.

The plots use a light "StegoScope" palette so they look at home in the
light forensic GUI and remain legible when exported.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
from matplotlib.figure import Figure

from ..core.image_loader import ImageData
from ..core.verdict import AnalysisReport

# --------------------------------------------------------------------- #
# Light Classic StegoScope palette (must stay in sync with gui/theme.py)
# --------------------------------------------------------------------- #
PLOT_PALETTE = {
    "bg":        "#FFFFFF",   # figure facecolor (pure white)
    "panel":     "#FFFFFF",   # axes facecolor
    "grid":      "#E2E8F0",   # slate-200 gridlines & spines
    "text":      "#0F172A",   # slate-900 primary text
    "muted":     "#64748B",   # slate-500 tick labels
    "accent":    "#4F46E5",   # indigo-600 (primary accent)
    "accent2":   "#0284C7",   # sky-600 (secondary accent)
    "accent3":   "#7C3AED",   # violet-600 (tertiary)
    "good":      "#059669",   # emerald-600 (CLEAN)
    "warn":      "#D97706",   # amber-600 (SUSPICIOUS)
    "bad":       "#DC2626",   # red-600 (LIKELY HIDDEN DATA)
    "channel":   ["#4F46E5", "#0284C7", "#7C3AED", "#DB2777"],
}


def _light_style(fig: Figure) -> None:
    """Apply the light StegoScope theme to a figure.

    Sets a white facecolor on the figure and every axis, draws subtle
    slate-200 gridlines behind the data, and recolours every text/spine
    element so the chart is legible on a white surface and exports as a
    clean PNG (no transparent / dark slabs).
    """

    fig.patch.set_facecolor(PLOT_PALETTE["bg"])
    for ax in fig.axes:
        ax.set_facecolor(PLOT_PALETTE["panel"])
        for spine in ax.spines.values():
            spine.set_color(PLOT_PALETTE["grid"])
            spine.set_linewidth(0.8)
        ax.tick_params(colors=PLOT_PALETTE["muted"], labelsize=8)
        ax.xaxis.label.set_color(PLOT_PALETTE["text"])
        ax.yaxis.label.set_color(PLOT_PALETTE["text"])
        ax.title.set_color(PLOT_PALETTE["text"])
        ax.grid(True, color=PLOT_PALETTE["grid"], linewidth=0.6, alpha=0.9)
        ax.set_axisbelow(True)


# Back-compat alias for any external callers — now points to the light styler.
_dark_style = _light_style


def _verdict_color(verdict: str) -> str:
    if verdict == "CLEAN":
        return PLOT_PALETTE["good"]
    if verdict == "SUSPICIOUS":
        return PLOT_PALETTE["warn"]
    return PLOT_PALETTE["bad"]


# --------------------------------------------------------------------- #
# Image-plane visualisations
# --------------------------------------------------------------------- #
def draw_channel_planes(image: ImageData, *, dpi: int = 100) -> Figure:
    """Render the original image plus one grayscale panel per channel."""

    channels = image.channel_arrays
    n = len(channels) + 1
    fig = Figure(figsize=(2.4 * n, 2.6), dpi=dpi)
    fig.subplots_adjust(left=0.04, right=0.98, top=0.86, bottom=0.06, wspace=0.12)

    ax0 = fig.add_subplot(1, n, 1)
    arr = image.array
    if arr.shape[2] == 1:
        ax0.imshow(arr[:, :, 0], cmap="gray", vmin=0, vmax=255)
    else:
        ax0.imshow(arr)
    ax0.set_title("Original", fontsize=9)
    ax0.set_xticks([]); ax0.set_yticks([])

    for i, (name, plane) in enumerate(channels.items(), start=2):
        ax = fig.add_subplot(1, n, i)
        ax.imshow(plane, cmap="gray", vmin=0, vmax=255)
        ax.set_title(f"Channel {name}", fontsize=9, color=PLOT_PALETTE["accent"])
        ax.set_xticks([]); ax.set_yticks([])

    fig.suptitle(f"Channel Planes — {image.filename}",
                 color=PLOT_PALETTE["text"], fontsize=11, y=0.98)
    _dark_style(fig)
    return fig


def draw_lsb_planes(image: ImageData, *, dpi: int = 100) -> Figure:
    """Render the LSB plane (binary) of every channel."""

    channels = image.channel_arrays
    n = len(channels)
    fig = Figure(figsize=(2.4 * n, 2.6), dpi=dpi)
    fig.subplots_adjust(left=0.04, right=0.98, top=0.86, bottom=0.06, wspace=0.12)

    for i, (name, plane) in enumerate(channels.items(), start=1):
        ax = fig.add_subplot(1, n, i)
        lsb = (plane & 1) * 255
        ax.imshow(lsb, cmap="gray", vmin=0, vmax=255, interpolation="nearest")
        ax.set_title(f"LSB · {name}", fontsize=9, color=PLOT_PALETTE["accent"])
        ax.set_xticks([]); ax.set_yticks([])

    fig.suptitle(f"LSB Planes — {image.filename}",
                 color=PLOT_PALETTE["text"], fontsize=11, y=0.98)
    _dark_style(fig)
    return fig


# --------------------------------------------------------------------- #
# Statistical charts
# --------------------------------------------------------------------- #
def draw_bit_distribution(report: AnalysisReport, *, dpi: int = 100) -> Figure:
    """Grouped bar chart of 0-bit vs 1-bit counts per channel."""

    channels = [c.channel for c in report.lsb.channels]
    zeros = [c.zero_count for c in report.lsb.channels]
    ones = [c.one_count for c in report.lsb.channels]
    x = np.arange(len(channels))
    w = 0.38

    fig = Figure(figsize=(7, 3.6), dpi=dpi)
    ax = fig.add_subplot(111)
    ax.bar(x - w / 2, zeros, w, label="0-bits", color=PLOT_PALETTE["accent2"])
    ax.bar(x + w / 2, ones, w, label="1-bits", color=PLOT_PALETTE["accent"])
    ax.set_xticks(x); ax.set_xticklabels(channels)
    ax.set_ylabel("bit count")
    ax.set_title("LSB Bit Distribution per Channel", fontsize=10)
    ax.legend(facecolor=PLOT_PALETTE["panel"], edgecolor=PLOT_PALETTE["grid"],
              labelcolor=PLOT_PALETTE["text"], fontsize=8, framealpha=0.95)
    _dark_style(fig)
    fig.tight_layout()
    return fig


def draw_chi_chart(report: AnalysisReport, *, dpi: int = 100) -> Figure:
    """Bar chart of Chi-Square embedding probability per channel."""

    channels = [c.channel for c in report.chi.channels]
    probs = [c.embedding_probability for c in report.chi.channels]
    colors = [PLOT_PALETTE["bad"] if p >= 0.5 else
              PLOT_PALETTE["warn"] if p >= 0.1 else PLOT_PALETTE["good"]
              for p in probs]

    fig = Figure(figsize=(7, 3.6), dpi=dpi)
    ax = fig.add_subplot(111)
    ax.bar(channels, probs, color=colors)
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("embedding probability")
    ax.set_title("Chi-Square Embedding Probability per Channel", fontsize=10)
    ax.axhline(0.5, color=PLOT_PALETTE["muted"], linestyle="--", linewidth=0.8)
    _dark_style(fig)
    fig.tight_layout()
    return fig


def draw_rs_chart(report: AnalysisReport, *, dpi: int = 100) -> Figure:
    """Grouped bar chart of R_M / S_M / R_-M / S_-M per channel."""

    channels = [c.channel for c in report.rs.channels]
    rm = [c.rm for c in report.rs.channels]
    sm = [c.sm for c in report.rs.channels]
    rnm = [c.r_negm for c in report.rs.channels]
    snm = [c.s_negm for c in report.rs.channels]
    x = np.arange(len(channels))
    w = 0.2

    fig = Figure(figsize=(8, 3.8), dpi=dpi)
    ax = fig.add_subplot(111)
    ax.bar(x - 1.5 * w, rm, w, label="R_M", color=PLOT_PALETTE["accent"])
    ax.bar(x - 0.5 * w, sm, w, label="S_M", color=PLOT_PALETTE["accent2"])
    ax.bar(x + 0.5 * w, rnm, w, label="R_-M", color=PLOT_PALETTE["channel"][2])
    ax.bar(x + 1.5 * w, snm, w, label="S_-M", color=PLOT_PALETTE["channel"][3])
    ax.set_xticks(x); ax.set_xticklabels(channels)
    ax.set_ylabel("fraction of groups")
    ax.set_title("RS-Analysis: Regular / Singular Group Fractions", fontsize=10)
    ax.legend(facecolor=PLOT_PALETTE["panel"], edgecolor=PLOT_PALETTE["grid"],
              labelcolor=PLOT_PALETTE["text"], fontsize=8, ncol=4,
              loc="upper center", bbox_to_anchor=(0.5, -0.12), framealpha=0.95)
    _dark_style(fig)
    fig.tight_layout()
    return fig


def draw_score_breakdown(report: AnalysisReport, *, dpi: int = 100) -> Figure:
    """Stacked bar of LSB / Chi-Square / RS score contributions."""

    findings = report.verdict.channel_findings
    channels = [f.channel for f in findings]
    lsb = [f.lsb_score for f in findings]
    chi = [f.chi_score for f in findings]
    rs_ = [f.rs_score for f in findings]

    # Scale each by its weight so the stack height == channel_score.
    w_lsb = report.verdict.thresholds.get("weight_lsb", 0.2)
    w_chi = report.verdict.thresholds.get("weight_chi", 0.4)
    w_rs = report.verdict.thresholds.get("weight_rs", 0.4)
    lsb_w = [v * w_lsb for v in lsb]
    chi_w = [v * w_chi for v in chi]
    rs_w = [v * w_rs for v in rs_]

    fig = Figure(figsize=(7, 3.8), dpi=dpi)
    ax = fig.add_subplot(111)
    x = np.arange(len(channels))
    ax.bar(x, lsb_w, label="LSB", color=PLOT_PALETTE["accent2"])
    ax.bar(x, chi_w, bottom=lsb_w, label="Chi-Square", color=PLOT_PALETTE["accent"])
    ax.bar(x, rs_w, bottom=[a + b for a, b in zip(lsb_w, chi_w)],
           label="RS", color=PLOT_PALETTE["channel"][2])
    ax.set_xticks(x); ax.set_xticklabels(channels)
    ax.set_ylabel("weighted score")
    ax.set_ylim(0, 100)
    ax.set_title("Per-Channel Suspicion Score Breakdown", fontsize=10)
    ax.legend(facecolor=PLOT_PALETTE["panel"], edgecolor=PLOT_PALETTE["grid"],
              labelcolor=PLOT_PALETTE["text"], fontsize=8, ncol=3,
              loc="upper center", bbox_to_anchor=(0.5, -0.12), framealpha=0.95)
    _dark_style(fig)
    fig.tight_layout()
    return fig


def draw_suspicion_gauge(report: AnalysisReport, *, dpi: int = 100) -> Figure:
    """A donut gauge showing the overall suspicion score and verdict."""

    score = report.verdict.score
    color = _verdict_color(report.verdict.verdict)

    fig = Figure(figsize=(3.6, 3.6), dpi=dpi)
    ax = fig.add_subplot(111)
    ax.set_facecolor(PLOT_PALETTE["bg"])
    # Background ring (light gray track).
    ax.add_artist(_wedge(ax, 0, 360, 0.62, 0.78, PLOT_PALETTE["grid"]))
    # Score arc.
    angle = 360 * score / 100
    ax.add_artist(_wedge(ax, 90, 90 - angle, 0.62, 0.78, color))
    ax.text(0, 0.05, f"{score}", ha="center", va="center",
            fontsize=34, color=color, fontweight="bold")
    ax.text(0, -0.18, report.verdict.verdict, ha="center", va="center",
            fontsize=10, color=PLOT_PALETTE["text"])
    ax.set_xlim(-1, 1); ax.set_ylim(-1, 1)
    ax.set_aspect("equal")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    fig.patch.set_facecolor(PLOT_PALETTE["bg"])
    return fig


def _wedge(ax, start, end, r_in, r_out, color):
    from matplotlib.patches import Wedge
    return Wedge((0, 0), r_out, end, start, width=r_out - r_in,
                 facecolor=color, edgecolor="none")


# --------------------------------------------------------------------- #
# Batch summary chart
# --------------------------------------------------------------------- #
def draw_batch_summary(verdicts: Sequence[str], scores: Sequence[int],
                       *, dpi: int = 100) -> Figure:
    """Histogram of suspicion scores across a batch, coloured by verdict."""

    fig = Figure(figsize=(7, 3.6), dpi=dpi)
    ax = fig.add_subplot(111)
    labels = ["CLEAN", "SUSPICIOUS", "LIKELY HIDDEN DATA"]
    colors = [PLOT_PALETTE["good"], PLOT_PALETTE["warn"], PLOT_PALETTE["bad"]]
    counts = [
        sum(1 for s in scores if s <= 40),
        sum(1 for s in scores if 40 < s <= 70),
        sum(1 for s in scores if s > 70),
    ]
    ax.bar(labels, counts, color=colors)
    ax.set_ylabel("image count")
    ax.set_title("Batch Verdict Summary", fontsize=10)
    for i, c in enumerate(counts):
        ax.text(i, c + max(counts) * 0.02 if counts else 0, str(c),
                ha="center", color=PLOT_PALETTE["text"], fontsize=9)
    _dark_style(fig)
    fig.tight_layout()
    return fig


def save_figure(fig: Figure, path: str) -> str:
    """Save *fig* to *path* (PNG by default). Returns the path written."""

    fig.savefig(path, facecolor=fig.get_facecolor(), dpi=fig.dpi)
    return path


# --------------------------------------------------------------------- #
# LSB-plane black-and-white image export (stretch feature)
# --------------------------------------------------------------------- #
def save_lsb_planes(image: ImageData, out_dir: str | Path,
                    *, stem: str | None = None,
                    overwrite: bool = False) -> list[Path]:
    """Save each channel's LSB plane as a black-and-white PNG.

    Each LSB bit (0 or 1) is scaled to 0 (black) or 255 (white) so that
    structured patterns in the LSB plane are visible at a glance — the
    classic visual steganalysis aid.  Files are named
    ``<stem>_<channel>_lsb.png``.

    Parameters
    ----------
    image
        A loaded :class:`ImageData`.
    out_dir
        Destination directory (created if missing).
    stem
        Filename stem (defaults to the image filename without extension).
    overwrite
        If False (default), existing files are skipped rather than
        clobbered; a unique ``_N`` suffix is used instead.

    Returns
    -------
    list[Path]
        The paths written, one per channel.
    """

    from PIL import Image as _PILImage

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    base = stem or Path(image.filename).stem

    written: list[Path] = []
    for name, plane in image.channel_arrays.items():
        # 0 -> 0 (black), 1 -> 255 (white).  uint8 B&W image.
        bw = ((plane & 1) * 255).astype(np.uint8)
        target = out / f"{base}_{name}_lsb.png"
        if target.exists() and not overwrite:
            # de-duplicate rather than clobber
            for i in range(1, 10000):
                cand = out / f"{base}_{name}_lsb_{i}.png"
                if not cand.exists():
                    target = cand
                    break
        _PILImage.fromarray(bw, mode="L").save(target)
        written.append(target)
    return written
