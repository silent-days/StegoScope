"""Forensic report generation for StegoScope.

Produces four output formats from a single :class:`AnalysisReport`:

* **TXT**  — human-readable plain text, suitable for terminals and
  quick review.
* **JSON** — structured, machine-readable, round-trips through the
  dataclass model.
* **CSV**  — one summary row plus per-channel detail rows, for
  spreadsheet import and batch aggregation.
* **PDF**  — formatted, paginated, suitable for academic / chain-of-
  custody demonstration.

All payloads are sanitised to printable ASCII before going into any
report so that a binary candidate stream cannot corrupt the output.
"""

from __future__ import annotations

import csv
import html
import io
import json as _json
from dataclasses import asdict
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

from ..core.verdict import AnalysisReport

REPORT_FORMATS = ("txt", "json", "csv", "pdf")


class ReportFormatError(ValueError):
    """Raised when an unsupported report format is requested."""


# --------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------- #
def _sanitize(text: str, limit: int = 512) -> str:
    """Reduce arbitrary text to safe printable ASCII for report output."""

    if not text:
        return ""
    out = "".join(ch if 0x20 <= ord(ch) < 0x7F else "." for ch in text)
    if len(out) > limit:
        out = out[:limit] + " …"
    return out


def _xml_sanitize(text: str, limit: int = 512) -> str:
    """Like :func:`_sanitize` but also XML-escapes ``&``, ``<``, ``>``.

    Required for any text placed inside a ReportLab ``Paragraph`` (whose
    mini-XML parser would otherwise choke on — or worse, interpret —
    those characters).  Candidate payload bytes frequently contain
    ``0x26``/``0x3C``/``0x3E``, so the ASCII preview MUST be escaped.
    """

    if not text:
        return ""
    out: list[str] = []
    for ch in str(text):
        o = ord(ch)
        if ch in "&<>":
            out.append(ch)
        elif 0x20 <= o < 0x7F:
            out.append(ch)
        else:
            out.append(".")
    # Truncate before escaping so a generated entity is never cut in half.
    raw = "".join(out)
    raw = raw[:limit] + (" …" if len(raw) > limit else "")
    return html.escape(raw, quote=False)


def _fmt_bytes(n: int) -> str:
    for unit in ("B", "KiB", "MiB", "GiB"):
        if n < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} TiB"


# --------------------------------------------------------------------- #
# TXT
# --------------------------------------------------------------------- #
def to_txt(report: AnalysisReport) -> str:
    """Render *report* as a formatted plain-text string."""

    info = report.info
    v = report.verdict
    lines: list[str] = []

    lines.append("=" * 72)
    lines.append(f"  {report.app_name} v{report.app_version} — {report.developer}")
    lines.append("  Detect. Analyze. Investigate.")
    lines.append("=" * 72)
    lines.append("")
    lines.append(f"Investigation timestamp (UTC): {report.timestamp}")
    lines.append(f"Image under analysis         : {info.filename}")
    lines.append(f"Source path                  : {info.path}")
    lines.append("")
    lines.append("-" * 72)
    lines.append("  FILE INFORMATION")
    lines.append("-" * 72)
    lines.append(f"  Format            : {info.format}")
    lines.append(f"  Colour mode       : {info.mode}")
    lines.append(f"  Dimensions        : {info.width} x {info.height} px")
    lines.append(f"  Total pixels      : {info.total_pixels:,}")
    lines.append(f"  Channels          : {', '.join(info.channels)}")
    lines.append(f"  File size         : {_fmt_bytes(info.file_size)}")
    if info.metadata:
        for k, val in info.metadata.items():
            lines.append(f"  {k:17s} : {_sanitize(str(val), 120)}")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  LSB ANALYSIS")
    lines.append("-" * 72)
    lines.append(f"  {'channel':8s} {'zeros%':>8s} {'ones%':>8s} {'mean':>8s} "
                 f"{'longest':>8s} {'bit':>4s}")
    for c in report.lsb.channels:
        lines.append(f"  {c.channel:8s} {c.zero_pct:8.3f} {c.one_pct:8.3f} "
                     f"{c.lsb_mean:8.4f} {c.longest_run:8d} {c.longest_run_value:4d}")
    lines.append(f"  Channel imbalance (max-min LSB mean): {report.lsb.channel_imbalance:.6f}")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  CHI-SQUARE ANALYSIS (Westfeld-Pfitzmann)")
    lines.append("-" * 72)
    lines.append(f"  {'channel':8s} {'statistic':>11s} {'dof':>6s} "
                 f"{'p-value':>10s} {'embed_prob':>11s} {'pairs':>7s}")
    for c in report.chi.channels:
        lines.append(f"  {c.channel:8s} {c.statistic:11.2f} {c.dof:6d} "
                     f"{c.p_value:10.4f} {c.embedding_probability:11.4f} "
                     f"{c.sample_pairs:7d}")
    lines.append(f"  Max embedding probability across channels: "
                 f"{report.chi.max_embedding_probability:.4f}")
    lines.append("  Interpretation: a HIGH embedding probability means the pair")
    lines.append("  value histogram is consistent with random LSB replacement.")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  RS ANALYSIS (Fridrich-Goljan-Du)")
    lines.append("-" * 72)
    lines.append(f"  {'channel':8s} {'R_M':>7s} {'S_M':>7s} {'R_-M':>7s} "
                 f"{'S_-M':>7s} {'d0':>8s} {'d_-1':>8s} {'imb':>8s} {'rate':>7s}")
    for c in report.rs.channels:
        valid = f"{c.estimated_rate:.3f}" if c.rate_valid else "  n/a"
        lines.append(f"  {c.channel:8s} {c.rm:7.4f} {c.sm:7.4f} {c.r_negm:7.4f} "
                     f"{c.s_negm:7.4f} {c.d0:8.4f} {c.d_neg1:8.4f} "
                     f"{c.imbalance:8.4f} {valid:>7s}")
    lines.append(f"  Max |d0 - d_-1| imbalance across channels: "
                 f"{report.rs.max_imbalance:.4f}")
    # The RS quadratic rate estimate is frequently valid-but-spurious on
    # clean images and invalid on some embedded ones, so we only surface
    # an embedding-rate / payload-length assessment when the imbalance
    # itself is non-trivial (above the ~0.01 clean baseline).  This
    # avoids printing a misleading "payload length" on a CLEAN image.
    if report.rs.max_imbalance >= 0.03:
        if report.rs.max_estimated_rate > 0:
            lines.append(f"  Approx. embedding rate (max valid channel): "
                         f"{report.rs.max_estimated_rate:.3f}")
            lines.append(f"  Approx. embedded payload length          : "
                         f"{report.rs.estimated_payload_bytes:,} bytes")
            lines.append("  (RS length estimate is indicative only — see limitations.)")
        else:
            lines.append("  RS imbalance exceeds the clean baseline; the quadratic")
            lines.append("  rate estimate was invalid on this image (a known RS")
            lines.append("  limitation) — the imbalance itself is the reliable signal.")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  VERDICT")
    lines.append("-" * 72)
    lines.append(f"  Suspicion score : {v.score} / 100")
    lines.append(f"  Verdict         : {v.verdict}")
    lines.append(f"  Confidence      : {v.confidence}")
    lines.append(f"  Thresholds      : CLEAN <= {v.thresholds['clean_max']}, "
                 f"SUSPICIOUS <= {v.thresholds['suspicious_max']}")
    lines.append(f"  Weights         : LSB {v.thresholds['weight_lsb']}, "
                 f"Chi {v.thresholds['weight_chi']}, RS {v.thresholds['weight_rs']}")
    lines.append("")
    lines.append("  Per-channel findings:")
    for f in v.channel_findings:
        lines.append(f"    [{f.channel}] score={f.channel_score:3d} "
                     f"(LSB {f.lsb_score:3d}, Chi {f.chi_score:3d}, RS {f.rs_score:3d})")
        for note in f.notes:
            lines.append(f"        - {_sanitize(note, 110)}")
    lines.append("")
    lines.append("  Detection reasons:")
    for r in v.reasons:
        lines.append(f"    * {_sanitize(r, 110)}")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  PAYLOAD EXTRACTION")
    lines.append("-" * 72)
    if report.payload is None:
        lines.append("  No payload extraction was requested for this run.")
    else:
        p = report.payload
        lines.append(f"  Channel order        : {', '.join(p.channel_order)}")
        lines.append(f"  Candidate bytes      : {p.byte_count:,}")
        lines.append(f"  Bits packed          : {p.bits_used:,}")
        lines.append(f"  Total LSB bits avail : {p.total_bits_available:,}")
        lines.append(f"  Truncated            : {p.truncated}")
        lines.append("  Hex preview (first 64 bytes):")
        hexline = p.data[:64].hex(" ")
        lines.append(f"    {_sanitize(hexline, 200)}")
        lines.append("  ASCII preview (first 64 bytes):")
        asciiline = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in p.data[:64])
        lines.append(f"    {_sanitize(asciiline, 200)}")
        lines.append("  NOTE: extracted data is CANDIDATE, not confirmed payload.")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  ANALYSIS LIMITATIONS")
    lines.append("-" * 72)
    for lim in report.limitations:
        lines.append(f"  * {_sanitize(lim, 110)}")
    lines.append("")
    lines.append("=" * 72)
    lines.append(f"  End of {report.app_name} forensic report")
    lines.append("=" * 72)
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------- #
# JSON
# --------------------------------------------------------------------- #
def to_json(report: AnalysisReport) -> str:
    return _json.dumps(asdict(report), indent=2, default=str)


# --------------------------------------------------------------------- #
# CSV
# --------------------------------------------------------------------- #
def to_csv(report: AnalysisReport) -> str:
    """Return CSV with a summary row then one detail row per channel."""

    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["# StegoScope forensic report — summary"])
    info = report.info
    v = report.verdict
    w.writerow(["field", "value"])
    w.writerow(["app", f"{report.app_name} v{report.app_version}"])
    w.writerow(["timestamp", report.timestamp])
    w.writerow(["filename", info.filename])
    w.writerow(["path", info.path])
    w.writerow(["format", info.format])
    w.writerow(["mode", info.mode])
    w.writerow(["width", info.width])
    w.writerow(["height", info.height])
    w.writerow(["channels", ",".join(info.channels)])
    w.writerow(["file_size", info.file_size])
    w.writerow(["total_pixels", info.total_pixels])
    w.writerow(["lsb_channel_imbalance", report.lsb.channel_imbalance])
    w.writerow(["chi_max_embed_prob", report.chi.max_embedding_probability])
    w.writerow(["rs_max_imbalance", report.rs.max_imbalance])
    w.writerow(["rs_max_estimated_rate", report.rs.max_estimated_rate])
    w.writerow(["rs_estimated_payload_bytes", report.rs.estimated_payload_bytes])
    w.writerow(["verdict_score", v.score])
    w.writerow(["verdict", v.verdict])
    w.writerow(["confidence", v.confidence])
    p = report.payload
    w.writerow(["payload_extracted", "yes" if p else "no"])
    w.writerow(["payload_bytes", p.byte_count if p else 0])
    w.writerow([])

    w.writerow(["# Per-channel detail"])
    w.writerow(["channel", "lsb_mean", "lsb_zero_pct", "lsb_one_pct",
                "lsb_longest_run", "chi_stat", "chi_dof", "chi_pvalue",
                "chi_embed_prob", "rs_rm", "rs_sm", "rs_r_negm", "rs_s_negm",
                "rs_d0", "rs_d_neg1", "rs_imbalance", "rs_estimated_rate",
                "rs_rate_valid", "rs_est_payload_bytes", "channel_score"])
    lsb_by = {c.channel: c for c in report.lsb.channels}
    chi_by = {c.channel: c for c in report.chi.channels}
    rs_by = {c.channel: c for c in report.rs.channels}
    score_by = {f.channel: f.channel_score for f in v.channel_findings}
    for name in info.channels:
        l = lsb_by[name]; c = chi_by[name]; r = rs_by[name]
        w.writerow([name, l.lsb_mean, l.zero_pct, l.one_pct, l.longest_run,
                    c.statistic, c.dof, c.p_value, c.embedding_probability,
                    r.rm, r.sm, r.r_negm, r.s_negm, r.d0, r.d_neg1,
                    r.imbalance, r.estimated_rate, r.rate_valid,
                    r.estimated_payload_bytes, score_by.get(name, "")])
    return buf.getvalue()


# --------------------------------------------------------------------- #
# PDF
# --------------------------------------------------------------------- #
# Light-theme palette for PDF reports. Kept in sync with gui/theme.py
# and visualization/plots.py so TXT/JSON/CSV/PDF all share the same
# forensic indigo + slate identity as the GUI.
PDF_PALETTE = {
    "ink":         "#0F172A",   # primary text (slate-950)
    "ink_dim":     "#475569",   # secondary text (slate-600)
    "ink_muted":   "#64748B",   # tertiary text (slate-500)
    "rule":        "#CBD5E1",   # slate-300 rules
    "rule_soft":   "#E2E8F0",   # slate-200 gridlines
    "surface":     "#F8FAFC",   # slate-50 zebra base
    "surface_alt": "#EEF2F7",   # slate-100 zebra alt
    "panel":       "#F1F5F9",   # slate-100 panel
    "accent":      "#4F46E5",   # indigo-600
    "accent_dim":  "#C7D2FE",   # indigo-200
    "good":        "#059669",   # emerald-600 (CLEAN)
    "good_bg":     "#D1FAE5",   # emerald-100
    "warn":        "#D97706",   # amber-600 (SUSPICIOUS)
    "warn_bg":     "#FEF3C7",   # amber-100
    "bad":         "#DC2626",   # red-600 (LIKELY)
    "bad_bg":      "#FEE2E2",   # red-100
}


def _verdict_colour(label: str) -> colors.Color:
    if label == "CLEAN":
        return colors.HexColor(PDF_PALETTE["good"])
    if label == "SUSPICIOUS":
        return colors.HexColor(PDF_PALETTE["warn"])
    return colors.HexColor(PDF_PALETTE["bad"])


def _verdict_bg(label: str) -> colors.Color:
    """Soft tinted background for the verdict badge cell."""
    if label == "CLEAN":
        return colors.HexColor(PDF_PALETTE["good_bg"])
    if label == "SUSPICIOUS":
        return colors.HexColor(PDF_PALETTE["warn_bg"])
    return colors.HexColor(PDF_PALETTE["bad_bg"])


def generate_pdf(report: AnalysisReport, path: str | Path) -> Path:
    """Write a paginated PDF report to *path*. Returns the path."""

    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("StegoTitle", parent=styles["Title"],
                                 fontSize=20, textColor=colors.HexColor(PDF_PALETTE["ink"]),
                                 spaceAfter=4)
    sub_style = ParagraphStyle("StegoSub", parent=styles["Normal"],
                               fontSize=9, textColor=colors.HexColor(PDF_PALETTE["ink_dim"]),
                               spaceAfter=10)
    h2 = ParagraphStyle("StegoH2", parent=styles["Heading2"],
                        fontSize=12, textColor=colors.HexColor(PDF_PALETTE["accent"]),
                        spaceBefore=12, spaceAfter=4)
    body = ParagraphStyle("StegoBody", parent=styles["BodyText"],
                          fontSize=9, leading=12)
    mono = ParagraphStyle("StegoMono", parent=styles["Code"],
                          fontSize=7.5, leading=9,
                          textColor=colors.HexColor(PDF_PALETTE["ink"]))

    info = report.info
    v = report.verdict

    story: list = []
    story.append(Paragraph(
        f"{_xml_sanitize(report.app_name)} <font size=11>"
        f"v{_xml_sanitize(report.app_version)}</font>", title_style))
    story.append(Paragraph(
        f"{_xml_sanitize(report.developer)} — Detect. Analyze. Investigate.<br/>"
        f"Forensic analysis report — {report.timestamp}", sub_style))

    # Verdict banner table — light theme: a soft tinted badge cell instead
    # of a dark slab, dark ink labels, white background panel.
    vcolour = _verdict_colour(v.verdict)
    v_bg = _verdict_bg(v.verdict)
    verdict_tbl = Table([[Paragraph("<b>VERDICT</b>", body),
                          Paragraph(f"<b><font color='white'>{v.verdict}</font></b>", body),
                          Paragraph(f"<b>Score</b> {v.score}/100", body)]],
                        colWidths=[40 * mm, 60 * mm, 40 * mm])
    verdict_tbl.setStyle(TableStyle([
        # Verdict badge cell: coloured fill with white text.
        ("BACKGROUND", (1, 0), (1, 0), vcolour),
        # VERDICT label cell: soft verdict-tinted background, dark verdict-colour text.
        ("BACKGROUND", (0, 0), (0, 0), v_bg),
        ("TEXTCOLOR", (0, 0), (0, 0), vcolour),
        # Score cell: subtle slate panel.
        ("BACKGROUND", (2, 0), (2, 0), colors.HexColor(PDF_PALETTE["panel"])),
        ("TEXTCOLOR", (2, 0), (2, 0), colors.HexColor(PDF_PALETTE["ink"])),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "CENTER"),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor(PDF_PALETTE["rule"])),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(verdict_tbl)
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<b>Confidence:</b> {_xml_sanitize(v.confidence)}", body))

    # File information.
    story.append(Paragraph("File Information", h2))
    file_rows = [
        ["Filename", info.filename],
        ["Source path", info.path],
        ["Format", info.format],
        ["Colour mode", info.mode],
        ["Dimensions", f"{info.width} x {info.height} px"],
        ["Total pixels", f"{info.total_pixels:,}"],
        ["Channels", ", ".join(info.channels)],
        ["File size", _fmt_bytes(info.file_size)],
    ]
    ftbl = Table(file_rows, colWidths=[40 * mm, 110 * mm])
    ftbl.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor(PDF_PALETTE["accent"])),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(PDF_PALETTE["panel"])),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1),
         [colors.HexColor(PDF_PALETTE["surface"]), colors.HexColor(PDF_PALETTE["surface_alt"])]),
        ("BOX", (0, 0), (-1, -1), 0.3, colors.HexColor(PDF_PALETTE["rule"])),
        ("INNERGRID", (0, 0), (-1, -1), 0.2, colors.HexColor(PDF_PALETTE["rule_soft"])),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(ftbl)

    # LSB analysis.
    story.append(Paragraph("LSB Analysis", h2))
    lsb_hdr = ["Channel", "0-bits %", "1-bits %", "LSB mean", "Longest run", "Bit"]
    lsb_rows = [lsb_hdr] + [
        [c.channel, f"{c.zero_pct:.3f}", f"{c.one_pct:.3f}",
         f"{c.lsb_mean:.4f}", str(c.longest_run), str(c.longest_run_value)]
        for c in report.lsb.channels
    ]
    lsb_rows.append(["Imbalance", "", "", f"{report.lsb.channel_imbalance:.6f}", "", ""])
    story.append(_data_table(lsb_rows))

    # Chi-square.
    story.append(Paragraph("Chi-Square Analysis (Westfeld-Pfitzmann)", h2))
    chi_hdr = ["Channel", "Statistic", "dof", "p-value", "Embed prob", "Pairs"]
    chi_rows = [chi_hdr] + [
        [c.channel, f"{c.statistic:.2f}", str(c.dof),
         f"{c.p_value:.4f}", f"{c.embedding_probability:.4f}", str(c.sample_pairs)]
        for c in report.chi.channels
    ]
    story.append(_data_table(chi_rows))
    story.append(Paragraph(
        "A <b>high</b> embedding probability indicates the value-pair histogram "
        "is consistent with random LSB replacement.", body))

    # RS analysis.
    story.append(Paragraph("RS Analysis (Fridrich-Goljan-Du)", h2))
    rs_hdr = ["Ch", "R_M", "S_M", "R_-M", "S_-M", "d0", "d_-1", "imb", "rate"]
    rs_rows = [rs_hdr] + [
        [c.channel, f"{c.rm:.4f}", f"{c.sm:.4f}", f"{c.r_negm:.4f}",
         f"{c.s_negm:.4f}", f"{c.d0:.4f}", f"{c.d_neg1:.4f}",
         f"{c.imbalance:.4f}",
         f"{c.estimated_rate:.3f}" if c.rate_valid else "n/a"]
        for c in report.rs.channels
    ]
    story.append(_data_table(rs_rows))
    if report.rs.max_imbalance >= 0.03:
        if report.rs.max_estimated_rate > 0:
            story.append(Paragraph(
                f"<b>Approx. embedding rate</b> (max valid channel): "
                f"{report.rs.max_estimated_rate:.3f} &nbsp; "
                f"<b>Approx. embedded payload length</b>: "
                f"{report.rs.estimated_payload_bytes:,} bytes "
                f"(indicative only).", body))
        else:
            story.append(Paragraph(
                "RS imbalance exceeds the clean baseline; the quadratic "
                "rate estimate was invalid on this image (a known RS "
                "limitation) — the imbalance itself is the reliable "
                "signal.", body))

    # Per-channel findings.
    story.append(Paragraph("Per-Channel Findings", h2))
    find_hdr = ["Channel", "LSB", "Chi", "RS", "Score"]
    find_rows = [find_hdr] + [
        [f.channel, str(f.lsb_score), str(f.chi_score), str(f.rs_score),
         str(f.channel_score)]
        for f in v.channel_findings
    ]
    story.append(_data_table(find_rows))

    # Detection reasons.
    story.append(Paragraph("Detection Reasons", h2))
    for r in v.reasons:
        story.append(Paragraph(f"&bull; {_xml_sanitize(r, 400)}", body))

    # Payload.
    story.append(Paragraph("Payload Extraction", h2))
    if report.payload is None:
        story.append(Paragraph("No payload extraction was requested.", body))
    else:
        p = report.payload
        story.append(Paragraph(
            f"Channel order: {', '.join(p.channel_order)}<br/>"
            f"Candidate bytes: <b>{p.byte_count:,}</b> &nbsp; "
            f"Bits packed: {p.bits_used:,} &nbsp; "
            f"Truncated: {p.truncated}", body))
        story.append(Paragraph("<b>Hex preview (first 64 bytes):</b>", body))
        story.append(Paragraph(_xml_sanitize(p.data[:64].hex(" "), 400).replace(" ", "&nbsp;"), mono))
        asc = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in p.data[:64])
        story.append(Paragraph("<b>ASCII preview (first 64 bytes):</b>", body))
        story.append(Paragraph(_xml_sanitize(asc, 400), mono))
        story.append(Paragraph(
            "<i>Extracted data is CANDIDATE, not confirmed payload, and is "
            "treated as untrusted throughout.</i>", body))

    # Limitations.
    story.append(Paragraph("Analysis Limitations", h2))
    for lim in report.limitations:
        story.append(Paragraph(f"&bull; {_xml_sanitize(lim, 400)}", body))

    # Build the document with a footer that carries the app name + page no.
    doc = BaseDocTemplate(str(out), pagesize=A4,
                          leftMargin=18 * mm, rightMargin=18 * mm,
                          topMargin=18 * mm, bottomMargin=18 * mm,
                          title=f"{report.app_name} report — {info.filename}",
                          author=report.developer)
    frame = Frame(doc.leftMargin, doc.bottomMargin,
                  doc.width, doc.height, id="main")

    def _footer(canvas, doc_):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor(PDF_PALETTE["rule"]))
        canvas.setLineWidth(0.4)
        canvas.line(18 * mm, 14 * mm, A4[0] - 18 * mm, 14 * mm)
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor(PDF_PALETTE["ink_muted"]))
        canvas.drawString(18 * mm, 10 * mm,
                          f"{report.app_name} v{report.app_version} — {report.developer}")
        canvas.drawRightString(A4[0] - 18 * mm, 10 * mm,
                               f"Page {doc_.page}")
        canvas.restoreState()

    doc.addPageTemplates([PageTemplate(id="main", frames=[frame],
                                       onPage=_footer)])
    doc.build(story)
    return out


def _data_table(rows: list[list[str]]) -> Table:
    """Build a uniformly-styled data table from *rows* (header first)."""

    tbl = Table(rows, hAlign="LEFT")
    tbl.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(PDF_PALETTE["accent"])),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.HexColor(PDF_PALETTE["surface"]), colors.HexColor(PDF_PALETTE["surface_alt"])]),
        ("BOX", (0, 0), (-1, -1), 0.3, colors.HexColor(PDF_PALETTE["rule"])),
        ("INNERGRID", (0, 0), (-1, -1), 0.2, colors.HexColor(PDF_PALETTE["rule_soft"])),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return tbl


# --------------------------------------------------------------------- #
# Unified saver
# --------------------------------------------------------------------- #
def save_report(report: AnalysisReport, path: str | Path,
                fmt: str | None = None,
                overwrite: bool = False) -> Path:
    """Save *report* to *path* in the requested (or inferred) format.

    The format is taken from *fmt* if given, else from *path*'s suffix.

    Parameters
    ----------
    overwrite
        If ``False`` (default) and the target path already exists, a
        :class:`FileExistsError` is raised rather than silently
        clobbering an existing file.
    """

    p = Path(path)
    fmt = (fmt or p.suffix.lstrip(".")).lower()
    if fmt not in REPORT_FORMATS:
        raise ReportFormatError(
            f"Unsupported report format '{fmt}'. "
            f"Supported: {', '.join(REPORT_FORMATS)}."
        )

    if p.exists() and not overwrite:
        raise FileExistsError(
            f"Refusing to overwrite existing report {p}. "
            f"Pass overwrite=True (or --force on the CLI) to allow it.")

    p.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "txt":
        p.write_text(to_txt(report), encoding="utf-8")
    elif fmt == "json":
        p.write_text(to_json(report), encoding="utf-8")
    elif fmt == "csv":
        p.write_text(to_csv(report), encoding="utf-8")
    elif fmt == "pdf":
        generate_pdf(report, p)
    return p
