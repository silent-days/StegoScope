"""
StegoScope — Advanced Steganography Intelligence Suite
======================================================

A digital-forensics toolkit for detecting hidden information inside
digital images.  StegoScope performs LSB-plane analysis, Chi-Square
statistical examination, RS-analysis, candidate payload extraction,
visual forensics and forensic report generation.

Public API
----------
``stegoscope.analyze_image`` runs the complete pipeline against a single
image file and returns an :class:`~stegoscope.core.verdict.AnalysisReport`.

This package performs **all analysis locally**.  No image data ever
leaves the host machine.
"""

from __future__ import annotations

__version__ = "1.0.0"
__app_name__ = "StegoScope"
__full_name__ = "StegoScope — Steganography Intelligence Suite"
__tagline__ = "Detect. Analyze. Investigate."
__developer__ = "StegoScope Labs"
__license__ = "MIT"

# Re-export the most useful entry points so callers can do
# ``from stegoscope import analyze_image``.
from .core.verdict import (  # noqa: E402  (re-export)
    AnalysisReport,
    ImageInfo,
    VerdictResult,
    analyze_image,
)

__all__ = [
    "__version__",
    "__app_name__",
    "__full_name__",
    "__tagline__",
    "__developer__",
    "__license__",
    "analyze_image",
    "AnalysisReport",
    "ImageInfo",
    "VerdictResult",
]
