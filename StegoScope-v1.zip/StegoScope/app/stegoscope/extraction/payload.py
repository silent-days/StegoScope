"""Candidate LSB payload extraction.

This module reconstructs the byte stream that a naive LSB-replacement
steganographer would have embedded, by reading the LSB of selected
pixels and packing the bits into bytes.

Extraction modes
----------------
The **default** mode is the one required by the official assignment:
read every channel in channel order (``R`` then ``G`` then ``B`` then
``A``), each channel flattened row-major, and pack the resulting bit
stream **MSB-first** into bytes.  This is the canonical order the
embedder writes, so a payload embedded by the matching routine is
recovered byte-for-byte.

Optional knobs (all default to the assignment-required behaviour):

* ``channels`` — restrict extraction to a subset / single channel
  (e.g. ``["R"]`` for individual-channel extraction).
* ``bit_order`` — ``"msb"`` (default, MSB-first) or ``"lsb"``.
* ``interleave`` — ``False`` (default, channel-sequential: all of R,
  then all of G, …) or ``True`` (bit-round-robin: R[0], G[0], B[0],
  R[1], G[1], B[1], … — true RGB-interleaved extraction).

CRITICAL SECURITY NOTE
----------------------
Extracted bytes are **candidate data only**.  They are untrusted input.
StegoScope will *never*:

* execute them,
* interpret them as a script,
* write them to a path that the OS would auto-execute,
* follow any instruction they contain.

The inspector merely presents hex and printable-ASCII previews.
``save_payload`` always forces a ``.bin`` extension (never ``.exe``,
``.sh``, ``.py``, …) and writes with default (non-executable) file
permissions.  Extracted bytes are treated as untrusted throughout.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..core.image_loader import ImageData

# A byte is "printable ASCII" for preview purposes if it falls in the
# safe visible ASCII range.  Everything else is shown as '.'.
_PRINTABLE = bytes(range(0x20, 0x7E)) + b"\t\n\r"


class PayloadError(ValueError):
    """Raised for invalid extraction parameters or destination paths."""


@dataclass
class PayloadResult:
    byte_count: int
    truncated: bool
    """True if extraction stopped early because ``max_bytes`` was hit."""

    bits_used: int
    """Number of LSB bits packed into the bytes (byte_count * 8, minus
    any zero-padding of the final partial byte)."""

    total_bits_available: int
    """Total LSB bits available across the extracted channels."""

    channel_order: list[str] = field(default_factory=list)
    bit_order: str = "msb"
    interleave: bool = False
    data: bytes = b""
    hex_preview: str = ""
    ascii_preview: str = ""


def _bits_to_bytes(bits: np.ndarray, max_bytes: int,
                   bit_order: str) -> tuple[bytes, int]:
    """Pack a 1-D array of 0/1 bits into bytes.

    ``bit_order`` is ``"msb"`` (``packbits`` big-endian) or ``"lsb"``
    (little-endian).  The final partial byte is zero-padded.  Returns
    ``(bytes, bits_actually_packed)``.
    """

    bits = bits.astype(np.uint8)
    if bits.size == 0:
        return b"", 0
    usable_bits = min(bits.size, max_bytes * 8)
    bits = bits[:usable_bits]
    pad = (-usable_bits) % 8
    if pad:
        bits = np.concatenate([bits, np.zeros(pad, dtype=np.uint8)])
    order = "big" if bit_order == "msb" else "little"
    packed = np.packbits(bits, bitorder=order)
    return packed.tobytes(), usable_bits


def extract_payload(image: ImageData, *,
                    max_bytes: int = 1 << 20,
                    channels: list[str] | tuple[str, ...] | None = None,
                    bit_order: str = "msb",
                    interleave: bool = False) -> PayloadResult:
    """Extract a candidate LSB payload from *image*.

    Parameters
    ----------
    image
        A loaded :class:`ImageData`.
    max_bytes
        Hard cap on extracted bytes.  Default 1 MiB to bound memory.
    channels
        Channel names to read, in extraction order.  Default: all of
        ``image.channels`` (R, G, B, A).  Names must exist on the image.
    bit_order
        ``"msb"`` (default) or ``"lsb"`` — bit significance within each
        byte.
    interleave
        ``False`` (default): read each chosen channel fully in order
        (channel-sequential — the assignment-required default).  ``True``:
        read bit-round-robin across the chosen channels (true
        RGB-interleaved).

    Returns
    -------
    PayloadResult
    """

    if bit_order not in ("msb", "lsb"):
        raise PayloadError(
            f"bit_order must be 'msb' or 'lsb', got {bit_order!r}")
    if max_bytes <= 0:
        raise PayloadError(f"max_bytes must be positive, got {max_bytes}")

    available = image.channel_arrays
    channel_order = list(channels) if channels is not None else list(image.channels)
    # Validate requested channels exist on the image.
    for name in channel_order:
        if name not in available:
            raise PayloadError(
                f"Channel {name!r} not present on image "
                f"(available: {list(image.channels)}).")
    if not channel_order:
        raise PayloadError("No channels selected for extraction.")

    bits_needed = max_bytes * 8
    selected_total_bits = sum(available[name].size for name in channel_order)
    collected: list[np.ndarray] = []
    bits_collected = 0
    # A cap is truncating whenever the selected stream is larger than the
    # requested byte budget, including the exact-boundary case where the
    # loop stops after filling the final byte.
    truncated = selected_total_bits > bits_needed

    if not interleave:
        # Channel-sequential: all of channel[0], then channel[1], …
        for name in channel_order:
            if bits_collected >= bits_needed:
                break
            lsb = (available[name].reshape(-1) & 1).astype(np.uint8)
            remaining = bits_needed - bits_collected
            if lsb.size > remaining:
                lsb = lsb[:remaining]
                truncated = True
            collected.append(lsb)
            bits_collected += lsb.size
    else:
        # True RGB-interleaved: round-robin one bit per channel.
        planes = [available[n].reshape(-1) & 1 for n in channel_order]
        sizes = [p.size for p in planes]
        if sizes:
            max_len = max(sizes)
            buf = np.empty(min(max_len * len(planes), bits_needed),
                           dtype=np.uint8)
            idx = 0
            for pos in range(max_len):
                if idx >= bits_needed:
                    truncated = True
                    break
                for p, sz in zip(planes, sizes):
                    if pos < sz:
                        buf[idx] = p[pos]
                        idx += 1
                        if idx >= bits_needed:
                            truncated = True
                            break
                if idx >= bits_needed:
                    break
            collected.append(buf[:idx])
            bits_collected = idx

    if not collected or bits_collected == 0:
        return PayloadResult(
            byte_count=0, truncated=False, bits_used=0,
            total_bits_available=selected_total_bits,
            channel_order=channel_order, bit_order=bit_order,
            interleave=interleave,
        )

    all_bits = np.concatenate(collected) if len(collected) > 1 else collected[0]
    data, bits_used = _bits_to_bytes(all_bits, max_bytes, bit_order)
    # Truncation is also set if we packed fewer bits than we collected
    # (final partial byte rounding does not count as truncation).
    truncated = truncated or (bits_collected > bits_used)
    byte_count = len(data)

    hex_preview = data[:256].hex(" ")
    ascii_preview = "".join(
        chr(b) if b in _PRINTABLE else "." for b in data[:256]
    )

    return PayloadResult(
        byte_count=byte_count,
        truncated=truncated,
        bits_used=bits_used,
        total_bits_available=selected_total_bits,
        channel_order=channel_order,
        bit_order=bit_order,
        interleave=interleave,
        data=data,
        hex_preview=hex_preview,
        ascii_preview=ascii_preview,
    )


def save_payload(result: PayloadResult, dest: str | Path,
                 *, overwrite: bool = False) -> Path:
    """Write extracted bytes to *dest* as a ``.bin`` file.

    The destination always receives a ``.bin`` extension (appended if a
    different or no extension is given) so the OS will not auto-execute
    it.  The file is written with default permissions (non-executable).

    Parameters
    ----------
    result
        The :class:`PayloadResult` to persist.
    dest
        Destination path.
    overwrite
        If ``False`` (default) and the target path already exists, a
        :class:`FileExistsError` is raised rather than silently
        clobbering an existing file.

    Raises
    ------
    FileExistsError
        The target exists and ``overwrite`` is False.
    PayloadError
        The destination's parent directory cannot be created or is not
        a directory.
    """

    out = Path(dest)
    # Force a .bin extension: append .bin if there is a non-bin suffix,
    # or add .bin if there is no suffix at all.
    if out.suffix.lower() not in (".bin",):
        out = out.with_suffix(out.suffix + ".bin" if out.suffix else ".bin")
    if out.suffix == "":
        out = out.with_suffix(".bin")

    # Overwrite protection.
    if out.exists() and not overwrite:
        raise FileExistsError(
            f"Refusing to overwrite existing file {out}. "
            f"Pass overwrite=True (or --force on the CLI) to allow it.")

    parent = out.parent
    try:
        parent.mkdir(parents=True, exist_ok=True)
    except (NotADirectoryError, OSError) as exc:
        raise PayloadError(
            f"Cannot create destination directory {parent}: {exc}"
        ) from exc
    if parent.exists() and not parent.is_dir():
        raise PayloadError(
            f"Destination parent {parent} is not a directory.")

    # write_bytes honours the process umask (typically 022 → mode 644),
    # so the file is created non-executable by default.
    out.write_bytes(result.data)
    return out
