"""Allow ``python -m stegoscope`` to launch the CLI."""

from .cli import main

raise SystemExit(main())
