"""Core sub-package: image loading, batch scanning, cleaning and verdict aggregation."""

from .batch import BatchResult, batch_to_csv, batch_to_json, save_batch_results, scan_directory
from .cleaner import CleanerResult, clean_image
from .image_loader import ImageData, ImageLoader, UnsupportedFormatError
from .verdict import (
    AnalysisReport,
    ChannelFinding,
    ImageInfo,
    VerdictResult,
    analyze_image,
)

__all__ = [
    "ImageData",
    "ImageLoader",
    "UnsupportedFormatError",
    "AnalysisReport",
    "ChannelFinding",
    "ImageInfo",
    "VerdictResult",
    "analyze_image",
    "BatchResult",
    "batch_to_csv",
    "batch_to_json",
    "save_batch_results",
    "scan_directory",
    "CleanerResult",
    "clean_image",
]
