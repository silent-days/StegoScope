"""Batch directory scanning for StegoScope.

Scans a folder of supported PNG/BMP images, runs the full pipeline on
each, and returns ranked results.  The core scan loop is GUI-independent
so the CLI can call it directly and the GUI can wrap it in a
``QThread`` worker.  An optional ``on_progress`` callback lets callers
update a progress bar without coupling to any particular UI toolkit, and
an optional ``should_stop`` callback enables cancellation.

Resource-safety guarantees
--------------------------
* A single corrupt or oversized image never aborts the whole scan —
  per-file failures are captured and reported inline.
* ``max_files`` caps the number of images processed so a directory with
  hundreds of thousands of files cannot exhaust time/memory.
* Each image is loaded, analysed and released one at a time, so peak
  memory is bounded by the largest single image, not the batch size.
* ``should_stop`` is polled between files so a long recursive scan can
  be cancelled cleanly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from ..core.image_loader import UnsupportedFormatError
from ..core.verdict import AnalysisReport, analyze_image
from ..utils.config import AppConfig, get_config
from ..utils.limits import ImageTooLargeError
from ..utils.logger import get_logger

_log = get_logger("batch")

ProgressCb = Callable[[int, int, str], None]
StopCb = Callable[[], bool]


@dataclass
class BatchResult:
    path: str
    filename: str
    verdict: str
    score: int
    chi_max: float
    rs_imbalance: float
    error: str | None = None
    report: AnalysisReport | None = field(default=None, repr=False)


def _iter_supported(root: Path, recursive: bool,
                    extensions: Iterable[str]) -> list[Path]:
    ext_set = {e.lower() for e in extensions}
    # Accept .png/.bmp regardless of the case used in the filename.
    if recursive:
        files = (p for p in root.rglob("*") if p.is_file())
    else:
        files = (p for p in root.iterdir() if p.is_file())
    return sorted(p for p in files if p.suffix.lower() in ext_set)


def _unique_path(path: Path) -> Path:
    """Return *path* or ``<stem>_N<ext>`` if it already exists.

    Used so duplicate basenames in a recursive scan do not clobber each
    other's per-image report.
    """

    if not path.exists():
        return path
    stem, suffix, parent = path.stem, path.suffix, path.parent
    for i in range(1, 10000):
        cand = parent / f"{stem}_{i}{suffix}"
        if not cand.exists():
            return cand
    # Extremely unlikely fallback.
    return parent / f"{stem}_{abs(hash(path))}{suffix}"


def scan_directory(directory: str | Path,
                   *,
                   recursive: bool = False,
                   extract: bool = False,
                   config: AppConfig | None = None,
                   on_progress: ProgressCb | None = None,
                   should_stop: StopCb | None = None,
                   max_files: int | None = None) -> list[BatchResult]:
    """Scan *directory* and return a list of :class:`BatchResult`.

    Results are sorted by suspicion score (highest first) so the most
    suspicious images appear at the top of the list.

    Parameters
    ----------
    recursive
        Recurse into subdirectories.
    extract
        Also extract candidate payloads (slower, more memory).
    on_progress
        Called as ``on_progress(done, total, filename)`` after each file.
    should_stop
        Optional predicate polled between files; if it returns True the
        scan stops early (already-completed results are returned).
    max_files
        Optional hard cap on the number of files processed (after
        filtering to supported extensions).
    """

    cfg = config or get_config()
    root = Path(directory)
    if not root.is_dir():
        raise FileNotFoundError(f"Not a directory: {root}")

    # Map supported Pillow format names to file extensions.
    ext_map = {"PNG": ".png", "BMP": ".bmp"}
    exts = [ext_map[f] for f in cfg.supported_read_formats if f in ext_map]
    files = _iter_supported(root, recursive, exts)
    if max_files is not None and max_files > 0:
        files = files[:max_files]
    total = len(files)
    _log.info("batch scan: %d candidate file(s) in %s", total, root)

    results: list[BatchResult] = []
    for i, path in enumerate(files, start=1):
        # Cooperative cancellation — check before starting heavy work.
        if should_stop is not None and should_stop():
            _log.info("batch scan cancelled by caller at %d/%d", i - 1, total)
            break

        err: str | None = None
        report: AnalysisReport | None = None
        try:
            report = analyze_image(path, extract=extract, config=cfg)
        except UnsupportedFormatError as exc:
            err = f"unsupported/corrupt: {exc}"
        except ImageTooLargeError as exc:
            err = f"too large: {exc}"
        except FileNotFoundError as exc:
            err = f"missing: {exc}"
        except Exception as exc:  # never abort the whole batch
            err = f"{exc.__class__.__name__}: {exc}"
            _log.warning("batch: failed on %s: %s", path.name, err)

        if report is not None:
            res = BatchResult(
                path=str(path), filename=path.name,
                verdict=report.verdict.verdict,
                score=report.verdict.score,
                chi_max=report.chi.max_embedding_probability,
                rs_imbalance=report.rs.max_imbalance,
                error=err,
                report=report,
            )
        else:
            res = BatchResult(
                path=str(path), filename=path.name,
                verdict="ERROR", score=0,
                chi_max=0.0, rs_imbalance=0.0, error=err,
            )
        results.append(res)

        if on_progress is not None:
            on_progress(i, total, path.name)

    results.sort(key=lambda r: r.score, reverse=True)
    return results


def batch_to_csv(results: list[BatchResult]) -> str:
    """Serialise batch results to CSV for spreadsheet import."""

    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["rank", "filename", "path", "verdict", "score",
                "chi_max_embed_prob", "rs_max_imbalance", "error"])
    for rank, r in enumerate(results, start=1):
        w.writerow([rank, r.filename, r.path, r.verdict, r.score,
                    f"{r.chi_max:.4f}", f"{r.rs_imbalance:.4f}",
                    r.error or ""])
    return buf.getvalue()


def batch_to_json(results: list[BatchResult]) -> str:
    import json as _json
    payload = [{
        "filename": r.filename,
        "path": r.path,
        "verdict": r.verdict,
        "score": r.score,
        "chi_max_embed_prob": r.chi_max,
        "rs_max_imbalance": r.rs_imbalance,
        "error": r.error,
    } for r in results]
    return _json.dumps(payload, indent=2)


def save_batch_results(results: list[BatchResult],
                       base_path: str | Path,
                       *, overwrite: bool = False) -> dict[str, str]:
    """Write CSV and JSON sidecar files next to *base_path*.

    ``base_path`` is a stem; ``<stem>.csv`` and ``<stem>.json`` are
    written.  Returns a dict mapping format -> written path.

    Raises :class:`FileExistsError` if either target exists and
    ``overwrite`` is False.
    """

    stem = Path(base_path)
    csv_path = stem.with_suffix(".csv")
    json_path = stem.with_suffix(".json")
    for target in (csv_path, json_path):
        if target.exists() and not overwrite:
            raise FileExistsError(
                f"Refusing to overwrite existing batch result {target}. "
                f"Pass overwrite=True (or --force on the CLI) to allow it.")
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.write_text(batch_to_csv(results), encoding="utf-8")
    json_path.write_text(batch_to_json(results), encoding="utf-8")
    return {"csv": str(csv_path), "json": str(json_path)}


def unique_report_path(directory: str | Path, filename: str,
                       ext: str) -> Path:
    """Build a safe, non-clobbering per-image report path.

    Uses the image's *basename stem* (so a malicious image named
    ``../../etc/passwd.png`` cannot traverse out of *directory* —
    :py:meth:`pathlib.Path.name` already returns only the final
    component), then de-duplicates against existing files.
    """

    safe_stem = Path(filename).stem  # final component only
    target = Path(directory) / f"{safe_stem}.{ext.lstrip('.')}"
    return _unique_path(target)
