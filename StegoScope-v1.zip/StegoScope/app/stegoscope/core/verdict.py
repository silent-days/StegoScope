"""Intelligent verdict engine.

The verdict engine combines the three detectors (LSB, Chi-Square, RS)
into a single, transparent 0–100 suspicion score and a three-way
verdict: ``CLEAN``, ``SUSPICIOUS`` or ``LIKELY HIDDEN DATA``.

Design principles
-----------------
* **Transparency.**  Every score is decomposed into its per-channel
  per-detector components, and every contributing reason is spelled out
  in human language.  No black box.
* **Honesty about uncertainty.**  Statistical anomalies alone never
  produce a 100 score, and the engine always reports a *confidence*
  caveat.  Steganalysis is probabilistic.
* **Configurable thresholds.**  All cut-offs live in
  :class:`~stegoscope.utils.config.Thresholds` and can be tuned without
  touching this module.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..analysis.chi_square import ChiSquareResult, run_chi_square
from ..analysis.lsb import LSBResult, run_lsb_analysis
from ..analysis.rs_analysis import RSResult, run_rs_analysis
from ..extraction.payload import PayloadResult, extract_payload
from ..utils.config import AppConfig, get_config
from ..utils.logger import get_logger
from .image_loader import ImageLoader

_log = get_logger("verdict")


# --------------------------------------------------------------------- #
# Data model
# --------------------------------------------------------------------- #
@dataclass
class ImageInfo:
    filename: str
    path: str
    format: str
    mode: str
    width: int
    height: int
    channels: list[str]
    file_size: int
    total_pixels: int
    metadata: dict[str, Any]


@dataclass
class ChannelFinding:
    channel: str
    lsb_score: int
    chi_score: int
    rs_score: int
    channel_score: int
    notes: list[str] = field(default_factory=list)


@dataclass
class VerdictResult:
    score: int
    verdict: str
    reasons: list[str]
    channel_findings: list[ChannelFinding]
    confidence: str
    thresholds: dict[str, Any]


@dataclass
class AnalysisReport:
    app_name: str
    app_version: str
    developer: str
    timestamp: str          # ISO-8601 UTC
    info: ImageInfo
    lsb: LSBResult
    chi: ChiSquareResult
    rs: RSResult
    verdict: VerdictResult
    payload: PayloadResult | None
    limitations: list[str]


# --------------------------------------------------------------------- #
# Scoring helpers
# --------------------------------------------------------------------- #
def _lsb_score(mean: float, thr) -> int:
    dev = abs(mean - 0.5)
    if dev < thr.lsb_balance_strong:
        return 90
    if dev < thr.lsb_balance_moderate:
        return 70
    if dev < thr.lsb_balance_weak:
        return 50
    if dev < thr.lsb_balance_negligible:
        return 30
    return 10


def _chi_score(embed_prob: float) -> int:
    return int(round(min(1.0, max(0.0, embed_prob)) * 100))


def _rs_score(imbalance: float, rate: float, rate_valid: bool, thr) -> int:
    """Score the RS detector.

    The **imbalance** (``|d0 - d_-1|``) is the reliable signal — it
    grows monotonically with LSB-replacement embedding.  The
    **embedding-rate quadratic** is an approximation that frequently
    returns spurious values on natural images, so we only let it
    contribute when (a) the solver reported a valid in-range root and
    (b) the imbalance already corroborates stego activity — and even
    then we cap its contribution so a rogue rate cannot dominate.
    """

    imb_score = min(100.0, abs(imbalance) * thr.rs_imbalance_scale)
    rate_score = 0.0
    if rate_valid and rate > 0 and imb_score >= 30.0:
        rate_score = min(60.0, rate * thr.rs_rate_scale)
    return int(round(max(imb_score, rate_score)))


def _confidence_label(score: int, agreeing_channels: int,
                      total_channels: int) -> str:
    """A plain-language caveat about how much weight to put on the
    verdict."""

    if total_channels == 0:
        return "No channels were analysed; verdict is unreliable."
    ratio = agreeing_channels / total_channels
    if score >= 70 and ratio >= 0.5:
        return ("HIGH — multiple independent detectors and channels agree, "
                "but statistical steganalysis is never a proof of payload.")
    if score >= 70:
        return ("MEDIUM — strong signal on a single detector/channel. "
                "Confirm with the Payload Inspector before drawing conclusions.")
    if score >= 40:
        return ("LOW — anomalies are present but weak. Treat as a prompt to "
                "investigate further, not as a conclusion.")
    return ("LOW — no detector reports a strong anomaly. A CLEAN verdict "
            "is not proof that no payload exists; only that none was found.")


# --------------------------------------------------------------------- #
# Verdict assembly
# --------------------------------------------------------------------- #
def _build_verdict(lsb: LSBResult, chi: ChiSquareResult,
                   rs: RSResult, cfg: AppConfig) -> VerdictResult:
    thr = cfg.thresholds

    findings: list[ChannelFinding] = []
    reasons: list[str] = []
    high_channels = 0

    # Align channels across detectors by name (they share an ordering
    # because they all iterate image.channel_arrays in the same order).
    lsb_by = {c.channel: c for c in lsb.channels}
    chi_by = {c.channel: c for c in chi.channels}
    rs_by = {c.channel: c for c in rs.channels}
    channel_names = list(lsb_by.keys())

    for name in channel_names:
        l = lsb_by[name]
        c = chi_by[name]
        r = rs_by[name]

        ls = _lsb_score(l.lsb_mean, thr)
        cs = _chi_score(c.embedding_probability)
        rs_ = _rs_score(r.imbalance, r.estimated_rate, r.rate_valid, thr)
        channel_score = int(round(
            thr.weight_lsb * ls + thr.weight_chi * cs + thr.weight_rs * rs_
        ))
        channel_score = max(0, min(100, channel_score))

        notes: list[str] = []
        if c.insufficient_sample:
            notes.append(
                f"Chi-Square test inconclusive on {name} (only "
                f"{c.sample_pairs} populated value-pairs / low expected "
                f"counts); embedding probability reported as 0 (no "
                f"positive evidence), not as 'clean'."
            )
        if ls >= 70:
            notes.append(
                f"LSB balance near 0.5 (mean={l.lsb_mean:.4f}, "
                f"{l.one_pct:.2f}% ones) — consistent with random data "
                f"(weak signal on its own; corroborated below by Chi/RS)."
            )
        if cs >= 70:
            notes.append(
                f"Chi-Square embedding-probability heuristic {c.embedding_probability:.2f} "
                f"(statistic={c.statistic:.1f}, dof={c.dof}); pair histogram "
                f"is consistent with random LSB replacement."
            )
        if rs_ >= 70:
            extra = ""
            if r.rate_valid and r.estimated_rate > 0:
                extra = (f" (estimated rate ≈ {r.estimated_rate:.2f}, "
                         f"≈ {r.estimated_payload_bytes:,} bytes in {name})")
            notes.append(
                f"RS imbalance {r.imbalance:.4f} exceeds clean baseline"
                f"{extra}; d0={r.d0:.4f}, d_-1={r.d_neg1:.4f}."
            )

        findings.append(ChannelFinding(
            channel=name, lsb_score=ls, chi_score=cs, rs_score=rs_,
            channel_score=channel_score, notes=notes,
        ))
        if channel_score >= 70:
            high_channels += 1
        if notes:
            reasons.append(f"[{name}] " + " ".join(notes))

    # Aggregate: mean of channel scores, but never ignore a strong
    # single-channel signal entirely.
    if findings:
        mean_score = int(round(sum(f.channel_score for f in findings) / len(findings)))
        max_score = max(f.channel_score for f in findings)
    else:
        mean_score = 0
        max_score = 0

    overall = mean_score
    # If at least one channel is strongly suspicious, lift the overall
    # score part-way toward it so a single-channel payload is not masked
    # by averaging.
    if max_score >= 70:
        overall = max(overall, int(round(0.7 * mean_score + 0.3 * max_score)))
    overall = max(0, min(100, overall))

    label = cfg.verdict_label(overall)
    if overall >= cfg.thresholds.suspicious_max:
        reasons.append(
            "Aggregated suspicion exceeds the LIKELY HIDDEN DATA threshold. "
            "This is a statistical indicator, not a confirmed payload."
        )
    elif overall > cfg.thresholds.clean_max:
        reasons.append(
            "Aggregated suspicion falls in the SUSPICIOUS band. Manual "
            "review with the Payload Inspector is recommended."
        )
    else:
        if reasons:
            reasons.append(
                "Minor anomalies detected but below the SUSPICIOUS threshold."
            )
        else:
            reasons.append(
                "No detector reports a statistically significant anomaly."
            )

    confidence = _confidence_label(overall, high_channels, len(findings))

    thr_dump = {
        "clean_max": thr.clean_max,
        "suspicious_max": thr.suspicious_max,
        "weight_lsb": thr.weight_lsb,
        "weight_chi": thr.weight_chi,
        "weight_rs": thr.weight_rs,
    }

    return VerdictResult(
        score=overall,
        verdict=label,
        reasons=reasons,
        channel_findings=findings,
        confidence=confidence,
        thresholds=thr_dump,
    )


# --------------------------------------------------------------------- #
# Limitations (always reported)
# --------------------------------------------------------------------- #
_LIMITATIONS = [
    "StegoScope detects LSB-replacement steganography. LSB matching (±1) "
    "and adaptive / model-based steganography may evade detection.",
    "Statistical detectors assume natural photographic content. "
    "Synthetic, flat or highly compressed-source images produce noisy "
    "scores even when clean.",
    "A CLEAN verdict means no anomaly was found — it is not proof that "
    "no payload exists.",
    "Extracted payload bytes are CANDIDATE data, never confirmed hidden "
    "content, and are treated as untrusted throughout.",
    "The RS embedding-rate estimate is an approximation; out-of-range "
    "values are reported as 0 and flagged as invalid.",
]


# --------------------------------------------------------------------- #
# Top-level entry point
# --------------------------------------------------------------------- #
def analyze_image(path: str | Path,
                  *,
                  extract: bool = False,
                  max_payload_bytes: int | None = None,
                  extract_channels: list[str] | None = None,
                  extract_bit_order: str = "msb",
                  extract_interleave: bool = False,
                  config: AppConfig | None = None) -> AnalysisReport:
    """Run the full StegoScope pipeline against *path*.

    Parameters
    ----------
    path
        Path to a PNG or BMP image.
    extract
        If True, also extract a candidate LSB payload (see
        :mod:`stegoscope.extraction.payload`).
    max_payload_bytes
        Optional cap on extracted payload size.
    extract_channels
        Optional channel subset/order for extraction (default: all
        image channels in R,G,B,A order — the assignment-required order).
    extract_bit_order
        ``"msb"`` (default) or ``"lsb"``.
    extract_interleave
        If True, extract bit-round-robin across channels instead of
        channel-sequential.  Default False (assignment-required).
    config
        Optional configuration override.

    Returns
    -------
    AnalysisReport
    """

    cfg = config or get_config()
    loader = ImageLoader(supported_formats=cfg.supported_read_formats)
    image = loader.load(path)

    lsb = run_lsb_analysis(image)
    chi = run_chi_square(image)
    rs = run_rs_analysis(image)
    verdict = _build_verdict(lsb, chi, rs, cfg)

    payload = None
    if extract:
        cap = max_payload_bytes or cfg.max_payload_extract_bytes
        try:
            payload = extract_payload(
                image, max_bytes=cap,
                channels=extract_channels,
                bit_order=extract_bit_order,
                interleave=extract_interleave,
            )
        except Exception as exc:  # never let extraction abort the report
            _log.warning("payload extraction failed for %s: %s",
                         image.filename, exc)
            payload = None

    info = ImageInfo(
        filename=image.filename,
        path=str(image.path),
        format=image.format,
        mode=image.mode,
        width=image.width,
        height=image.height,
        channels=list(image.channels),
        file_size=image.file_size,
        total_pixels=image.total_pixels,
        metadata=dict(image.metadata),
    )

    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")

    _log.info("analyzed %s: score=%d verdict=%s",
              image.filename, verdict.score, verdict.verdict)

    return AnalysisReport(
        app_name=cfg.app_name,
        app_version=cfg.app_version,
        developer=cfg.developer,
        timestamp=timestamp,
        info=info,
        lsb=lsb,
        chi=chi,
        rs=rs,
        verdict=verdict,
        payload=payload,
        limitations=list(_LIMITATIONS),
    )


def report_to_dict(report: AnalysisReport) -> dict[str, Any]:
    """Serialise an :class:`AnalysisReport` to a plain dict (for JSON)."""

    from dataclasses import asdict
    return asdict(report)


# Re-export analyze_image's dependency on the loader at module level so
# ``from stegoscope.core.verdict import ImageLoader`` works for callers.
__all__ = [
    "ImageInfo",
    "ChannelFinding",
    "VerdictResult",
    "AnalysisReport",
    "analyze_image",
    "report_to_dict",
]
