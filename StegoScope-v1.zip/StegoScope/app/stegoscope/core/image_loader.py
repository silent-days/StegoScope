"""Image loading and validation for StegoScope.

StegoScope only analyses *lossless* imagery — PNG and BMP — because
lossy compression (JPEG, WebP) destroys the LSB structure that every
detector in this suite relies upon.  Attempting to analyse a lossy
format would produce misleading statistics, so we refuse them up-front
with a clear error rather than silently returning nonsense.

Security / resource model
-------------------------
The loader enforces resource limits **before** any expensive operation:

1. The on-disk file size is checked from ``stat()`` *before* the file is
   even handed to Pillow, so a 10 GiB blob never reaches the decoder.
2. Pillow's own decompression-bomb guard (``Image.MAX_IMAGE_PIXELS``) is
   pinned to the configured pixel ceiling, so a tiny PNG whose decoded
   canvas is enormous is rejected at ``Image.open`` time — before a
   single pixel is materialised.
3. The decoded ``width × height`` is re-checked against
   :func:`~stegoscope.utils.limits.enforce_limits` from the image header
   (available without decoding the pixel stream) before any conversion or
   ``np.asarray`` call.

Information-preservation model
------------------------------
The loader **never silently destroys original LSB information**:

* Supported modes (``L``, ``LA``, ``RGB``, ``RGBA``) are read in their
  native representation — no conversion, no resampling.
* Palette (``P``) images are read as their raw palette-index plane.  The
  index values are exactly what a palette-image steganographer would
  modify, so analysing the index plane preserves the original LSBs.
  Converting ``P`` → ``RGB`` would replace indices with palette colours
  and *change* the LSB structure — we deliberately do not do that.
* 16-bit (``I``, ``I;16``…) and exotic modes (``CMYK``, ``YCbCr``,
  ``F``, ``1``…) require a lossy conversion to become analysable, which
  would alter the LSB plane.  They are refused with a clear
  :class:`UnsupportedFormatError` rather than silently normalised.

The loader never modifies the source file: it opens the image in-place,
copies the decoded pixel buffer into a NumPy array, and closes the file
handle.  All subsequent analysis operates on the in-memory copy.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import warnings as _warnings
import hashlib
from PIL import Image, UnidentifiedImageError
from PIL import ExifTags
from PIL import ImageFile
# F14 fix: Pillow only raises a Warning (not an Error) when the decoded
# pixel count is between MAX_IMAGE_PIXELS and 2*MAX_IMAGE_PIXELS. Promote
# that warning to an error so oversized images are rejected in *both*
# the hard-bomb zone and the warning zone — otherwise a 90-Mpixel PNG
# (above the 60-Mpixel ceiling but below 120-Mpixel) would load with a
# silent warning and bypass the configured pixel ceiling.
_warnings.simplefilter("error", Image.DecompressionBombWarning)

from ..utils.config import get_config
from ..utils.limits import ImageLimits, ImageTooLargeError, enforce_limits
from ..utils.logger import get_logger

_log = get_logger("loader")

# Canonical channel ordering for each Pillow mode we support natively.
# "P" is the palette-index plane (single channel of index values).
_CHANNEL_NAMES: dict[str, tuple[str, ...]] = {
    "L": ("L",),
    "LA": ("L", "A"),
    "RGB": ("R", "G", "B"),
    "RGBA": ("R", "G", "B", "A"),
    "P": ("P",),
}

# Modes that would require a lossy / value-altering conversion to analyse.
# We refuse them explicitly so the original LSB information is never
# silently destroyed.  Callers can convert such images externally and
# re-save as PNG/BMP in an analysable mode if they accept the trade-off.
_UNSUPPORTED_MODES = {
    "1": "1-bit bilevel (convert externally to 8-bit grayscale PNG/BMP)",
    "I": "16-bit grayscale integer (LSB analysis is out of scope; convert externally if required)",
    "I;16": "16-bit grayscale integer (LSB analysis is out of scope; convert externally if required)",
    "I;16B": "16-bit big-endian grayscale (unsupported)",
    "I;16L": "16-bit little-endian grayscale (unsupported)",
    "I;16N": "16-bit native-endian grayscale (unsupported)",
    "F": "32-bit floating-point (unsupported)",
    "CMYK": "CMYK (convert externally to RGB PNG/BMP if required)",
    "YCbCr": "YCbCr (convert externally to RGB PNG/BMP if required)",
    "HSV": "HSV (unsupported)",
}


class UnsupportedFormatError(Exception):
    """Raised when the user supplies a format/mode StegoScope will not analyse."""


@dataclass
class ImageData:
    """In-memory representation of a decoded image ready for analysis."""

    path: Path
    filename: str
    format: str          # e.g. "PNG", "BMP"
    mode: str            # e.g. "RGB", "RGBA", "L", "P"
    width: int
    height: int
    channels: tuple[str, ...]
    file_size: int
    array: np.ndarray = field(repr=False)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def channel_arrays(self) -> dict[str, np.ndarray]:
        """Return a dict mapping channel name -> 2-D uint8 array."""
        return {
            name: np.ascontiguousarray(self.array[..., idx])
            for idx, name in enumerate(self.channels)
        }

    @property
    def total_pixels(self) -> int:
        return self.width * self.height


class ImageLoader:
    """Load and validate PNG/BMP images into :class:`ImageData`."""

    def __init__(self, supported_formats: tuple[str, ...] | None = None,
                 limits: ImageLimits | None = None) -> None:
        cfg = get_config()
        self.supported = supported_formats or cfg.supported_read_formats
        self._fmt_set = {f.upper() for f in self.supported}
        self._limits = limits or ImageLimits(
            max_pixels=cfg.max_image_pixels)
        # Pin Pillow's decompression-bomb guard to our pixel ceiling so a
        # weaponised "tiny file / huge canvas" PNG is rejected at open
        # time, before any pixel buffer is allocated.  This is a process
        # global, but StegoScope is a single-purpose process so the side
        # effect is acceptable and desirable.
        Image.MAX_IMAGE_PIXELS = self._limits.max_pixels
        # Truncated files should fail loudly, not silently produce partial
        # pixel data that would corrupt the statistics.
        ImageFile.LOAD_TRUNCATED_IMAGES = False

    # ------------------------------------------------------------------ #
    def load(self, path: str | Path) -> ImageData:
        """Load *path* into an :class:`ImageData`.

        Raises
        ------
        FileNotFoundError
            The path does not exist.
        UnsupportedFormatError
            The file is not a PNG/BMP, is corrupt, or is in an
            unsupported colour mode (16-bit, CMYK, …).
        ImageTooLargeError
            The on-disk file or the decoded pixel count exceeds the
            configured ceiling.
        """

        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"No such file: {p}")
        if not p.is_file():
            raise UnsupportedFormatError(f"Not a regular file: {p}")

        file_size = p.stat().st_size

        # 1. Cheap on-disk size guard — refuses huge files before Pillow
        #    even touches them.  This bounds I/O and decompressor input.
        if file_size > self._limits.max_file_bytes:
            _log.warning("rejecting image: file size %d > %d",
                         file_size, self._limits.max_file_bytes)
            raise ImageTooLargeError(
                f"Source file is {file_size:,} bytes which exceeds the "
                f"{self._limits.max_file_bytes:,} byte ceiling "
                f"({self._limits.max_file_bytes / (1024 * 1024):.0f} MiB)."
            )

        try:
            with Image.open(p) as img:
                fmt = (img.format or "").upper()
                if fmt not in self._fmt_set:
                    raise UnsupportedFormatError(
                        f"Format '{fmt or 'unknown'}' is not supported. "
                        f"StegoScope analyses lossless "
                        f"{', '.join(self.supported)} only — lossy "
                        f"compression destroys LSB structure and would "
                        f"produce misleading statistics."
                    )

                mode = img.mode
                width, height = img.size

                # 2. Decoded-dimension guard from the header.  For PNG/BMP
                #    the dimensions are known without decoding the pixel
                #    stream, so this runs before any heavy allocation.
                enforce_limits(width, height, file_size, self._limits)

                # 3. Mode handling — NO conversion for supported modes, so
                #    the original LSB plane is never altered before
                #    analysis.  Exotic/16-bit modes are refused outright.
                if mode in _UNSUPPORTED_MODES:
                    hint = _UNSUPPORTED_MODES[mode]
                    raise UnsupportedFormatError(
                        f"Image colour mode '{mode}' is not supported: "
                        f"{hint}. StegoScope analyses L / LA / RGB / RGBA "
                        f"(and palette-index P) imagery only, because "
                        f"converting '{mode}' would alter the original "
                        f"LSB information."
                    )
                if mode not in _CHANNEL_NAMES:
                    raise UnsupportedFormatError(
                        f"Image colour mode '{mode}' is not supported. "
                        f"StegoScope analyses L / LA / RGB / RGBA (and "
                        f"palette-index P) imagery only."
                    )
                channels = _CHANNEL_NAMES[mode]

                # 4. Decode the pixel buffer into a NumPy array.  This is
                #    the first operation that materialises every pixel,
                #    and it runs only after all guards have passed.
                arr = np.asarray(img, dtype=np.uint8)
                if arr.ndim == 2:
                    # Single-channel (L / P) — add channel axis for
                    # uniform indexing downstream.
                    arr = arr[:, :, None]
                if arr.ndim != 3 or arr.shape[2] != len(channels):
                    raise UnsupportedFormatError(
                        f"Unexpected pixel buffer shape {arr.shape} for "
                        f"mode '{mode}' (expected {len(channels)} "
                        f"channels). The file may be corrupt."
                    )
                # Ensure a writable, contiguous buffer so downstream
                # analysis can operate in place without touching the
                # Pillow-internal read-only array.
                arr = np.ascontiguousarray(arr)

                metadata = self._extract_metadata(img, fmt)
        except UnidentifiedImageError as exc:
            raise UnsupportedFormatError(
                f"Pillow could not identify the image at {p}: {exc}"
            ) from exc
        except ImageTooLargeError:
            raise
        except UnsupportedFormatError:
            raise
        except Image.DecompressionBombError as exc:
            # PIL's guard fired (decoded dimensions > MAX_IMAGE_PIXELS).
            raise ImageTooLargeError(
                f"Image {p.name} triggered Pillow's decompression-bomb "
                f"protection (decoded canvas exceeds "
                f"{self._limits.max_pixels:,} pixels). "
                f"{exc}"
            ) from exc
        except Image.DecompressionBombWarning as exc:
            # F14 fix: the "warning zone" (between MAX_IMAGE_PIXELS and
            # 2*MAX_IMAGE_PIXELS) is now promoted to an error at module
            # import time, and we translate it to ImageTooLargeError so
            # callers see the same exception type for both zones.
            raise ImageTooLargeError(
                f"Image {p.name} exceeded the configured pixel ceiling "
                f"({self._limits.max_pixels:,} pixels) and was rejected. "
                f"{exc}"
            ) from exc
        except Exception as exc:  # truncated / corrupt files
            raise UnsupportedFormatError(
                f"Failed to decode {p}: {exc.__class__.__name__}: {exc}"
            ) from exc

        _log.debug("loaded %s: %s %dx%d %s (%d channels, %d bytes)",
                   p.name, fmt, width, height, mode, len(channels), file_size)

        return ImageData(
            path=p,
            filename=p.name,
            format=fmt,
            mode=mode,
            width=width,
            height=height,
            channels=channels,
            file_size=file_size,
            metadata=metadata,
            array=arr,
        )

    # ------------------------------------------------------------------ #
    @staticmethod
    def _extract_metadata(img: Image.Image, fmt: str) -> dict[str, Any]:
        """Return a complete JSON-safe view of container metadata.

        Pixel data is never included. Binary fields such as ICC/EXIF blobs
        are represented by their length and SHA-256, while textual and scalar
        fields remain readable for forensic inspection.
        """
        def safe(value: Any) -> Any:
            if isinstance(value, bytes):
                return {"type": "bytes", "length": len(value),
                        "sha256": hashlib.sha256(value).hexdigest()}
            if isinstance(value, (str, int, float, bool)) or value is None:
                return value
            if isinstance(value, (list, tuple)):
                return [safe(v) for v in value]
            if isinstance(value, dict):
                return {str(k): safe(v) for k, v in value.items()}
            return repr(value)

        info = dict(img.info or {})
        meta: dict[str, Any] = {
            "container": fmt,
            "Pillow mode": img.mode,
            "Pillow size": {"width": img.width, "height": img.height},
            "info": {str(key): safe(value) for key, value in info.items()},
        }
        try:
            exif = img.getexif()
            if exif:
                meta["EXIF"] = {
                    str(ExifTags.TAGS.get(key, key)): safe(value)
                    for key, value in exif.items()
                }
        except Exception as exc:
            meta["EXIF error"] = f"{exc.__class__.__name__}: {exc}"
        if fmt == "BMP":
            meta["header"] = "BMP/DIB"
        return meta
