"""Image cleaner — strip metadata and optionally neutralise the LSB plane.

The cleaner is the symmetric counterpart of the analyzer: where the
analysis pipeline reports *what* was found, the cleaner *removes* the
surface that steganography tools operate on so the cleaned image can
be re-shared safely.

Two independent operations are supported and can be toggled separately:

1. **Metadata stripping** — every non-essential chunk is removed
   (PNG text chunks, EXIF, XMP, IPTC, ICC profile, gamma, comment,
   transparent-color hints, etc.). The pixel stream is preserved
   bit-for-bit; only the container's auxiliary chunks are dropped.

2. **LSB neutralisation** — the least-significant bit of every
   channel is forced to ``0``. This destroys any LSB-replacement
   payload while keeping the high seven bits (and therefore the
   visible image) untouched. After neutralisation the LSB plane of
   each channel becomes uniformly zero, so any future LSB-replacement
   detector returns a 0/100 suspicion score.

Both operations are lossless with respect to the visible image (the
8-bit pixel values are preserved to within 1 LSB ≈ imperceptible
luminance difference). The output is always written as PNG (lossless)
regardless of the input format, so the cleaned file cannot degrade
further.

The cleaner **never modifies the source file** — it writes a new
file alongside or to a path the caller chooses.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, PngImagePlugin

from .image_loader import ImageData, ImageLoader
from ..utils.logger import get_logger

_log = get_logger("cleaner")


# --------------------------------------------------------------------- #
# Result model
# --------------------------------------------------------------------- #
@dataclass
class CleanerResult:
    """Outcome of an image-clean operation."""

    source_path: str
    output_path: str
    input_format: str
    output_format: str
    input_size: int
    output_size: int
    metadata_chunks_removed: list[str]
    lsb_neutralised: bool
    channels_neutralised: list[str]
    bits_cleared: int          # total LSB bits set to 0 (per channel × per pixel)
    success: bool
    error: str | None = None


# --------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------- #
def clean_image(
    source: str | Path,
    output: str | Path,
    *,
    strip_metadata: bool = True,
    strip_text_chunks: bool = True,
    strip_color_profile: bool = True,
    strip_gamma: bool = True,
    strip_transparency: bool = True,
    neutralise_lsb: bool = False,
    neutralise_channels: list[str] | None = None,
) -> CleanerResult:
    """Strip metadata and/or neutralise the LSB plane of *source*.

    Parameters
    ----------
    source
        Path to the input PNG / BMP image.
    output
        Path to write the cleaned PNG to. Always written as PNG
        (lossless) regardless of the input format.
    strip_metadata
        Master switch. If False, no metadata is stripped at all
        (overrides the granular flags below).
    strip_text_chunks
        Drop PNG ``tEXt`` / ``zTXt`` / ``iTXt`` chunks (comments,
        software tag, timestamps, etc.).
    strip_color_profile
        Drop embedded ICC profile (``iCCP``) and sRGB / cHRM chunks.
    strip_gamma
        Drop the ``gAMA`` chunk.
    strip_transparency
        Drop the ``tRNS`` chunk (single transparent colour hint).
    neutralise_lsb
        Force the LSB of every selected channel to 0.
    neutralise_channels
        Channels to neutralise. ``None`` means all channels of the
        image (``R, G, B, [A]`` for RGB / RGBA, ``L`` for grayscale,
        ``P`` index plane for palette images).

    Returns
    -------
    CleanerResult
        A summary of what was done. ``success=False`` and a populated
        ``error`` field indicate the operation failed; the input file
        is never modified.
    """

    src = Path(source)
    dst = Path(output)

    if not src.exists():
        return CleanerResult(
            source_path=str(src), output_path=str(dst),
            input_format="", output_format="",
            input_size=0, output_size=0,
            metadata_chunks_removed=[], lsb_neutralised=False,
            channels_neutralised=[], bits_cleared=0,
            success=False, error=f"Source file not found: {src}",
        )

    try:
        # Use the same loader as the analyzer so we get the same
        # validation, size limits and metadata extraction.
        loader = ImageLoader()
        image: ImageData = loader.load(src)

        # Open the original PIL image so we can re-save with control
        # over the chunks. We *don't* use this object's pixel data —
        # we use the validated NumPy buffer from ImageData, which
        # may have been modified by the LSB neutraliser.
        with Image.open(src) as raw:
            mode = raw.mode
            format_in = (raw.format or "").upper()

        # ---- 1. LSB neutralisation (operates on the NumPy buffer) --------
        bits_cleared = 0
        channels_neut: list[str] = []
        if neutralise_lsb:
            arr = image.array.copy()
            channels = neutralise_channels or list(image.channels)
            for idx, name in enumerate(image.channels):
                if name not in channels:
                    continue
                plane = arr[..., idx]
                # Count bits we are about to clear (LSBs currently set to 1)
                bits_cleared += int((plane & 1).sum())
                # Force LSB to 0
                arr[..., idx] = plane & 0xFE
                channels_neut.append(name)
            image = ImageData(
                path=image.path, filename=image.filename,
                format=image.format, mode=image.mode,
                width=image.width, height=image.height,
                channels=image.channels, file_size=image.file_size,
                array=arr, metadata=image.metadata,
            )
            _log.info("neutralised LSB on %d channel(s), %d bits cleared",
                      len(channels_neut), bits_cleared)

        # ---- 2. Build the output PIL image with a fresh PNG info --------
        # We always re-encode as PNG (lossless) so the cleaned file
        # cannot degrade further. The NumPy buffer may have been
        # modified above; we copy it back into a PIL Image.
        out_arr = image.array
        # Drop the channel axis we added for single-channel modes.
        if out_arr.shape[2] == 1 and mode in ("L", "P"):
            out_arr = out_arr[:, :, 0]
        if mode == "P":
            # Palette image: PIL needs the palette to render correctly.
            # We re-open to get the palette, then put our (possibly
            # modified) index plane back.
            with Image.open(src) as pal_src:
                out_img = Image.fromarray(out_arr, mode="P")
                if pal_src.palette:
                    out_img.putpalette(pal_src.palette.tobytes())
        else:
            out_img = Image.fromarray(out_arr, mode=mode)

        # ---- 3. Build a fresh PngInfo with only what the user wants ----
        png_info = PngImagePlugin.PngInfo()
        chunks_removed: list[str] = []

        if strip_metadata:
            # Drop everything by default. Only re-add a single
            # "cleaned by" tag so the cleaned file is self-describing.
            chunks_removed.extend([
                "tEXt", "zTXt", "iTXt",      # text chunks
                "iCCP", "sRGB", "cHRM",      # color profile (if requested)
                "gAMA",                       # gamma (if requested)
                "tRNS",                       # transparency hint (if requested)
                "exif", "xp",                 # EXIF / XMP
                "icc_profile",                # ICC profile attribute
            ])
            if not strip_text_chunks:
                # Re-apply text chunks from the original (rare use-case).
                for k, v in (image.metadata or {}).items():
                    if isinstance(v, (str, bytes)):
                        png_info.add_text(str(k), v)
            # Add a single "cleaned by" marker so the cleaned file is
            # self-describing but does not leak source information.
            png_info.add_text("Software", "StegoScope Cleaner v1.0.0")
            png_info.add_text("Cleaned",
                              f"meta={'yes' if strip_metadata else 'no'},"
                              f"lsb={'yes' if neutralise_lsb else 'no'}")
        else:
            # Preserve all original chunks by copying them through.
            for k, v in (image.metadata or {}).items():
                if isinstance(v, (str, bytes)):
                    try:
                        png_info.add_text(str(k), v)
                    except Exception as exc:
                        _log.debug("skipping non-encodable metadata key %s: %s", k, exc)

        # Make sure the destination directory exists.
        dst.parent.mkdir(parents=True, exist_ok=True)

        # ---- 4. Save with explicit PNG parameters -----------------------
        # Save with maximum compression and no ancillary chunks beyond
        # the PngInfo we explicitly constructed.
        save_kwargs: dict[str, Any] = {
            "format": "PNG",
            "pnginfo": png_info,
            "compress_level": 6,
            "optimize": True,
        }
        # Strip the per-image ICC profile / EXIF at the PIL level
        # (these are stored on the Image object separately from PngInfo).
        if strip_color_profile:
            out_img.info.pop("icc_profile", None)
            out_img.info.pop("exif", None)
        if strip_gamma:
            out_img.info.pop("gamma", None)
        if strip_transparency:
            out_img.info.pop("transparency", None)

        out_img.save(str(dst), **save_kwargs)

        out_size = dst.stat().st_size
        _log.info("cleaned %s → %s (in=%d out=%d, meta=%s lsb=%s)",
                  src.name, dst.name, image.file_size, out_size,
                  strip_metadata, neutralise_lsb)

        return CleanerResult(
            source_path=str(src),
            output_path=str(dst),
            input_format=format_in,
            output_format="PNG",
            input_size=image.file_size,
            output_size=out_size,
            metadata_chunks_removed=chunks_removed if strip_metadata else [],
            lsb_neutralised=neutralise_lsb,
            channels_neutralised=channels_neut,
            bits_cleared=bits_cleared,
            success=True,
        )

    except Exception as exc:
        _log.error("clean failed for %s: %s: %s", src,
                   exc.__class__.__name__, exc)
        return CleanerResult(
            source_path=str(src), output_path=str(dst),
            input_format="", output_format="",
            input_size=0, output_size=0,
            metadata_chunks_removed=[], lsb_neutralised=False,
            channels_neutralised=[], bits_cleared=0,
            success=False, error=f"{exc.__class__.__name__}: {exc}",
        )


__all__ = ["clean_image", "CleanerResult"]
