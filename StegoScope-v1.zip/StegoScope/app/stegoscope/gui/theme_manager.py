"""Qt-aware theme manager — switches between LIGHT and DARK at runtime.

A single :class:`ThemeManager` instance lives at module level (accessed
via :func:`get_theme_manager`). When the user calls
:meth:`ThemeManager.toggle` (or :meth:`set_mode`), it:

1. Updates the active palette in :mod:`theme`.
2. Re-applies the application-wide stylesheet.
3. Emits the ``theme_changed`` Qt signal so every widget that
   registered for refresh notifications can repaint itself.

Widgets that paint custom colors (the nav button, the splash, the
matplotlib canvases) connect to ``theme_changed`` and refresh their
cached colors / figures on every switch.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from . import theme as _theme


class ThemeManager(QObject):
    """Singleton Qt-aware wrapper around :mod:`theme`."""

    theme_changed = Signal(str)   # emits the new mode ("light" or "dark")

    _instance: "ThemeManager | None" = None

    def __init__(self, app=None) -> None:
        super().__init__()
        self._app = app

    # ---- public API --------------------------------------------------
    def set_mode(self, mode: _theme.Mode) -> None:
        if mode == _theme.get_mode():
            return
        _theme.set_mode(mode)
        self._reapply_qss()
        self.theme_changed.emit(mode.value)

    def toggle(self) -> None:
        """Flip between LIGHT and DARK."""
        new = _theme.Mode.DARK if _theme.get_mode() == _theme.Mode.LIGHT \
            else _theme.Mode.LIGHT
        self.set_mode(new)

    def current_mode(self) -> _theme.Mode:
        return _theme.get_mode()

    def current_palette(self) -> dict[str, str]:
        return _theme.get_palette()

    def current_qss(self) -> str:
        return _theme.get_qss()

    def set_app(self, app) -> None:
        """Bind the QApplication instance so we can re-apply the QSS."""
        self._app = app
        # Apply once now.
        app.setStyleSheet(_theme.get_qss())

    # ---- internals ---------------------------------------------------
    def _reapply_qss(self) -> None:
        if self._app is None:
            return
        self._app.setStyleSheet(_theme.get_qss())


def get_theme_manager() -> ThemeManager:
    """Return the singleton ThemeManager instance."""
    if ThemeManager._instance is None:
        ThemeManager._instance = ThemeManager()
    return ThemeManager._instance


__all__ = ["ThemeManager", "get_theme_manager"]
