"""GUI sub-package for StegoScope.

Sets the matplotlib backend to QtAgg on import so that figures created
by :mod:`stegoscope.visualization` can be embedded via
``FigureCanvasQTAgg``.
"""

import matplotlib
matplotlib.use("QtAgg")  # must precede pyplot / FigureCanvas import

from .main_window import MainWindow, launch_gui

__all__ = ["MainWindow", "launch_gui"]
