"""Background workers for the StegoScope GUI.

Running the detection engine on the GUI thread would freeze the
interface for large images or batch scans, so all heavy work is moved
onto :class:`QThread` subclasses that emit Qt signals when done.
"""

from __future__ import annotations

import threading
from pathlib import Path

from PySide6.QtCore import QThread, Signal

from ..core.batch import scan_directory
from ..core.verdict import analyze_image


class AnalyzeWorker(QThread):
    """Analyse a single image off the UI thread."""

    finished_report = Signal(object)   # AnalysisReport
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, path: str, *, extract: bool = False,
                 max_payload_bytes: int | None = None) -> None:
        super().__init__()
        self._path = path
        self._extract = extract
        self._max_payload_bytes = max_payload_bytes

    def run(self) -> None:
        try:
            self.progress.emit(f"Analyzing {Path(self._path).name} …")
            report = analyze_image(
                self._path,
                extract=self._extract,
                max_payload_bytes=self._max_payload_bytes,
            )
            self.finished_report.emit(report)
        except Exception as exc:
            self.failed.emit(f"{exc.__class__.__name__}: {exc}")


class BatchWorker(QThread):
    """Scan a directory off the UI thread.

    Supports cooperative cancellation: call :meth:`cancel` and the scan
    loop stops before starting the next file (already-completed results
    are still emitted).
    """

    progress = Signal(int, int, str)    # done, total, filename
    finished_batch = Signal(object)     # list[BatchResult]
    failed = Signal(str)

    def __init__(self, directory: str, *, recursive: bool = False,
                 extract: bool = False, max_files: int | None = None) -> None:
        super().__init__()
        self._directory = directory
        self._recursive = recursive
        self._extract = extract
        self._max_files = max_files
        self._stop = threading.Event()

    def cancel(self) -> None:
        """Request the scan to stop after the current file."""
        self._stop.set()

    def run(self) -> None:
        try:
            results = scan_directory(
                self._directory,
                recursive=self._recursive,
                extract=self._extract,
                max_files=self._max_files,
                on_progress=lambda d, t, n: self.progress.emit(d, t, n),
                should_stop=self._stop.is_set,
            )
            self.finished_batch.emit(results)
        except Exception as exc:
            self.failed.emit(f"{exc.__class__.__name__}: {exc}")
