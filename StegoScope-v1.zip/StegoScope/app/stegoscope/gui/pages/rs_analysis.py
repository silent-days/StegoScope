"""RS Analysis page."""

from __future__ import annotations

from PySide6.QtWidgets import (QHeaderView, QLabel,
                                QTableWidget, QTableWidgetItem)

from ..theme import APP_COLORS
from ..widgets import Card, MatplotlibCanvas
from . import BasePage
from ...visualization.plots import draw_rs_chart


class RSAnalysisPage(BasePage):
    title = "RS Analysis"
    subtitle = ("Fridrich-Goljan-Du RS-analysis: regular/singular group "
                "fractions under the positive (M) and negative (−M) masks.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        stats_card = Card("RS statistics per channel")
        self.table = QTableWidget(0, 10)
        self.table.setHorizontalHeaderLabels(
            ["Channel", "R_M", "S_M", "R_−M", "S_−M",
             "d0", "d_−1", "|imbalance|", "est. rate", "valid"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for i in range(10):
            self.table.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.ResizeMode.Stretch if i == 0 else
                QHeaderView.ResizeMode.ResizeToContents)
        stats_card.addWidget(self.table)
        self.addContent(stats_card)

        self.note_lbl = QLabel("")
        self.note_lbl.setWordWrap(True)
        self.note_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};"
                                     f"font-size:11px;")
        stats_card.addWidget(self.note_lbl)

        chart_card = Card("Regular / singular group fractions")
        self.canvas = MatplotlibCanvas(parent=self)
        chart_card.addWidget(self.canvas)
        self.addContent(chart_card)

        self._refresh_empty()

    def _refresh_empty(self) -> None:
        self.table.setRowCount(0)
        self.note_lbl.setText("")

    def _on_report(self, report) -> None:
        if report is None:
            self._refresh_empty()
            return
        self.table.setRowCount(0)
        for c in report.rs.channels:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(c.channel))
            self.table.setItem(r, 1, QTableWidgetItem(f"{c.rm:.4f}"))
            self.table.setItem(r, 2, QTableWidgetItem(f"{c.sm:.4f}"))
            self.table.setItem(r, 3, QTableWidgetItem(f"{c.r_negm:.4f}"))
            self.table.setItem(r, 4, QTableWidgetItem(f"{c.s_negm:.4f}"))
            self.table.setItem(r, 5, QTableWidgetItem(f"{c.d0:.4f}"))
            self.table.setItem(r, 6, QTableWidgetItem(f"{c.d_neg1:.4f}"))
            self.table.setItem(r, 7, QTableWidgetItem(f"{c.imbalance:.4f}"))
            self.table.setItem(r, 8,
                               QTableWidgetItem(f"{c.estimated_rate:.3f}"
                                                 if c.rate_valid else "n/a"))
            self.table.setItem(r, 9, QTableWidgetItem("yes" if c.rate_valid else "no"))
        self.note_lbl.setText(
            "For a clean image R_M−S_M ≈ R_−M−S_−M; LSB replacement breaks "
            "this symmetry. The estimated rate is an approximation — treat "
            f"the imbalance as the primary signal. Max imbalance: "
            f"{report.rs.max_imbalance:.4f}.")
        self.canvas.set_figure(draw_rs_chart(report))
