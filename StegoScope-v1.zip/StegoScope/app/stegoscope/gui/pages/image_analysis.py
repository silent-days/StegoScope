"""Image Analysis page — primary analysis entry point."""

from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFileDialog, QFormLayout,
                                QHBoxLayout, QLabel, QLineEdit,
                                QMessageBox, QProgressBar, QPushButton,
                                QPlainTextEdit, QSpinBox, QVBoxLayout,
                                QWidget)

from ..theme import APP_COLORS
from ..widgets import (Card, InfoCard, MatplotlibCanvas, VerdictBadge,
                        kv_row, _make_transparent)
from ..workers import AnalyzeWorker
from . import BasePage
from ...visualization.plots import draw_score_breakdown


class ImageAnalysisPage(BasePage):
    title = "Image Analysis"
    subtitle = ("Load a PNG or BMP image and run the full StegoScope "
                "detection pipeline: LSB, Chi-Square and RS analysis.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        # ---- toolbar ----
        toolbar = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select a PNG or BMP image…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        self.analyze_btn = QPushButton("Analyze")
        self.analyze_btn.setObjectName("Primary")
        self.analyze_btn.clicked.connect(self._analyze)
        self.clear_btn = QPushButton("Clear current")
        self.clear_btn.setToolTip(
            "Clear the current image, score, charts and detail panel. "
            "Previous scans remain in dashboard history only.")
        self.clear_btn.clicked.connect(self._clear_current)
        self.extract_chk_label = QLabel("Extract payload:")
        self.extract_spin = QSpinBox()
        self.extract_spin.setRange(0, 100000)
        self.extract_spin.setSuffix(" KiB")
        self.extract_spin.setValue(1024)
        toolbar.addWidget(QLabel("Image:"))
        toolbar.addWidget(self.path_edit, 1)
        toolbar.addWidget(browse)
        toolbar.addWidget(self.extract_chk_label)
        toolbar.addWidget(self.extract_spin)
        toolbar.addWidget(self.analyze_btn)
        toolbar.addWidget(self.clear_btn)
        wrap = QWidget(); wrap.setLayout(toolbar)
        self.addContent(wrap)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.addContent(self.progress)

        # ---- verdict + file info row ----
        row = QHBoxLayout()
        row.setSpacing(14)

        verdict_card = Card("Verdict")
        v_inner = QVBoxLayout()
        self.verdict_badge = VerdictBadge()
        # Use "Steganography Risk Score" — clearer than bare "score"
        self.score_lbl = QLabel("Steganography risk score: —")
        self.score_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};"
                                     f"font-size:12px;")
        self.score_lbl.setToolTip(
            "Steganography Risk Score (0–100):\n\n"
            "  • 0–40  →  CLEAN\n"
            "    No statistically significant anomaly detected.\n\n"
            "  • 41–70 →  SUSPICIOUS\n"
            "    Some anomalies present, manual review recommended.\n\n"
            "  • 71–100 → LIKELY HIDDEN DATA\n"
            "    Strong signal from multiple detectors.\n\n"
            "The score is a weighted combination of three independent "
            "detectors (LSB-plane, Chi-Square, RS-analysis), each run "
            "per channel. It is NOT a proof of payload — it is a "
            "statistical indicator that should be confirmed with the "
            "Payload Inspector.")
        self.confidence_lbl = QLabel("")
        self.confidence_lbl.setWordWrap(True)
        self.confidence_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};"
                                          f"font-size:11px;")
        v_inner.addWidget(self.verdict_badge)
        v_inner.addWidget(self.score_lbl, 0, Qt.AlignmentFlag.AlignCenter)
        v_inner.addWidget(self.confidence_lbl)
        vw = QWidget(); _make_transparent(vw); vw.setLayout(v_inner)
        verdict_card.addWidget(vw)
        row.addWidget(verdict_card, 1)

        info_card = Card("File information")
        self.info_form = QFormLayout()
        self.info_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.info_rows = {}
        for key in ("Filename", "Path", "Format", "Mode", "Dimensions",
                    "Channels", "File size", "Total pixels"):
            k, v = kv_row(key, "—")
            self.info_rows[key] = v
            self.info_form.addRow(k, v)
        iw = QWidget(); _make_transparent(iw); iw.setLayout(self.info_form)
        info_card.addWidget(iw)
        row.addWidget(info_card, 2)

        rw = QWidget(); _make_transparent(rw); rw.setLayout(row)
        self.addContent(rw)

        metadata_card = Card("Full image metadata / container detail")
        self.metadata_view = QPlainTextEdit()
        self.metadata_view.setReadOnly(True)
        self.metadata_view.setMinimumHeight(130)
        self.metadata_view.setPlaceholderText(
            "Analyze an image to inspect all safe metadata fields, EXIF tags, "
            "text chunks and binary-field hashes.")
        metadata_card.addWidget(self.metadata_view)
        self.addContent(metadata_card)

        # ---- Risk score explainer card (always visible) ----
        explainer = InfoCard(
            "What is the Steganography Risk Score?",
            "A 0–100 statistical indicator produced by combining three "
            "independent detectors (LSB-plane analysis 20%, Chi-Square "
            "40%, RS-analysis 40%) — each run per channel. "
            "Bands: 0–40 CLEAN, 41–70 SUSPICIOUS, 71–100 LIKELY HIDDEN "
            "DATA. The score is NOT proof of a payload — it is a "
            "statistical indicator that should be confirmed with the "
            "Payload Inspector before drawing conclusions.",
            icon="nav_about", accent=APP_COLORS["accent2"])
        self.addContent(explainer)

        # ---- score breakdown chart ----
        chart_card = Card("Per-channel risk score breakdown")
        self.score_canvas = MatplotlibCanvas(parent=self)
        chart_card.addWidget(self.score_canvas)
        self.addContent(chart_card)

        # ---- reasons ----
        reasons_card = Card("Detection reasons")
        self.reasons_lbl = QLabel("Run an analysis to see detector output.")
        self.reasons_lbl.setWordWrap(True)
        self.reasons_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};"
                                        f"font-size:12px;")
        reasons_card.addWidget(self.reasons_lbl)
        self.addContent(reasons_card)

        self._worker: AnalyzeWorker | None = None
        self._refresh_empty()

    # ---- actions ----
    def _browse(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Select image", "",
            "Images (*.png *.bmp);;All files (*)")
        if path:
            self.path_edit.setText(path)

    def _analyze(self) -> None:
        path = self.path_edit.text().strip()
        if not path:
            QMessageBox.warning(self, "No image", "Please select an image first.")
            return
        if not Path(path).exists():
            QMessageBox.warning(self, "Missing file", f"File not found:\n{path}")
            return
        # Tear down any previous worker before starting a new one so the
        # QThread is fully joined (prevents Qt's "Destroyed while thread is
        # still running" warning if the user double-clicks Analyze).
        self._dispose_worker()
        if self._worker is not None:
            # A previous run is still active.  Never start a second worker
            # over it or let the old completion signal reset new UI state.
            return

        do_extract = self.extract_spin.value() > 0
        max_bytes = self.extract_spin.value() * 1024 if do_extract else None

        self.analyze_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)  # indeterminate
        self.session.set_status(f"Analyzing {Path(path).name}…", "busy")

        self._worker = AnalyzeWorker(
            path, extract=do_extract, max_payload_bytes=max_bytes)
        self._worker.finished_report.connect(self._on_done)
        self._worker.failed.connect(self._on_fail)
        # Auto-cleanup the QThread when it finishes (A4/A7 fix).
        worker = self._worker
        worker.finished.connect(worker.deleteLater)
        worker.finished.connect(lambda w=worker: self._clear_worker(w))
        self._worker.start()

    def _clear_worker(self, worker=None) -> None:
        """Release a finished worker while preserving any newer worker."""
        if worker is None or self._worker is worker:
            self._worker = None

    def _on_done(self, report) -> None:
        self.analyze_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.session.set_report(report)
        self.session.set_status(
            f"{report.info.filename}: {report.verdict.verdict} "
            f"(risk score {report.verdict.score}/100)", "ok")
        self._refresh(report)

    def _on_fail(self, message: str) -> None:
        self.analyze_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.session.set_status(f"Analysis failed: {message}", "idle")
        QMessageBox.critical(self, "Analysis failed", message)

    def _clear_current(self) -> None:
        """Clear only the current report; dashboard history is preserved."""
        if self._worker is not None and self._worker.isRunning():
            return
        self.session.set_report(None)
        self._refresh_empty()
        self.session.set_status("Current image cleared", "idle")

    def _dispose_worker(self) -> None:
        """Wait for & dispose of any previously-started AnalyzeWorker."""
        w = self._worker
        if w is None:
            return
        if w.isRunning():
            return
        try:
            w.deleteLater()
        except Exception as _e:
            from ...utils.logger import get_logger
            get_logger("analysis").debug("worker deleteLater: %s", _e)
        self._worker = None

    # ---- refresh ----
    def _refresh_empty(self) -> None:
        self.verdict_badge.setVerdict("—")
        self.score_lbl.setText("Steganography risk score: —")
        self.confidence_lbl.setText("")
        self.reasons_lbl.setText("Run an analysis to see detector output.")
        for key in self.info_rows:
            self.info_rows[key].setText("—")
        self.metadata_view.setPlainText("")

    def _on_report(self, report) -> None:
        if report is not None:
            self._refresh(report)
        else:
            self._refresh_empty()

    def _refresh(self, report) -> None:
        info = report.info
        def fmt_bytes(n):
            for u in ("B", "KiB", "MiB"):
                if n < 1024:
                    return f"{n:.1f} {u}" if u != "B" else f"{n} B"
                n /= 1024
            return f"{n:.1f} GiB"
        self.info_rows["Filename"].setText(info.filename)
        self.info_rows["Path"].setText(info.path)
        self.info_rows["Format"].setText(info.format)
        self.info_rows["Mode"].setText(info.mode)
        self.info_rows["Dimensions"].setText(f"{info.width} × {info.height} px")
        self.info_rows["Channels"].setText(", ".join(info.channels))
        self.info_rows["File size"].setText(fmt_bytes(info.file_size))
        self.info_rows["Total pixels"].setText(f"{info.total_pixels:,}")
        self.metadata_view.setPlainText(json.dumps(
            info.metadata, indent=2, ensure_ascii=False, default=str))

        self.verdict_badge.setVerdict(report.verdict.verdict)
        self.score_lbl.setText(
            f"Steganography risk score: {report.verdict.score} / 100")
        self.confidence_lbl.setText(report.verdict.confidence)

        # A1 fix: reasons come from the verdict engine as plain text, so
        # we render them with Qt.PlainText. Previously the &bull;/&lt;br/&gt;
        # HTML entities forced Qt into rich-text mode and any '<', '>', '&'
        # inside a reason string would be silently mangled. We now join with
        # a real bullet character (U+2022) and a newline and let plain-text
        # word-wrap do the work.
        if report.verdict.reasons:
            joined = "\n".join(f"•  {r}" for r in report.verdict.reasons)
            self.reasons_lbl.setTextFormat(Qt.TextFormat.PlainText)
            self.reasons_lbl.setText(joined)
        else:
            self.reasons_lbl.setTextFormat(Qt.TextFormat.PlainText)
            self.reasons_lbl.setText("No anomalies detected.")

        self.score_canvas.set_figure(draw_score_breakdown(report))
