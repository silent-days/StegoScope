"""StegoScope GUI pages.

Each page is a self-contained :class:`QWidget` that observes the shared
:class:`~stegoscope.gui.session.SessionManager` and refreshes itself
when the current analysis report or batch results change.
"""

from __future__ import annotations

from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from ..session import SessionManager


class BasePage(QWidget):
    """Common scaffolding: a title, a subtitle, and a content slot."""

    title: str = "Page"
    subtitle: str = ""

    def __init__(self, session: SessionManager,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.session = session
        self.setObjectName("Page")
        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(28, 22, 28, 22)
        self._root.setSpacing(8)

        self._title_lbl = QLabel(self.title)
        self._title_lbl.setObjectName("PageTitle")
        self._sub_lbl = QLabel(self.subtitle)
        self._sub_lbl.setObjectName("PageSubtitle")
        self._root.addWidget(self._title_lbl)
        self._root.addWidget(self._sub_lbl)

        self._content = QVBoxLayout()
        self._content.setSpacing(14)
        self._root.addLayout(self._content)

        # Wire to the session by default.
        session.report_changed.connect(self._on_report)
        session.batch_changed.connect(self._on_batch)
        session.history_changed.connect(self._on_history)
        session.stats_changed.connect(self._on_stats)

    # ---- content helper ----
    def addContent(self, widget: QWidget) -> None:
        self._content.addWidget(widget)

    def addLayout(self, layout) -> None:
        self._content.addLayout(layout)

    # ---- session hooks (override in subclasses) ----
    def _on_report(self, report) -> None:
        pass

    def _on_batch(self, results) -> None:
        pass

    def _on_history(self, history) -> None:
        pass

    def _on_stats(self) -> None:
        pass

    @property
    def report(self):
        return self.session.report


# Import pages after BasePage is defined so circular imports resolve.
from .dashboard import DashboardPage  # noqa: E402
from .image_analysis import ImageAnalysisPage  # noqa: E402
from .lsb import LSBAnalysisPage  # noqa: E402
from .chi_square import ChiSquarePage  # noqa: E402
from .rs_analysis import RSAnalysisPage  # noqa: E402
from .batch import BatchScannerPage  # noqa: E402
from .payload import PayloadInspectorPage  # noqa: E402
from .cleaner import CleanerPage  # noqa: E402
from .visual import VisualForensicsPage  # noqa: E402
from .reports import ReportsPage  # noqa: E402
from .settings import SettingsPage  # noqa: E402
from .about import AboutPage  # noqa: E402

__all__ = [
    "BasePage",
    "DashboardPage",
    "ImageAnalysisPage",
    "LSBAnalysisPage",
    "ChiSquarePage",
    "RSAnalysisPage",
    "BatchScannerPage",
    "PayloadInspectorPage",
    "CleanerPage",
    "VisualForensicsPage",
    "ReportsPage",
    "SettingsPage",
    "AboutPage",
]
