"""Chi-Square analysis page."""

from __future__ import annotations

from PySide6.QtWidgets import (QHeaderView, QLabel,
                                QTableWidget, QTableWidgetItem)

from ..theme import APP_COLORS
from ..widgets import Card, MatplotlibCanvas
from . import BasePage
from ...visualization.plots import draw_chi_chart


class ChiSquarePage(BasePage):
    title = "Chi-Square Analysis"
    subtitle = ("Westfeld-Pfitzmann pair-value histogram test for random "
                "LSB replacement embedding.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        stats_card = Card("Chi-Square statistics per channel")
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Channel", "Statistic", "dof", "p-value",
             "Embedding prob.", "Sample pairs"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for i in range(6):
            self.table.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.ResizeMode.Stretch if i == 0 else
                QHeaderView.ResizeMode.ResizeToContents)
        stats_card.addWidget(self.table)
        self.addContent(stats_card)

        self.note_lbl = QLabel("")
        self.note_lbl.setWordWrap(True)
        self.note_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};"
                                     f"font-size:11px;")
        stats_card.addWidget(self.note_lbl)

        chart_card = Card("Embedding probability per channel")
        self.canvas = MatplotlibCanvas(parent=self)
        chart_card.addWidget(self.canvas)
        self.addContent(chart_card)

        self._refresh_empty()

    def _refresh_empty(self) -> None:
        self.table.setRowCount(0)
        self.note_lbl.setText("")

    def _on_report(self, report) -> None:
        if report is None:
            self._refresh_empty()
            return
        self.table.setRowCount(0)
        for c in report.chi.channels:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(c.channel))
            self.table.setItem(r, 1, QTableWidgetItem(f"{c.statistic:.2f}"))
            self.table.setItem(r, 2, QTableWidgetItem(str(c.dof)))
            self.table.setItem(r, 3, QTableWidgetItem(f"{c.p_value:.4f}"))
            self.table.setItem(r, 4, QTableWidgetItem(f"{c.embedding_probability:.4f}"))
            self.table.setItem(r, 5, QTableWidgetItem(str(c.sample_pairs)))
        self.note_lbl.setText(
            "A HIGH embedding probability means the value-pair histogram is "
            "consistent with random LSB replacement. Max across channels: "
            f"{report.chi.max_embedding_probability:.4f}.")
        self.canvas.set_figure(draw_chi_chart(report))
