"""Image Cleaner page — strip metadata and neutralise the LSB plane.

The cleaner is the symmetric counterpart of the analyzer: where the
analyzer reports what was found, the cleaner *removes* the surface
steganography tools operate on so the image can be re-shared safely.

Two independent operations, both optional:

1. **Strip metadata** — removes PNG text chunks, EXIF, XMP, ICC
   profile, gamma, transparency hints. The visible image is unchanged.
2. **Neutralise LSB** — forces the least-significant bit of every
   selected channel to 0. Destroys any LSB-replacement payload while
   keeping the high seven bits intact.

The cleaned image is always written as PNG (lossless).
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QFormLayout,
                                QHBoxLayout, QLabel, QLineEdit,
                                QMessageBox, QProgressBar, QPushButton,
                                QVBoxLayout, QWidget)

from ..theme import APP_COLORS
from ..widgets import Card, InfoCard, _make_transparent
from . import BasePage
from ...core.cleaner import clean_image


class _CleanWorker(QThread):
    """Run the cleaner off the UI thread."""

    finished_clean = Signal(object)   # CleanerResult
    failed = Signal(str)

    def __init__(self, source: str, output: str, *,
                 strip_metadata: bool, neutralise_lsb: bool,
                 channels: list[str] | None = None) -> None:
        super().__init__()
        self._source = source
        self._output = output
        self._strip = strip_metadata
        self._lsb = neutralise_lsb
        self._channels = channels

    def run(self) -> None:
        try:
            res = clean_image(
                self._source, self._output,
                strip_metadata=self._strip,
                neutralise_lsb=self._lsb,
                neutralise_channels=self._channels,
            )
            if res.success:
                self.finished_clean.emit(res)
            else:
                self.failed.emit(res.error or "Unknown error")
        except Exception as exc:
            self.failed.emit(f"{exc.__class__.__name__}: {exc}")


class CleanerPage(BasePage):
    title = "Image Cleaner"
    subtitle = ("Strip metadata and neutralise the LSB plane so an image "
                "can be re-shared without leaking steganographic surface.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        # ---- Toolbar: source + output -------------------------------
        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select source PNG / BMP…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_source)
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Output path (default: <name>_clean.png)")
        out_browse = QPushButton("…")
        out_browse.setFixedWidth(40)
        out_browse.clicked.connect(self._browse_output)
        self.clean_btn = QPushButton("Clean Image")
        self.clean_btn.setObjectName("Primary")
        self.clean_btn.clicked.connect(self._clean)
        toolbar.addWidget(QLabel("Source:"))
        toolbar.addWidget(self.path_edit, 1)
        toolbar.addWidget(browse)
        toolbar.addWidget(QLabel("Output:"))
        toolbar.addWidget(self.output_edit, 1)
        toolbar.addWidget(out_browse)
        toolbar.addWidget(self.clean_btn)
        wrap = QWidget()
        _make_transparent(wrap)
        wrap.setLayout(toolbar)
        self.addContent(wrap)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setRange(0, 0)
        self.addContent(self.progress)

        # ---- Options ------------------------------------------------
        opts_card = Card("Cleaning options")
        opts_wrap = QWidget()
        _make_transparent(opts_wrap)
        ov = QVBoxLayout(opts_wrap)
        ov.setSpacing(10)

        # Metadata stripping
        self.meta_chk = QCheckBox("Strip metadata (PNG text chunks, EXIF, XMP, ICC profile, gamma, transparency hints)")
        self.meta_chk.setChecked(True)
        self.meta_chk.setToolTip(
            "Removes every non-essential PNG chunk and PIL image-info "
            "field. The visible pixel stream is unchanged — only the "
            "container's ancillary data is dropped.\n\n"
            "Removes: tEXt, zTXt, iTXt, iCCP, sRGB, cHRM, gAMA, tRNS, "
            "EXIF, XMP, icc_profile.")
        ov.addWidget(self.meta_chk)

        # LSB neutralisation
        lsb_row = QWidget()
        _make_transparent(lsb_row)
        lh = QHBoxLayout(lsb_row)
        lh.setContentsMargins(0, 0, 0, 0)
        lh.setSpacing(10)
        self.lsb_chk = QCheckBox("Neutralise LSB plane (force every LSB to 0 — DESTROYS any hidden payload)")
        self.lsb_chk.setToolTip(
            "Sets the least-significant bit of every selected channel "
            "to 0. This destroys any LSB-replacement payload while "
            "keeping the high seven bits (and therefore the visible "
            "image) unchanged. After neutralisation the LSB plane of "
            "each channel becomes uniformly zero — any future LSB "
            "detector returns a 0/100 suspicion score.\n\n"
            "COST: an imperceptible 1-LSB change in luminance per "
            "channel (~0.4% of full scale).\n\n"
            "WHY ON BY DEFAULT: this is the operation that actually "
            "lowers the Steganography Risk Score. Without it the "
            "cleaner only strips metadata (which does not affect "
            "the score). Turn it off only if you need to preserve "
            "the exact pixel stream.")
        self.lsb_chk.setChecked(True)
        lh.addWidget(self.lsb_chk)
        lh.addStretch(1)
        self.channels_lbl = QLabel("Channels: all")
        self.channels_lbl.setStyleSheet(
            f"color: {APP_COLORS['text_dim']}; font-size: 11px;")
        lh.addWidget(self.channels_lbl)
        ov.addWidget(lsb_row)

        # Channel selector (visible only when LSB is on)
        chan_row = QWidget()
        _make_transparent(chan_row)
        ch = QHBoxLayout(chan_row)
        ch.setContentsMargins(20, 0, 0, 0)
        ch.setSpacing(14)
        self.chan_checks: dict[str, QCheckBox] = {}
        for c in ("R", "G", "B", "A", "L", "P"):
            cb = QCheckBox(c)
            cb.setChecked(True)
            cb.setVisible(False)
            self.chan_checks[c] = cb
            ch.addWidget(cb)
        ch.addStretch(1)
        ov.addWidget(chan_row)
        self.lsb_chk.toggled.connect(self._on_lsb_toggled)
        ov.addStretch(1)

        opts_card.addWidget(opts_wrap)
        self.addContent(opts_card)

        # ---- Information cards --------------------------------------
        info_row = QWidget()
        _make_transparent(info_row)
        ih = QHBoxLayout(info_row)
        ih.setContentsMargins(0, 0, 0, 0)
        ih.setSpacing(12)

        info_row_layout_left = QVBoxLayout()
        info_row_layout_left.setSpacing(8)
        info_row_layout_right = QVBoxLayout()
        info_row_layout_right.setSpacing(8)

        # What does each option do?
        info_row_layout_left.addWidget(InfoCard(
            "Strip metadata — what it removes",
            "PNG text chunks (tEXt / zTXt / iTXt), EXIF, XMP, ICC color "
            "profile, gamma, single-color transparency hints and the "
            "software tag. The visible pixel stream is preserved "
            "bit-for-bit; only the container's ancillary data is dropped.",
            icon="nav_cleaner", accent=APP_COLORS["accent2"]))
        info_row_layout_left.addWidget(InfoCard(
            "Why neutralise the LSB plane?",
            "Forces the least-significant bit of every selected channel "
            "to 0. This destroys any LSB-replacement payload while keeping "
            "the high seven bits intact. After cleaning, any future LSB "
            "detector returns a 0/100 suspicion score. Cost: an "
            "imperceptible 1-LSB luminance change per channel.",
            icon="nav_lsb", accent=APP_COLORS["accent3"]))

        # Output format and verification
        info_row_layout_right.addWidget(InfoCard(
            "Output format & verification",
            "The cleaned image is always written as PNG (lossless), "
            "regardless of the input format. After cleaning, re-run the "
            "Image Analysis on the output file to confirm the metadata "
            "is gone and the suspicion score has dropped.",
            icon="nav_reports", accent=APP_COLORS["accent"]))
        info_row_layout_right.addWidget(InfoCard(
            "Safety guarantees",
            "The source file is never modified. The cleaner operates on "
            "a copy and writes the result to a new path. Re-running the "
            "cleaner on an already-clean image is a no-op (idempotent).",
            icon="nav_about", accent=APP_COLORS["good"]))

        wrap_left = QWidget(); _make_transparent(wrap_left)
        wrap_left.setLayout(info_row_layout_left)
        wrap_right = QWidget(); _make_transparent(wrap_right)
        wrap_right.setLayout(info_row_layout_right)
        ih.addWidget(wrap_left, 1)
        ih.addWidget(wrap_right, 1)
        self.addContent(info_row)

        # ---- Result panel -------------------------------------------
        self.result_card = Card("Last clean result")
        self.result_form = QFormLayout()
        self.result_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.res_rows: dict[str, QLabel] = {}
        for k in ("Source", "Output", "Input size", "Output size",
                  "Chunks removed", "LSB neutralised",
                  "Channels neutralised", "Bits cleared"):
            lbl = QLabel("—")
            lbl.setStyleSheet(
                f"color: {APP_COLORS['text']}; background: transparent;"
                f"font-size: 12px;")
            self.res_rows[k] = lbl
            k_lbl = QLabel(k)
            k_lbl.setStyleSheet(
                f"color: {APP_COLORS['text_dim']}; background: transparent;"
                f"font-size: 11px;")
            k_lbl.setMinimumWidth(150)
            self.result_form.addRow(k_lbl, lbl)
        rw = QWidget(); _make_transparent(rw); rw.setLayout(self.result_form)
        self.result_card.addWidget(rw)
        self.addContent(self.result_card)

        # ---- Open-output + analyze buttons ----------------------------
        open_row = QHBoxLayout()
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.setEnabled(False)
        self.open_btn.clicked.connect(self._open_output)
        self.analyze_btn = QPushButton("Analyze cleaned image")
        self.analyze_btn.setObjectName("Primary")
        self.analyze_btn.setEnabled(False)
        self.analyze_btn.setToolTip(
            "Switch to the Image Analysis page and run the full "
            "detection pipeline on the cleaned image. The risk score "
            "should be much lower than the original (close to 0 if "
            "the LSB plane was neutralised).")
        self.analyze_btn.clicked.connect(self._analyze_cleaned)
        open_row.addWidget(self.open_btn)
        open_row.addWidget(self.analyze_btn)
        open_row.addStretch(1)
        ow = QWidget(); _make_transparent(ow); ow.setLayout(open_row)
        self.addContent(ow)

        self._worker: _CleanWorker | None = None
        self._last_output: str | None = None

        # Initialise the channel checkboxes for the default LSB-on state.
        # setChecked(True) above did not fire the toggled signal (initial
        # state), so we call _on_lsb_toggled once to make the channel
        # checks match the lsb_chk state and make them visible.
        self._on_lsb_toggled(self.lsb_chk.isChecked())

    # ------------------------------------------------------------------ #
    def _browse_source(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Select source image", "",
            "Images (*.png *.bmp);;All files (*)")
        if path:
            self.path_edit.setText(path)
            # Default the output path to <name>_clean.png alongside the source.
            if not self.output_edit.text().strip():
                p = Path(path)
                self.output_edit.setText(str(p.with_name(p.stem + "_clean.png")))

    def _browse_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Choose output path", "cleaned.png",
            "PNG image (*.png);;All files (*)")
        if path:
            self.output_edit.setText(path)

    def _on_lsb_toggled(self, on: bool) -> None:
        for cb in self.chan_checks.values():
            cb.setVisible(on)
            # Auto-check all visible channels so the user doesn't have to
            # manually pick R, G, B every time — the common case is
            # "neutralise every channel". They can uncheck individually
            # if they only want a subset.
            if on:
                cb.setChecked(True)
        self._update_channel_label()

    def _update_channel_label(self) -> None:
        """Keep the channel summary accurate even before the page is shown."""
        selected = [name for name, cb in self.chan_checks.items()
                    if cb.isChecked()]
        self.channels_lbl.setText(
            "Channels: " + (", ".join(selected) if selected else "none"))

    def _clean(self) -> None:
        src = self.path_edit.text().strip()
        out = self.output_edit.text().strip()
        if not src:
            QMessageBox.warning(self, "No source", "Please select a source image first.")
            return
        if not Path(src).exists():
            QMessageBox.warning(self, "Missing file", f"File not found:\n{src}")
            return
        if not out:
            p = Path(src)
            out = str(p.with_name(p.stem + "_clean.png"))
            self.output_edit.setText(out)
        if not out.lower().endswith(".png"):
            QMessageBox.information(
                self, "Output format",
                "The output path will be saved as PNG (lossless). "
                "Appending .png to the path.")
            out = out + ".png"
            self.output_edit.setText(out)

        if not self.meta_chk.isChecked() and not self.lsb_chk.isChecked():
            QMessageBox.warning(
                self, "Nothing to do",
                "Select at least one cleaning operation: strip metadata "
                "or neutralise the LSB plane.")
            return

        # Dispose of any previous worker.
        self._dispose_worker()
        if self._worker is not None:
            return

        channels: list[str] | None = None
        if self.lsb_chk.isChecked():
            # Do not use QWidget.isVisible() here.  A page inside a hidden
            # QStackedWidget/scroll area reports its children as invisible
            # even though the controls are enabled and selected.  That made
            # the first clean action open a modal "No channels" warning and
            # made repeated clean operations appear broken.
            channels = [c for c, cb in self.chan_checks.items()
                        if cb.isChecked()]
            if not channels:
                QMessageBox.warning(
                    self, "No channels",
                    "Select at least one channel to neutralise, "
                    "or uncheck the LSB option.")
                return

        self.clean_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.session.set_status(f"Cleaning {Path(src).name}…", "busy")

        self._worker = _CleanWorker(
            src, out,
            strip_metadata=self.meta_chk.isChecked(),
            neutralise_lsb=self.lsb_chk.isChecked(),
            channels=channels,
        )
        self._worker.finished_clean.connect(self._on_done)
        self._worker.failed.connect(self._on_fail)
        worker = self._worker
        worker.finished.connect(worker.deleteLater)
        worker.finished.connect(lambda w=worker: self._clear_worker(w))
        self._worker.start()

    def _clear_worker(self, worker=None) -> None:
        """Release a finished worker without disturbing a new run."""
        if worker is None or self._worker is worker:
            self._worker = None

    def _on_done(self, res) -> None:
        self.clean_btn.setEnabled(True)
        self.progress.setVisible(False)
        self._last_output = res.output_path
        self._update_channel_label()

        def fmt_bytes(n: int) -> str:
            for u in ("B", "KiB", "MiB"):
                if n < 1024:
                    return f"{n:.1f} {u}" if u != "B" else f"{n} B"
                n /= 1024
            return f"{n:.1f} GiB"

        self.res_rows["Source"].setText(res.source_path)
        self.res_rows["Output"].setText(res.output_path)
        self.res_rows["Input size"].setText(fmt_bytes(res.input_size))
        self.res_rows["Output size"].setText(fmt_bytes(res.output_size))
        if res.metadata_chunks_removed:
            self.res_rows["Chunks removed"].setText(
                ", ".join(res.metadata_chunks_removed))
        else:
            self.res_rows["Chunks removed"].setText("none")
        if res.lsb_neutralised:
            self.res_rows["LSB neutralised"].setText("yes")
            self.res_rows["Channels neutralised"].setText(
                ", ".join(res.channels_neutralised))
            self.res_rows["Bits cleared"].setText(f"{res.bits_cleared:,}")
        else:
            self.res_rows["LSB neutralised"].setText("no")
            self.res_rows["Channels neutralised"].setText("—")
            self.res_rows["Bits cleared"].setText("0")

        self.open_btn.setEnabled(True)
        self.analyze_btn.setEnabled(True)
        self.session.set_status(
            f"Cleaned {Path(res.source_path).name} → "
            f"{Path(res.output_path).name}", "ok")

    def _on_fail(self, msg: str) -> None:
        self.clean_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.session.set_status(f"Clean failed: {msg}", "idle")
        QMessageBox.critical(self, "Clean failed", msg)

    def _open_output(self) -> None:
        if not self._last_output:
            return
        # Open the parent folder — cross-platform.
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        url = QUrl.fromLocalFile(str(Path(self._last_output).parent))
        QDesktopServices.openUrl(url)

    def _analyze_cleaned(self) -> None:
        """Switch to Image Analysis page and trigger analysis on the cleaned file."""
        if not self._last_output:
            return
        out = self._last_output
        if not Path(out).exists():
            QMessageBox.warning(self, "File missing",
                                f"The cleaned file no longer exists:\n{out}")
            return
        # Find the main window so we can switch the page.
        from ..main_window import MainWindow
        from ..pages import ImageAnalysisPage
        parent = self.window()
        if isinstance(parent, MainWindow):
            # The main window lazy-loads heavy pages; ensure the target page
            # exists instead of relying on findChildren() finding it.
            page = parent._ensure_page(1)
            if isinstance(page, ImageAnalysisPage):
                page.path_edit.setText(out)
                parent._stack.setCurrentIndex(1)
                parent._nav_buttons[1].setChecked(True)
                page._analyze()
                return
        # Fallback: switch to the analysis page if a custom host is used.
        if isinstance(parent, MainWindow):
            parent._stack.setCurrentIndex(1)
            parent._nav_buttons[1].setChecked(True)

    def _dispose_worker(self) -> None:
        w = self._worker
        if w is None:
            return
        if w.isRunning():
            return
        try:
            w.deleteLater()
        except Exception as _e:
            from ...utils.logger import get_logger
            get_logger("cleaner").debug("worker deleteLater: %s", _e)
        self._worker = None
