"""Payload Inspector page — candidate LSB payload extraction preview."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFileDialog, QFormLayout, QHBoxLayout,
                                QLabel, QPushButton, QSpinBox,
                                QTextEdit, QWidget)

from ..theme import APP_COLORS
from ..widgets import Card
from . import BasePage


class PayloadInspectorPage(BasePage):
    title = "Payload Inspector"
    subtitle = ("Candidate LSB payload extraction. Extracted data is "
                "UNTRUSTED — StegoScope never executes it.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)
        # Page-local re-extraction result (None = use session.report.payload).
        self._local_payload = None

        # Controls to (re)extract from the current image with a new cap.
        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Max payload:"))
        self.cap_spin = QSpinBox()
        self.cap_spin.setRange(1, 100000)
        self.cap_spin.setSuffix(" KiB")
        self.cap_spin.setValue(1024)
        self.reextract_btn = QPushButton("Re-extract")
        self.reextract_btn.clicked.connect(self._reextract)
        self.export_btn = QPushButton("Export .bin")
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self._export)
        ctrl.addWidget(self.cap_spin)
        ctrl.addWidget(self.reextract_btn)
        ctrl.addWidget(self.export_btn)
        ctrl.addStretch(1)
        cw = QWidget(); cw.setLayout(ctrl)
        self.addContent(cw)

        info_card = Card("Extraction summary")
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.lbl_channels = QLabel("—")
        self.lbl_bytes = QLabel("—")
        self.lbl_bits = QLabel("—")
        self.lbl_avail = QLabel("—")
        self.lbl_trunc = QLabel("—")
        form.addRow("Channel order", self.lbl_channels)
        form.addRow("Candidate bytes", self.lbl_bytes)
        form.addRow("Bits packed", self.lbl_bits)
        form.addRow("Total LSB bits available", self.lbl_avail)
        form.addRow("Truncated", self.lbl_trunc)
        iw = QWidget(); iw.setLayout(form)
        info_card.addWidget(iw)
        self.addContent(info_card)

        warn = QLabel("⚠  Extracted bytes are CANDIDATE data, not a confirmed "
                      "payload. Do not execute, import, or trust their contents.")
        warn.setWordWrap(True)
        warn.setStyleSheet(
            f"color:{APP_COLORS['warn']}; background:{APP_COLORS['panel_alt']};"
            f"padding:10px; border-radius:6px;")
        self.addContent(warn)

        hex_card = Card("Hex preview (first 256 bytes)")
        self.hex_view = QTextEdit()
        self.hex_view.setReadOnly(True)
        hex_card.addWidget(self.hex_view)
        self.addContent(hex_card)

        ascii_card = Card("ASCII preview (first 256 bytes)")
        self.ascii_view = QTextEdit()
        self.ascii_view.setReadOnly(True)
        ascii_card.addWidget(self.ascii_view)
        self.addContent(ascii_card)

        self._refresh_empty()

    def _refresh_empty(self) -> None:
        for lbl in (self.lbl_channels, self.lbl_bytes, self.lbl_bits,
                    self.lbl_avail, self.lbl_trunc):
            lbl.setText("—")
        self.hex_view.setPlainText("")
        self.ascii_view.setPlainText("")
        self.export_btn.setEnabled(False)

    def _on_report(self, report) -> None:
        # When a fresh report arrives from the session, drop any page-local
        # re-extraction so we preview the report's actual payload.
        self._local_payload = None
        if report is None or report.payload is None:
            self._refresh_empty()
            return
        self._show(report)

    def _show(self, report) -> None:
        # Prefer the page-local re-extraction if the user just re-extracted;
        # otherwise show the report's own payload.
        p = self._local_payload if self._local_payload is not None else report.payload
        self._show_payload(p)

    def _reextract(self) -> None:
        report = self.session.report
        if report is None:
            return
        from ...core.image_loader import ImageLoader
        from ...extraction.payload import extract_payload
        try:
            img = ImageLoader().load(report.info.path)
        except Exception:
            return
        cap = self.cap_spin.value() * 1024
        payload = extract_payload(img, max_bytes=cap)
        # A5 fix: do NOT mutate session.report.payload in place. Doing so
        # would silently overwrite the original PayloadResult on every
        # other page (notably Reports), losing the original byte_count /
        # truncated metadata. Keep the original report immutable and store
        # the re-extraction in a page-local field for preview/export only.
        self._local_payload = payload
        self._show_payload(payload)
        self.session.set_status(
            f"Re-extracted {payload.byte_count:,} candidate bytes", "ok")

    def _show_payload(self, p) -> None:
        if p is None:
            self._refresh_empty()
            return
        self.lbl_channels.setText(", ".join(p.channel_order))
        self.lbl_bytes.setText(f"{p.byte_count:,}")
        self.lbl_bits.setText(f"{p.bits_used:,}")
        self.lbl_avail.setText(f"{p.total_bits_available:,}")
        self.lbl_trunc.setText("yes" if p.truncated else "no")
        self.hex_view.setPlainText(p.hex_preview or "")
        asc = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in p.data[:256])
        self.ascii_view.setPlainText(asc)
        self.export_btn.setEnabled(p.byte_count > 0)

    def _export(self) -> None:
        report = self.session.report
        # Prefer page-local re-extraction if present.
        p = self._local_payload if getattr(self, "_local_payload", None) is not None else (report.payload if report is not None else None)
        if p is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export candidate payload",
            Path(report.info.filename).stem + "_candidate.bin" if report else "candidate.bin",
            "Binary files (*.bin);;All files (*)")
        if not path:
            return
        from ...extraction.payload import save_payload
        written = save_payload(p, path)
        self.session.set_status(f"Payload written: {written}", "ok")
