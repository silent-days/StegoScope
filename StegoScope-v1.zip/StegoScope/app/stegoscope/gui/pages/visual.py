"""Visual Forensics page — image planes and saveable charts."""

from __future__ import annotations

from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QPushButton,
                                QTabWidget, QVBoxLayout, QWidget)

from ..theme import APP_COLORS
from ..widgets import MatplotlibCanvas
from . import BasePage
from ...visualization.plots import (draw_channel_planes, draw_chi_chart,
                                     draw_lsb_planes, draw_rs_chart,
                                     draw_score_breakdown)


class _PlotTab(QWidget):
    """A tab holding one matplotlib canvas and a Save button."""

    def __init__(self, title: str, parent=None) -> None:
        super().__init__(parent)
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        self.canvas = MatplotlibCanvas(parent=self)
        v.addWidget(self.canvas)
        bar = QHBoxLayout()
        self.save_btn = QPushButton(f"Save {title} as PNG…")
        self.save_btn.clicked.connect(self._save)
        bar.addStretch(1)
        bar.addWidget(self.save_btn)
        bw = QWidget(); bw.setLayout(bar)
        v.addWidget(bw)

    def set_figure(self, fig) -> None:
        self.canvas.set_figure(fig)

    def _save(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save visualization", "stegoscope_plot.png",
            "PNG image (*.png);;All files (*)")
        if not path:
            return
        self.canvas.figure.savefig(path,
                                   facecolor=self.canvas.figure.get_facecolor(),
                                   dpi=self.canvas.figure.dpi)


class VisualForensicsPage(BasePage):
    title = "Visual Forensics"
    subtitle = ("Image channel planes, LSB planes and statistical charts. "
                "Every plot can be saved as a PNG.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        self.tabs = QTabWidget()
        self.tab_channels = _PlotTab("channel planes")
        self.tab_lsb = _PlotTab("LSB planes")
        self.tab_score = _PlotTab("score breakdown")
        self.tab_chi = _PlotTab("chi-square")
        self.tab_rs = _PlotTab("RS chart")
        self.tabs.addTab(self.tab_channels, "Channel planes")
        self.tabs.addTab(self.tab_lsb, "LSB planes")
        self.tabs.addTab(self.tab_score, "Score breakdown")
        self.tabs.addTab(self.tab_chi, "Chi-Square")
        self.tabs.addTab(self.tab_rs, "RS Analysis")
        self.addContent(self.tabs)

        self._empty_fig()

    def _empty_fig(self) -> None:
        from matplotlib.figure import Figure
        for tab in (self.tab_channels, self.tab_lsb, self.tab_score,
                    self.tab_chi, self.tab_rs):
            f = Figure()
            ax = f.add_subplot(111)
            ax.set_axis_off()
            ax.text(0.5, 0.5, "No image loaded",
                    ha="center", va="center",
                    color=APP_COLORS["text_muted"], transform=ax.transAxes)
            f.patch.set_facecolor(APP_COLORS["bg"])
            tab.set_figure(f)

    def _on_report(self, report) -> None:
        if report is None:
            self._empty_fig()
            return
        try:
            from ...core.image_loader import ImageLoader
            img = ImageLoader().load(report.info.path)
            self.tab_channels.set_figure(draw_channel_planes(img))
            self.tab_lsb.set_figure(draw_lsb_planes(img))
        except Exception:
            self._empty_fig()
        self.tab_score.set_figure(draw_score_breakdown(report))
        self.tab_chi.set_figure(draw_chi_chart(report))
        self.tab_rs.set_figure(draw_rs_chart(report))
