"""Batch Scanner page."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QHBoxLayout,
                                QHeaderView, QLabel, QLineEdit, QMessageBox,
                                QProgressBar, QPushButton, QSpinBox,
                                QTableWidget, QTableWidgetItem, QWidget)

from ..theme import APP_COLORS
from ..widgets import Card
from ..workers import BatchWorker
from . import BasePage


class BatchScannerPage(BasePage):
    title = "Batch Scanner"
    subtitle = ("Scan every PNG/BMP in a folder. The scan runs in the "
                "background so the interface stays responsive.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        toolbar = QHBoxLayout()
        self.dir_edit = QLineEdit()
        self.dir_edit.setPlaceholderText("Select a folder of images…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        self.recursive_chk = QCheckBox("Recursive")
        self.extract_chk = QCheckBox("Extract payloads")
        self.max_files_spin = QSpinBox()
        self.max_files_spin.setRange(0, 100000)
        self.max_files_spin.setSuffix(" max")
        self.max_files_spin.setSpecialValueText("no limit")
        self.max_files_spin.setValue(0)
        self.max_files_spin.setToolTip("Cap the number of files processed "
                                       "(0 = no limit).")
        self.scan_btn = QPushButton("Scan")
        self.scan_btn.setObjectName("Primary")
        self.scan_btn.clicked.connect(self._scan)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self._cancel)
        toolbar.addWidget(QLabel("Folder:"))
        toolbar.addWidget(self.dir_edit, 1)
        toolbar.addWidget(browse)
        toolbar.addWidget(self.recursive_chk)
        toolbar.addWidget(self.extract_chk)
        toolbar.addWidget(self.max_files_spin)
        toolbar.addWidget(self.scan_btn)
        toolbar.addWidget(self.cancel_btn)
        wrap = QWidget(); wrap.setLayout(toolbar)
        self.addContent(wrap)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.addContent(self.progress)

        self.status_lbl = QLabel("")
        self.status_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};")
        self.addContent(self.status_lbl)

        results_card = Card("Ranked results (most suspicious first)")
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Rank", "Filename", "Verdict", "Score",
             "Chi max", "RS imbalance"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch)
        for i in (0, 2, 3, 4, 5):
            self.table.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.ResizeMode.ResizeToContents)
        results_card.addWidget(self.table)
        self.addContent(results_card)

        export_row = QHBoxLayout()
        self.export_csv_btn = QPushButton("Export CSV")
        self.export_json_btn = QPushButton("Export JSON")
        self.export_csv_btn.clicked.connect(lambda: self._export("csv"))
        self.export_json_btn.clicked.connect(lambda: self._export("json"))
        self.export_csv_btn.setEnabled(False)
        self.export_json_btn.setEnabled(False)
        export_row.addWidget(self.export_csv_btn)
        export_row.addWidget(self.export_json_btn)
        export_row.addStretch(1)
        ew = QWidget(); ew.setLayout(export_row)
        self.addContent(ew)

        self._worker: BatchWorker | None = None
        self._results = []

    def _browse(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Select folder")
        if d:
            self.dir_edit.setText(d)

    def _scan(self) -> None:
        d = self.dir_edit.text().strip()
        if not d or not Path(d).is_dir():
            QMessageBox.warning(self, "Invalid folder",
                                "Please select an existing folder.")
            return
        # Tear down any previous worker so its QThread is fully joined
        # before we start a new one — prevents the Qt warning about a
        # QThread being destroyed while still running.
        self._dispose_worker()
        self.scan_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.export_csv_btn.setEnabled(False)
        self.export_json_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.status_lbl.setText("Scanning…")
        self.session.set_status(f"Batch scanning {d}…", "busy")

        max_files = self.max_files_spin.value() or None
        self._worker = BatchWorker(
            d, recursive=self.recursive_chk.isChecked(),
            extract=self.extract_chk.isChecked(), max_files=max_files)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished_batch.connect(self._on_done)
        self._worker.failed.connect(self._on_fail)
        # Auto-cleanup the QThread when it finishes so the worker object
        # does not linger until the page is destroyed.
        self._worker.finished.connect(self._worker.deleteLater)
        self._worker.start()

    def _cancel(self) -> None:
        if self._worker is not None and self._worker.isRunning():
            self._worker.cancel()
            self.status_lbl.setText("Cancelling… (finishes after the "
                                    "current file)")
            self.cancel_btn.setEnabled(False)

    def _on_progress(self, done, total, name) -> None:
        self.progress.setRange(0, total)
        self.progress.setValue(done)
        self.status_lbl.setText(f"[{done}/{total}] {name}")

    def _on_done(self, results) -> None:
        self.scan_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress.setVisible(False)
        self._results = results
        self.session.set_batch(results)
        clean = sum(1 for r in results if r.verdict == "CLEAN")
        susp = sum(1 for r in results if r.verdict == "SUSPICIOUS")
        likely = sum(1 for r in results if r.verdict == "LIKELY HIDDEN DATA")
        err = sum(1 for r in results if r.verdict == "ERROR")
        self.status_lbl.setText(
            f"Done: {len(results)} image(s) — {clean} CLEAN, {susp} "
            f"SUSPICIOUS, {likely} LIKELY HIDDEN DATA, {err} error(s).")
        self.session.set_status(
            f"Batch done: {len(results)} scanned", "ok")
        self._populate(results)
        self.export_csv_btn.setEnabled(bool(results))
        self.export_json_btn.setEnabled(bool(results))

    def _on_fail(self, message: str) -> None:
        self.scan_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress.setVisible(False)
        self.status_lbl.setText(f"Failed: {message}")
        self.session.set_status("Batch failed", "idle")
        QMessageBox.critical(self, "Batch failed", message)

    def _populate(self, results) -> None:
        from PySide6.QtGui import QColor, QBrush
        self.table.setRowCount(0)
        for rank, r in enumerate(results, start=1):
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(rank)))
            self.table.setItem(row, 1, QTableWidgetItem(r.filename))
            verdict_item = QTableWidgetItem(r.verdict)
            self.table.setItem(row, 2, verdict_item)
            self.table.setItem(row, 3, QTableWidgetItem(str(r.score)))
            self.table.setItem(row, 4, QTableWidgetItem(f"{r.chi_max:.4f}"))
            self.table.setItem(row, 5, QTableWidgetItem(f"{r.rs_imbalance:.4f}"))
            color = (APP_COLORS["good"] if r.verdict == "CLEAN" else
                     APP_COLORS["warn"] if r.verdict == "SUSPICIOUS" else
                     APP_COLORS["bad"])
            # Theme-aware verdict colour (readable on the white row
            # background) — the previous code computed `color` then
            # unconditionally painted the cell Qt.white, which was unreadable
            # on the new light theme.
            f = verdict_item.font()
            f.setBold(True)
            verdict_item.setFont(f)
            verdict_item.setForeground(QBrush(QColor(color)))

    def _dispose_worker(self) -> None:
        """Wait for & dispose of any previously-started BatchWorker."""
        w = self._worker
        if w is None:
            return
        if w.isRunning():
            w.cancel()
            w.wait(3000)
        try:
            w.deleteLater()
        except Exception as _e:
            from ...utils.logger import get_logger
            get_logger("batch").debug("worker deleteLater: %s", _e)
        self._worker = None

    def _export(self, fmt: str) -> None:
        if not self._results:
            return
        from ...core.batch import batch_to_csv, batch_to_json
        path, _ = QFileDialog.getSaveFileName(
            self, "Export batch results", "batch_results",
            f"{fmt.upper()} files (*.{fmt});;All files (*)")
        if not path:
            return
        content = batch_to_csv(self._results) if fmt == "csv" \
            else batch_to_json(self._results)
        Path(path).write_text(content, encoding="utf-8")
        self.status_lbl.setText(f"Exported: {path}")
        self.session.set_status(f"Batch exported to {path}", "ok")
