"""Dashboard page — investigation overview."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QGridLayout, QHBoxLayout, QHeaderView,
                                QLabel, QTableWidget, QTableWidgetItem,
                                QWidget)

from ..theme import APP_COLORS
from ..widgets import Card, StatCard, MatplotlibCanvas
from . import BasePage
from ...visualization.plots import draw_batch_summary, draw_suspicion_gauge
from matplotlib.figure import Figure


class DashboardPage(BasePage):
    title = "Dashboard"
    subtitle = "Investigation overview — totals, recent activity and verdict mix."

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        # Stat cards row.
        stats_row = QWidget()
        g = QGridLayout(stats_row)
        g.setContentsMargins(0, 0, 0, 0)
        g.setSpacing(14)
        self.card_total = StatCard("Total analyzed", "0",
                                   APP_COLORS["text"], icon="nav_dashboard")
        self.card_clean = StatCard("Clean", "0",
                                   APP_COLORS["good"], icon="nav_chi")
        self.card_susp = StatCard("Suspicious", "0",
                                  APP_COLORS["warn"], icon="nav_visual")
        self.card_likely = StatCard("Likely hidden data", "0",
                                    APP_COLORS["bad"], icon="nav_payload")
        for i, c in enumerate([self.card_total, self.card_clean,
                               self.card_susp, self.card_likely]):
            g.addWidget(c, 0, i)
        self.addContent(stats_row)

        # Lower row: recent investigations table + verdict mix chart.
        lower = QHBoxLayout()
        lower.setSpacing(14)

        recent_card = Card("Recent investigations")
        recent_card.setMinimumHeight(260)
        self.history_table = QTableWidget(0, 4)
        self.history_table.setHorizontalHeaderLabels(
            ["Time", "Filename", "Verdict", "Score"])
        self.history_table.verticalHeader().setVisible(False)
        self.history_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.history_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.ResizeMode.ResizeToContents)
        # Empty-state message via an overlay
        self._empty_overlay = QLabel("No investigations yet — load an image to begin.")
        self._empty_overlay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty_overlay.setStyleSheet(
            f"color: {APP_COLORS['text_muted']}; font-size: 12px;"
            f"background: transparent; padding: 32px;")
        recent_card.addWidget(self._empty_overlay)
        recent_card.addWidget(self.history_table)
        lower.addWidget(recent_card, 3)

        # Verdict mix chart card.
        mix_card = Card("Verdict mix")
        mix_card.setMinimumHeight(260)
        self.mix_canvas = MatplotlibCanvas(parent=self)
        mix_card.addWidget(self.mix_canvas)
        lower.addWidget(mix_card, 2)

        wrap = QWidget()
        wrap.setLayout(lower)
        self.addContent(wrap)

        # Gauge card for current report.
        gauge_card = Card("Current image suspicion")
        gauge_card.setMinimumHeight(340)
        self.gauge_canvas = MatplotlibCanvas(parent=self)
        self.gauge_canvas.setMinimumHeight(300)
        self.gauge_canvas.setMaximumHeight(420)
        gauge_card.addWidget(self.gauge_canvas)
        self.addContent(gauge_card)

        self._refresh_mix([])
        self._refresh_gauge(None)
        self._on_stats()

    # ---- session hooks ----
    def _on_history(self, history) -> None:
        self.history_table.setRowCount(0)
        for entry in history:
            r = self.history_table.rowCount()
            self.history_table.insertRow(r)
            self.history_table.setItem(r, 0, QTableWidgetItem(entry.timestamp))
            self.history_table.setItem(r, 1, QTableWidgetItem(entry.filename))
            verdict_item = QTableWidgetItem(entry.verdict)
            color = APP_COLORS["good"] if entry.verdict == "CLEAN" else \
                    APP_COLORS["warn"] if entry.verdict == "SUSPICIOUS" else \
                    APP_COLORS["bad"]
            from PySide6.QtGui import QColor, QBrush
            verdict_item.setForeground(QBrush(QColor(color)))
            f = verdict_item.font()
            f.setBold(True)
            verdict_item.setFont(f)
            self.history_table.setItem(r, 2, verdict_item)
            self.history_table.setItem(r, 3, QTableWidgetItem(str(entry.score)))
        # Hide the empty-state overlay when we have data.
        if hasattr(self, "_empty_overlay"):
            self._empty_overlay.setVisible(not history)

    def _on_stats(self) -> None:
        s = self.session.stats
        self.card_total.setValue(str(s["total"]))
        self.card_clean.setValue(str(s["clean"]))
        self.card_susp.setValue(str(s["suspicious"]))
        self.card_likely.setValue(str(s["likely"]))
        # Read history once (the @property returns a fresh copy per call).
        history = self.session.history
        verdicts = [e.verdict for e in history]
        scores = [e.score for e in history]
        self._refresh_mix(verdicts, scores)

    def _on_report(self, report) -> None:
        self._refresh_gauge(report)

    # ---- helpers ----
    def _refresh_mix(self, verdicts, scores=None) -> None:
        scores = scores or [0] * len(verdicts)
        if not verdicts:
            fig = Figure()
            ax = fig.add_subplot(111)
            ax.text(0.5, 0.5, "No investigations yet",
                    ha="center", va="center",
                    color=APP_COLORS["text_muted"], transform=ax.transAxes)
            ax.set_axis_off()
            fig.patch.set_facecolor(APP_COLORS["bg"])
        else:
            fig = draw_batch_summary(verdicts, scores)
        self.mix_canvas.set_figure(fig)

    def _refresh_gauge(self, report) -> None:
        if report is None:
            fig = Figure()
            ax = fig.add_subplot(111)
            ax.text(0.5, 0.5, "No image loaded",
                    ha="center", va="center",
                    color=APP_COLORS["text_muted"], transform=ax.transAxes)
            ax.set_axis_off()
            fig.patch.set_facecolor(APP_COLORS["bg"])
        else:
            fig = draw_suspicion_gauge(report)
        self.gauge_canvas.set_figure(fig)
