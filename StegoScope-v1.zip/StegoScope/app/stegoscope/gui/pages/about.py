"""About page — comprehensive, professional application overview.

The About page is a multi-section presentation of:
  1. The application identity (name, version, tagline, developer, licence)
  2. The detection methodology (per-detector explanation)
  3. The forensic workflow (the 5-stage pipeline)
  4. Capabilities matrix
  5. Honest limitations & scope
  6. Privacy & security posture
  7. Acknowledgements & references
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel,
                                QVBoxLayout, QWidget)
from datetime import datetime

from ..theme import APP_COLORS
from ..widgets import Card, InfoCard, _make_transparent
from . import BasePage
from ... import (__app_name__, __developer__, __full_name__,
                  __license__, __tagline__, __version__)


class AboutPage(BasePage):
    title = "About"
    subtitle = ("Application identity, methodology, capabilities and "
                "operational scope.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        # ---- 1. Identity Hero Card -------------------------------------
        hero = Card()
        hero.setMinimumHeight(140)
        hv = QHBoxLayout()
        hv.setContentsMargins(28, 24, 28, 24)
        hv.setSpacing(24)

        # Logo block
        logo_label = QLabel()
        from pathlib import Path
        from PySide6.QtSvg import QSvgRenderer
        from PySide6.QtGui import QPixmap, QImage, QPainter
        from PySide6.QtCore import QByteArray
        logo_path = (Path(__file__).resolve().parents[2]
                     / "assets" / "icons" / "stegoscope_logo_pro.svg")
        if logo_path.exists():
            renderer = QSvgRenderer(QByteArray(logo_path.read_bytes()))
            if renderer.isValid():
                size = 96
                img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
                img.fill(Qt.GlobalColor.transparent)
                p = QPainter(img)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                renderer.render(p)
                p.end()
                logo_label.setPixmap(QPixmap.fromImage(img))
        _make_transparent(logo_label)
        logo_label.setFixedSize(100, 100)
        hv.addWidget(logo_label)

        # Identity text
        id_v = QVBoxLayout()
        id_v.setSpacing(4)
        name_lbl = QLabel(__app_name__)
        name_lbl.setStyleSheet(
            f"color: {APP_COLORS['text']}; font-size: 26px; font-weight: 800;"
            f"background: transparent; letter-spacing: 1px;")
        full_lbl = QLabel(__full_name__)
        full_lbl.setStyleSheet(
            f"color: {APP_COLORS['text_dim']}; font-size: 13px;"
            f"background: transparent;")
        tagline_lbl = QLabel(__tagline__.upper())
        tagline_lbl.setStyleSheet(
            f"color: {APP_COLORS['accent2']}; font-size: 10px; font-weight: 700;"
            f"letter-spacing: 3px; background: transparent;")
        id_v.addWidget(name_lbl)
        id_v.addWidget(full_lbl)
        id_v.addWidget(tagline_lbl)
        id_v.addSpacing(4)

        # Quick facts grid
        facts = QWidget()
        _make_transparent(facts)
        gl = QGridLayout(facts)
        gl.setContentsMargins(0, 0, 0, 0)
        gl.setHorizontalSpacing(20)
        gl.setVerticalSpacing(2)
        facts_list = [
            ("Version", f"{__version__}"),
            ("Developer", __developer__),
            ("Licence", __license__),
            ("Build date", datetime.now().strftime("%Y-%m-%d")),
        ]
        for i, (k, v) in enumerate(facts_list):
            col = i % 2
            row = i // 2
            k_lbl = QLabel(k.upper())
            k_lbl.setStyleSheet(
                f"color: {APP_COLORS['text_muted']}; font-size: 9px;"
                f"font-weight: 700; letter-spacing: 1.5px;"
                f"background: transparent;")
            v_lbl = QLabel(v)
            v_lbl.setStyleSheet(
                f"color: {APP_COLORS['text']}; font-size: 12px; font-weight: 500;"
                f"background: transparent;")
            wrap = QWidget()
            _make_transparent(wrap)
            wv = QVBoxLayout(wrap)
            wv.setContentsMargins(0, 0, 0, 0)
            wv.setSpacing(0)
            wv.addWidget(k_lbl)
            wv.addWidget(v_lbl)
            gl.addWidget(wrap, row, col)
        id_v.addWidget(facts)
        id_v.addStretch(1)
        hv.addLayout(id_v, 1)
        hero.addWidget(self._wrap_in_layout(hv))
        self.addContent(hero)

        # ---- 2. Mission Statement --------------------------------------
        mission_card = Card("Mission")
        mission_text = (
            "StegoScope is a desktop digital-forensics workbench purpose-built for the "
            "detection, statistical analysis and candidate extraction of information "
            "hidden inside bitmap images via least-significant-bit (LSB) steganography. "
            "It brings three independent, peer-reviewed statistical detectors under a "
            "single transparent verdict engine and presents them through a clean "
            "investigation-style interface so an analyst can move from raw image to a "
            "court-ready PDF report without leaving the application. Every byte of "
            "image data is processed locally; nothing is ever transmitted off the host "
            "machine."
        )
        m = QLabel(mission_text)
        m.setWordWrap(True)
        m.setStyleSheet(f"color: {APP_COLORS['text_dim']}; font-size: 12px;"
                        f"line-height: 150%; background: transparent;")
        mission_card.addWidget(m)
        self.addContent(mission_card)

        # ---- 3. Methodology --------------------------------------------
        method_card = Card("Detection methodology")
        method_text = (
            "StegoScope combines three independent, peer-reviewed statistical "
            "detectors into a transparent, weighted suspicion score. No single "
            "test is treated as authoritative — the engine cross-checks them."
        )
        m_intro = QLabel(method_text)
        m_intro.setWordWrap(True)
        m_intro.setStyleSheet(f"color: {APP_COLORS['text_dim']}; font-size: 12px;"
                              f"background: transparent;")
        method_card.addWidget(m_intro)

        # Three detector info cards in a row.
        det_row = QWidget()
        _make_transparent(det_row)
        dh = QHBoxLayout(det_row)
        dh.setContentsMargins(0, 8, 0, 0)
        dh.setSpacing(12)
        detectors = [
            ("nav_lsb", "LSB-plane analysis",
             "Measures the 0/1 bit balance and run-length structure of each "
             "channel's least-significant-bit plane. Random embedding tends "
             "to push bit balance toward 50% and lengthen or shorten the "
             "longest run of identical bits.",
             APP_COLORS["accent"]),
            ("nav_chi", "Chi-Square (Westfeld-Pfitzmann)",
             "Tests whether the value-pair histogram of consecutive pixels is "
             "consistent with random LSB replacement. The PoVs (pairs of "
             "values that differ only in the LSB) should converge for an "
             "embedded image and diverge for a natural one.",
             APP_COLORS["accent2"]),
            ("nav_rs", "RS-analysis (Fridrich-Goljan-Du)",
             "Partitions the image into groups and measures the regular/"
             "singular ratio under positive (M) and negative (-M) flipping "
             "masks. LSB replacement breaks the symmetry between R_M-S_M "
             "and R_-M-S_-M in a way that reveals the embedding rate.",
             APP_COLORS["accent3"]),
        ]
        for icon, title, body, accent in detectors:
            c = InfoCard(title, body, icon=icon, accent=accent)
            c.setMinimumHeight(140)
            dh.addWidget(c, 1)
        method_card.addWidget(det_row)

        # Weighting summary
        weight_lbl = QLabel(
            "Score weighting:  LSB 20%  ·  Chi-Square 40%  ·  RS 40%   "
            "(configurable in Settings).\n"
            "Verdict bands:  CLEAN ≤ 40  ·  SUSPICIOUS ≤ 70  ·  LIKELY HIDDEN > 70")
        weight_lbl.setWordWrap(True)
        weight_lbl.setStyleSheet(
            f"color: {APP_COLORS['text']}; font-size: 11px; font-weight: 600;"
            f"background: {APP_COLORS['panel_alt']}; padding: 12px 14px;"
            f"border-radius: 8px; border-left: 3px solid {APP_COLORS['accent2']};")
        method_card.addWidget(weight_lbl)
        self.addContent(method_card)

        # ---- 4. Workflow -----------------------------------------------
        flow_card = Card("Investigation workflow")
        flow_text = QLabel(
            "Every analysis follows the same five-stage forensic pipeline. The "
            "interface mirrors this pipeline so the analyst always knows where "
            "they are in the process.")
        flow_text.setWordWrap(True)
        flow_text.setStyleSheet(f"color: {APP_COLORS['text_dim']}; font-size: 12px;"
                                f"background: transparent;")
        flow_card.addWidget(flow_text)

        steps_row = QWidget()
        _make_transparent(steps_row)
        sh = QHBoxLayout(steps_row)
        sh.setContentsMargins(0, 10, 0, 0)
        sh.setSpacing(8)
        steps = [
            ("01", "ACQUIRE", "Load PNG / BMP via the Image Analysis page. "
                                "EXIF, mode and dimensions are catalogued."),
            ("02", "DETECT", "LSB, Chi-Square and RS-analysis run in parallel "
                              "off the UI thread, each on every channel."),
            ("03", "SCORE", "Per-channel contributions are weighted and "
                             "combined into a 0–100 suspicion score."),
            ("04", "EXTRACT", "Optional candidate LSB-payload extraction. "
                              "Bytes are treated as untrusted candidate data."),
            ("05", "REPORT", "Generate a TXT / JSON / CSV / PDF report for "
                              "evidence or downstream tooling."),
        ]
        for num, title, body in steps:
            step = QFrame()
            step.setObjectName("Card")
            step.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
            step.setMinimumHeight(130)
            sv = QVBoxLayout(step)
            sv.setContentsMargins(14, 12, 14, 12)
            sv.setSpacing(4)
            num_lbl = QLabel(num)
            num_lbl.setStyleSheet(
                f"color: {APP_COLORS['accent2']}; font-size: 18px;"
                f"font-weight: 800; background: transparent;")
            title_lbl = QLabel(title)
            title_lbl.setStyleSheet(
                f"color: {APP_COLORS['text']}; font-size: 10px; font-weight: 700;"
                f"letter-spacing: 2px; background: transparent;")
            body_lbl = QLabel(body)
            body_lbl.setWordWrap(True)
            body_lbl.setStyleSheet(
                f"color: {APP_COLORS['text_dim']}; font-size: 11px;"
                f"background: transparent;")
            sv.addWidget(num_lbl)
            sv.addWidget(title_lbl)
            sv.addWidget(body_lbl)
            sv.addStretch(1)
            sh.addWidget(step, 1)
        flow_card.addWidget(steps_row)
        self.addContent(flow_card)

        # ---- 5. Capabilities matrix ------------------------------------
        cap_card = Card("Capabilities")
        cap_row = QWidget()
        _make_transparent(cap_row)
        ch = QHBoxLayout(cap_row)
        ch.setContentsMargins(0, 0, 0, 0)
        ch.setSpacing(12)

        cap_left = [
            ("Single-image analysis", "PNG, BMP, RGB / RGBA / grayscale"),
            ("Image cleaner", "Strip metadata + neutralise LSB plane"),
            ("Batch scanning", "Folder, recursive, optional payload extraction"),
            ("LSB-plane visualisation", "Per-channel binary plane export"),
        ]
        cap_right = [
            ("Candidate payload extraction", "Hex + ASCII preview, .bin export"),
            ("Forensic reports", "TXT, JSON, CSV, PDF"),
            ("Statistical charts", "Score breakdown, chi-square, RS fractions"),
            ("100% local processing", "No telemetry, no network calls"),
        ]
        for caps in (cap_left, cap_right):
            col = QWidget()
            _make_transparent(col)
            cv = QVBoxLayout(col)
            cv.setContentsMargins(0, 0, 0, 0)
            cv.setSpacing(6)
            for title, body in caps:
                row = QWidget()
                _make_transparent(row)
                rh = QHBoxLayout(row)
                rh.setContentsMargins(0, 0, 0, 0)
                rh.setSpacing(8)
                dot = QLabel("●")
                dot.setStyleSheet(
                    f"color: {APP_COLORS['accent2']}; font-size: 9px;"
                    f"background: transparent;")
                dot.setFixedWidth(12)
                txt = QLabel(f"<b>{title}</b> — {body}")
                txt.setStyleSheet(
                    f"color: {APP_COLORS['text_dim']}; font-size: 11px;"
                    f"background: transparent;")
                txt.setWordWrap(True)
                rh.addWidget(dot)
                rh.addWidget(txt, 1)
                cv.addWidget(row)
            cv.addStretch(1)
            ch.addWidget(col, 1)
        cap_card.addWidget(cap_row)
        self.addContent(cap_card)

        # ---- 6. Limitations & Privacy ----------------------------------
        bottom = QHBoxLayout()
        bottom.setSpacing(14)

        limits_card = Card("Honest limitations")
        limits_text = (
            "StegoScope detects <b>LSB-replacement</b> steganography. It does "
            "not detect LSB matching (±1), adaptive or model-based schemes "
            "(HUGO, WOW, S-UNIWARD), or payloads hidden in lossy-compressed "
            "sources such as JPEG. A CLEAN verdict means <i>no anomaly was "
            "found</i> — it is not proof that no payload exists. Extracted "
            "bytes are <b>candidate data</b>, treated as untrusted throughout, "
            "and never executed by StegoScope."
        )
        l = QLabel(limits_text)
        l.setWordWrap(True)
        l.setTextFormat(Qt.TextFormat.RichText)
        l.setStyleSheet(
            f"color: {APP_COLORS['warn']}; font-size: 12px;"
            f"background: transparent; line-height: 140%;")
        limits_card.addWidget(l)
        bottom.addWidget(limits_card, 1)

        privacy_card = Card("Privacy & security posture")
        privacy_text = (
            "All analysis is performed locally. StegoScope makes no outbound "
            "network calls — no telemetry, no crash reporting, no anonymous "
            "usage statistics. Extracted candidate payloads are written only "
            "when the analyst explicitly exports them. The application runs "
            "as an unprivileged user process; it does not request root, does "
            "not install services, and does not modify the system."
        )
        pr = QLabel(privacy_text)
        pr.setWordWrap(True)
        pr.setStyleSheet(
            f"color: {APP_COLORS['good']}; font-size: 12px;"
            f"background: transparent; line-height: 140%;")
        privacy_card.addWidget(pr)
        bottom.addWidget(privacy_card, 1)
        bw = QWidget(); bw.setLayout(bottom); _make_transparent(bw)
        self.addContent(bw)

        # ---- 7. References / Acknowledgements --------------------------
        ref_card = Card("References & acknowledgements")
        ref_text = (
            "• Westfeld, A. & Pfitzmann, A. (2000). <i>Attacks on Steganographic "
            "Systems.</i> LNCS 1768 — the Chi-Square statistical attack.<br/><br/>"
            "• Fridrich, J., Goljan, M. & Du, R. (2001). <i>Reliable Detection "
            "of LSB Steganography in Color and Grayscale Images.</i> "
            "IEEE Multimedia — the RS-analysis detector.<br/><br/>"
            "• Built with PySide6 / Qt, NumPy, SciPy, Matplotlib and "
            "ReportLab. Open-source under the MIT licence."
        )
        r = QLabel(ref_text)
        r.setWordWrap(True)
        r.setTextFormat(Qt.TextFormat.RichText)
        r.setStyleSheet(
            f"color: {APP_COLORS['text_dim']}; font-size: 11px;"
            f"background: transparent; line-height: 160%;")
        ref_card.addWidget(r)
        self.addContent(ref_card)

    # ---- helpers --------------------------------------------------------
    def _wrap_in_layout(self, layout) -> QWidget:
        wrap = QWidget()
        _make_transparent(wrap)
        wrap.setLayout(layout)
        return wrap
