"""Settings page — verdict threshold configuration."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFormLayout, QHBoxLayout, QLabel,
                                QPushButton, QSlider, QWidget)

from ..theme import APP_COLORS
from ..widgets import Card
from . import BasePage
from ...utils.config import get_config


class SettingsPage(BasePage):
    title = "Settings"
    subtitle = ("Adjust the verdict-engine thresholds. Changes apply to "
                "subsequent analyses and are not persisted to disk.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)
        self.cfg = get_config()
        self.thr = self.cfg.thresholds
        self._updating_thresholds = False

        card = Card("Verdict thresholds")
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self.clean_slider, self.clean_val = self._slider(0, 100,
                                                          self.thr.clean_max)
        form.addRow("CLEAN ≤", self._row(self.clean_slider, self.clean_val, "/ 100"))
        self.susp_slider, self.susp_val = self._slider(0, 100,
                                                        self.thr.suspicious_max)
        form.addRow("SUSPICIOUS ≤", self._row(self.susp_slider, self.susp_val, "/ 100"))

        self.clean_slider.valueChanged.connect(self._on_clean)
        self.susp_slider.valueChanged.connect(self._on_susp)

        weights_card = Card("Advanced detector weights")
        wform = QFormLayout()
        self.w_lsb_s, self.w_lsb_v = self._slider(0, 100, int(self.thr.weight_lsb * 100))
        self.w_chi_s, self.w_chi_v = self._slider(0, 100, int(self.thr.weight_chi * 100))
        self.w_rs_s, self.w_rs_v = self._slider(0, 100, int(self.thr.weight_rs * 100))
        wform.addRow("LSB weight", self._row(self.w_lsb_s, self.w_lsb_v, "%"))
        wform.addRow("Chi-Square weight", self._row(self.w_chi_s, self.w_chi_v, "%"))
        wform.addRow("RS weight", self._row(self.w_rs_s, self.w_rs_v, "%"))
        self.w_lsb_s.valueChanged.connect(self._on_weights)
        self.w_chi_s.valueChanged.connect(self._on_weights)
        self.w_rs_s.valueChanged.connect(self._on_weights)

        self.weight_status = QLabel("")
        self.weight_status.setStyleSheet(f"color:{APP_COLORS['text_dim']};")
        wform.addRow("", self.weight_status)
        reset_btn = QPushButton("Reset recommended defaults")
        reset_btn.setToolTip("Restore CLEAN 40, SUSPICIOUS 70 and weights 20/40/40.")
        reset_btn.clicked.connect(self._reset_defaults)
        wform.addRow("", reset_btn)
        self._on_weights()

        card.addWidget(self._wrap(form))
        self.addContent(card)
        weights_card.addWidget(self._wrap(wform))
        self.addContent(weights_card)

        note = QLabel("Changes affect new analyses only. Detector weights are "
                      "normalised automatically; use Reset recommended defaults "
                      "if you are unsure.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color:{APP_COLORS['text_dim']};font-size:11px;")
        self.addContent(note)

    def _slider(self, lo, hi, val):
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(lo, hi)
        s.setValue(val)
        v = QLabel(str(val))
        v.setMinimumWidth(36)
        v.setAlignment(Qt.AlignmentFlag.AlignCenter)
        return s, v

    def _row(self, slider, label, suffix="") -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(slider, 1)
        h.addWidget(label)
        h.addWidget(QLabel(suffix))
        return w

    def _wrap(self, form) -> QWidget:
        w = QWidget(); w.setLayout(form); return w

    def _on_clean(self, val):
        if self._updating_thresholds:
            return
        susp = self.susp_slider.value()
        clean = min(max(int(val), 0), max(0, susp - 1))
        if clean != val or clean >= susp:
            self._set_thresholds(clean, max(susp, clean + 1))
        else:
            self.thr.clean_max = clean
            self.clean_val.setText(str(clean))

    def _on_susp(self, val):
        if self._updating_thresholds:
            return
        clean = self.clean_slider.value()
        suspicious = max(int(val), clean + 1)
        suspicious = min(suspicious, 100)
        if suspicious <= clean:
            clean = max(0, suspicious - 1)
        self._set_thresholds(clean, suspicious)

    def _set_thresholds(self, clean: int, suspicious: int) -> None:
        """Atomically apply valid, strictly ordered threshold values."""
        clean = max(0, min(int(clean), 99))
        suspicious = max(clean + 1, min(int(suspicious), 100))
        self._updating_thresholds = True
        try:
            self.clean_slider.setValue(clean)
            self.susp_slider.setValue(suspicious)
        finally:
            self._updating_thresholds = False
        self.clean_val.setText(str(clean))
        self.susp_val.setText(str(suspicious))
        self.thr.clean_max = clean
        self.thr.suspicious_max = suspicious

    def _on_weights(self):
        l = self.w_lsb_s.value()
        c = self.w_chi_s.value()
        r = self.w_rs_s.value()
        self.w_lsb_v.setText(str(l))
        self.w_chi_v.setText(str(c))
        self.w_rs_v.setText(str(r))
        total = l + c + r
        if total == 0:
            self.weight_status.setText("weights sum to 0 — invalid")
            self.weight_status.setStyleSheet(f"color:{APP_COLORS['bad']};")
            return
        # Normalise so the three weights always sum to 1.0.
        self.thr.weight_lsb = l / total
        self.thr.weight_chi = c / total
        self.thr.weight_rs = r / total
        if total == 100:
            self.weight_status.setText("weights sum to 1.00 ✓")
            self.weight_status.setStyleSheet(f"color:{APP_COLORS['good']};")
        else:
            self.weight_status.setText(
                f"raw sum {total/100:.2f} — normalised to 1.00")
            self.weight_status.setStyleSheet(f"color:{APP_COLORS['warn']};")

    def _reset_defaults(self) -> None:
        self._set_thresholds(40, 70)
        self._updating_thresholds = True
        try:
            self.w_lsb_s.setValue(20)
            self.w_chi_s.setValue(40)
            self.w_rs_s.setValue(40)
        finally:
            self._updating_thresholds = False
        self._on_weights()
