"""Reports page — generate TXT/JSON/CSV/PDF from the current report."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout,
                                QLabel, QMessageBox, QPushButton,
                                QTextEdit, QWidget)

from ..widgets import Card
from . import BasePage
from ...reporting import REPORT_FORMATS, ReportFormatError, save_report, to_txt


class ReportsPage(BasePage):
    title = "Reports"
    subtitle = ("Generate a forensic report for the currently loaded "
                "image in TXT, JSON, CSV or PDF format.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Format:"))
        self.fmt_combo = QComboBox()
        for f in REPORT_FORMATS:
            self.fmt_combo.addItem(f.upper(), f)
        self.save_btn = QPushButton("Save report…")
        self.save_btn.setObjectName("Primary")
        self.save_btn.clicked.connect(self._save)
        ctrl.addWidget(self.fmt_combo)
        ctrl.addWidget(self.save_btn)
        ctrl.addStretch(1)
        cw = QWidget(); cw.setLayout(ctrl)
        self.addContent(cw)

        preview_card = Card("TXT preview")
        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        preview_card.addWidget(self.preview)
        self.addContent(preview_card)

        self._refresh_empty()

    def _refresh_empty(self) -> None:
        self.preview.setPlainText(
            "Load and analyze an image to see a TXT report preview here.")

    def _on_report(self, report) -> None:
        if report is None:
            self._refresh_empty()
            return
        self.preview.setPlainText(to_txt(report))

    def _save(self) -> None:
        report = self.session.report
        if report is None:
            QMessageBox.warning(self, "No report",
                                "Analyze an image first.")
            return
        fmt = self.fmt_combo.currentData()
        stem = Path(report.info.filename).stem + "_report"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save report", f"{stem}.{fmt}",
            f"{fmt.upper()} files (*.{fmt});;All files (*)")
        if not path:
            return
        try:
            out = save_report(report, path, fmt=fmt)
        except ReportFormatError as exc:
            QMessageBox.critical(self, "Report error", str(exc))
            return
        self.session.set_status(f"Report written: {out}", "ok")
