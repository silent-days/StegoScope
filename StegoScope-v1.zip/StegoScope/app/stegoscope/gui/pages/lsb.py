"""LSB Analysis page."""

from __future__ import annotations

from PySide6.QtWidgets import (QHBoxLayout, QHeaderView, QLabel,
                                QTableWidget, QTableWidgetItem, QWidget)

from ..theme import APP_COLORS
from ..widgets import Card, MatplotlibCanvas
from . import BasePage
from ...visualization.plots import draw_lsb_planes, draw_bit_distribution


class LSBAnalysisPage(BasePage):
    title = "Advanced LSB Analysis"
    subtitle = ("Per-channel least-significant-bit statistics, bit "
                "distribution and LSB-plane visualisations.")

    def __init__(self, session, parent=None) -> None:
        super().__init__(session, parent)

        stats_card = Card("LSB statistics")
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["Channel", "0-bits %", "1-bits %", "LSB mean",
             "Longest run", "Run bit", "Total bits"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for i in range(7):
            self.table.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.ResizeMode.Stretch if i in (0,) else
                QHeaderView.ResizeMode.ResizeToContents)
        stats_card.addWidget(self.table)
        self.addContent(stats_card)

        self.imbalance_lbl = QLabel("Channel imbalance: —")
        self.imbalance_lbl.setStyleSheet(f"color:{APP_COLORS['text_dim']};")
        stats_card.addWidget(self.imbalance_lbl)

        charts = QHBoxLayout()
        charts.setSpacing(14)
        dist_card = Card("Bit distribution")
        self.dist_canvas = MatplotlibCanvas(parent=self)
        dist_card.addWidget(self.dist_canvas)
        charts.addWidget(dist_card, 1)

        planes_card = Card("LSB planes")
        self.planes_canvas = MatplotlibCanvas(parent=self)
        planes_card.addWidget(self.planes_canvas)
        charts.addWidget(planes_card, 1)
        cw = QWidget(); cw.setLayout(charts)
        self.addContent(cw)

        self._refresh_empty()

    def _refresh_empty(self) -> None:
        self.table.setRowCount(0)
        self.imbalance_lbl.setText("Channel imbalance: —")

    def _on_report(self, report) -> None:
        if report is None:
            self._refresh_empty()
            return
        self.table.setRowCount(0)
        for c in report.lsb.channels:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(c.channel))
            self.table.setItem(r, 1, QTableWidgetItem(f"{c.zero_pct:.3f}"))
            self.table.setItem(r, 2, QTableWidgetItem(f"{c.one_pct:.3f}"))
            self.table.setItem(r, 3, QTableWidgetItem(f"{c.lsb_mean:.4f}"))
            self.table.setItem(r, 4, QTableWidgetItem(str(c.longest_run)))
            self.table.setItem(r, 5, QTableWidgetItem(str(c.longest_run_value)))
            self.table.setItem(r, 6, QTableWidgetItem(f"{c.total_bits:,}"))
        self.imbalance_lbl.setText(
            f"Channel imbalance (max−min LSB mean): "
            f"{report.lsb.channel_imbalance:.6f}")
        self.dist_canvas.set_figure(draw_bit_distribution(report))
        # LSB planes need the loaded image; rebuild from the report path.
        try:
            from ...core.image_loader import ImageLoader
            img = ImageLoader().load(report.info.path)
            self.planes_canvas.set_figure(draw_lsb_planes(img))
        except Exception:
            from matplotlib.figure import Figure
            f = Figure()
            ax = f.add_subplot(111)
            ax.set_axis_off()
            ax.text(0.5, 0.5, "LSB planes unavailable",
                    ha="center", va="center",
                    color=APP_COLORS["text_muted"], transform=ax.transAxes)
            self.planes_canvas.set_figure(f)
