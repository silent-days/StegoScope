"""Animated boot splash screen for StegoScope.

A 3-second premium splash that runs while the application initialises.
Painted with QPainter so it has zero external dependencies and works
on every platform that PySide6 supports.

Visual sequence (~3s total):
  0.0 - 1.2s  : logo fades + scales in, outer ring draws clockwise
  1.2 - 2.0s  : tagline + version fade in
  2.0 - 3.0s  : progress bar fills, status text rotates through
                "Initializing detection engine", "Loading detectors",
                "Preparing interface"
  3.0s        : emits finished; main window is shown
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import (QRectF, Qt, QTimer, Signal, QElapsedTimer)
from PySide6.QtGui import (QBrush, QColor, QFont, QImage, QPainter, QPen,
                            QPixmap)
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QWidget

from .. import __app_name__, __tagline__, __version__, __developer__

_LOGO_SVG = (Path(__file__).resolve().parents[1]
             / "assets" / "icons" / "stegoscope_logo_pro.svg")

_STATUS_MESSAGES = [
    "Initializing detection engine",
    "Loading LSB · Chi-Square · RS detectors",
    "Preparing forensic interface",
    "Ready",
]


def _load_svg_pixmap(path: Path, size: int = 220) -> QPixmap:
    """Render the SVG logo into a pixmap of the requested size."""
    if not path.exists():
        return QPixmap()
    renderer = QSvgRenderer(str(path))
    if not renderer.isValid():
        return QPixmap()
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    renderer.render(p)
    p.end()
    return QPixmap.fromImage(img)


class BootSplash(QWidget):
    """Frameless, borderless splash with custom-painted animation."""

    finished = Signal()

    def __init__(self, *, duration_ms: int = 3000, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.SplashScreen
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setFixedSize(560, 420)

        self._duration = duration_ms
        self._logo = _load_svg_pixmap(_LOGO_SVG, size=220)
        self._progress = 0.0
        self._status_idx = 0
        self._status_alpha = 0.0
        self._logo_alpha = 0.0
        self._logo_scale = 0.7
        self._ring_angle = 0.0
        self._tagline_alpha = 0.0

        # Centralise on the primary screen.
        screen = self.screen().availableGeometry()
        self.move(screen.center().x() - self.width() // 2,
                  screen.center().y() - self.height() // 2)

        # High-frequency repaint timer (~60 FPS).
        self._elapsed = QElapsedTimer()
        self._elapsed.start()
        self._timer = QTimer(self)
        self._timer.setInterval(16)  # ~60fps
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    # ------------------------------------------------------------------ #
    def _tick(self) -> None:
        t = self._elapsed.elapsed()  # ms
        # --- stage timings -------------------------------------------------
        # 0–1.2s: logo fades + scales in
        # 0.5–2.0s: outer ring draws clockwise
        # 1.0–1.8s: tagline fades in
        # 2.0–3.0s: progress bar fills 0→100, status text rotates
        # 3.0s   : finish
        if t <= 1200:
            p = t / 1200.0
            # ease-out cubic
            e = 1 - (1 - p) ** 3
            self._logo_alpha = e
            self._logo_scale = 0.7 + 0.3 * e
        else:
            self._logo_alpha = 1.0
            self._logo_scale = 1.0

        if 500 <= t <= 2000:
            p = (t - 500) / 1500.0
            self._ring_angle = 360.0 * p
        elif t > 2000:
            self._ring_angle = 360.0

        if 1000 <= t <= 1800:
            p = (t - 1000) / 800.0
            self._tagline_alpha = p
        elif t > 1800:
            self._tagline_alpha = 1.0

        if t >= 2000:
            p = min((t - 2000) / 1000.0, 1.0)
            self._progress = p
            # Cycle status every 250 ms.
            target_idx = min(int((t - 2000) / 250), len(_STATUS_MESSAGES) - 1)
            if target_idx != self._status_idx:
                self._status_idx = target_idx
            self._status_alpha = min(1.0, (t - 2050) / 400.0)
        else:
            self._progress = 0.0

        self.update()

        if t >= self._duration:
            self._timer.stop()
            self.finished.emit()
            self.close()

    # ------------------------------------------------------------------ #
    def paintEvent(self, event) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # Read live palette so the splash adapts to the current theme mode.
        from .theme import get_palette
        c = get_palette()
        bg = QColor(c["panel"])         # white in light, deep slate in dark
        border = QColor(c["border"])
        track = QColor(c["border"])
        accent = QColor(c["accent"])
        accent2 = QColor(c["accent2"])
        text = QColor(c["text"])
        text_dim = QColor(c["text_dim"])
        text_muted = QColor(c["text_muted"])

        # ---- Background: flat solid colour, no rounded tile or shadow ----
        p.setBrush(QBrush(bg))
        p.setPen(QPen(border, 1))
        p.drawRect(self.rect().adjusted(0, 0, -1, -1))

        # ---- Outer animated ring ----
        cx, cy = self.width() / 2, 175
        ring_r = 96
        rect = QRectF(cx - ring_r, cy - ring_r, ring_r * 2, ring_r * 2)
        p.setPen(QPen(track, 3, Qt.PenStyle.SolidLine,
                       Qt.PenCapStyle.RoundCap))
        p.drawArc(rect, 0, 360 * 16)

        # Progress arc (primary accent)
        pen = QPen(accent, 3, Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        sweep = int(self._ring_angle * 16)
        if sweep > 0:
            p.drawArc(rect, 90 * 16, -sweep)

        # ---- Logo pixmap (scaled + alpha) ----
        if not self._logo.isNull() and self._logo_alpha > 0:
            scale = self._logo_scale
            sz = int(140 * scale)
            pix = self._logo.scaled(sz, sz, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            if self._logo_alpha < 1.0:
                alpha_img = QImage(pix.size(), QImage.Format.Format_ARGB32_Premultiplied)
                alpha_img.fill(Qt.GlobalColor.transparent)
                ap = QPainter(alpha_img)
                ap.setOpacity(self._logo_alpha)
                ap.drawPixmap(0, 0, pix)
                ap.end()
                pix = QPixmap.fromImage(alpha_img)
            px = int(cx - pix.width() / 2)
            py = int(cy - pix.height() / 2)
            p.drawPixmap(px, py, pix)

        # ---- App name (primary text colour) ----
        p.setPen(QColor(text.red(), text.green(), text.blue(),
                         int(255 * self._logo_alpha)))
        name_font = QFont("Segoe UI", 22, QFont.Weight.Bold)
        p.setFont(name_font)
        p.drawText(QRectF(0, 290, self.width(), 30), Qt.AlignmentFlag.AlignCenter,
                   __app_name__)

        # ---- Tagline + version ----
        tag_alpha = int(255 * self._tagline_alpha)
        p.setPen(QColor(accent2.red(), accent2.green(), accent2.blue(), tag_alpha))
        p.setFont(QFont("Segoe UI", 10, QFont.Weight.Medium))
        p.drawText(QRectF(0, 320, self.width(), 18), Qt.AlignmentFlag.AlignCenter,
                   __tagline__.upper())

        p.setPen(QColor(text_dim.red(), text_dim.green(), text_dim.blue(), tag_alpha))
        p.setFont(QFont("Segoe UI", 9))
        p.drawText(QRectF(0, 340, self.width(), 16), Qt.AlignmentFlag.AlignCenter,
                   f"Version {__version__}  ·  {__developer__}")

        # ---- Progress bar ----
        bar_x = 130
        bar_w = self.width() - 260
        bar_y = 370
        bar_h = 5
        bar_rect = QRectF(bar_x, bar_y, bar_w, bar_h)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(track))
        p.drawRect(bar_rect)
        if self._progress > 0:
            p.setBrush(QBrush(accent))
            fill_rect = QRectF(bar_x, bar_y, bar_w * self._progress, bar_h)
            p.drawRect(fill_rect)

        # ---- Status text ----
        if self._status_alpha > 0:
            alpha = int(180 * self._status_alpha)
            p.setPen(QColor(text_muted.red(), text_muted.green(),
                             text_muted.blue(), alpha))
            p.setFont(QFont("Segoe UI", 9))
            msg = _STATUS_MESSAGES[self._status_idx]
            p.drawText(QRectF(0, bar_y + 14, self.width(), 16),
                       Qt.AlignmentFlag.AlignCenter, msg)

        # ---- Bottom-left brand accent ----
        p.setPen(QColor(accent.red(), accent.green(), accent.blue(), 110))
        p.setFont(QFont("Segoe UI", 8))
        p.drawText(QRectF(20, self.height() - 22, 200, 14),
                   Qt.AlignmentFlag.AlignLeft, "DIGITAL FORENSICS")

        p.end()
