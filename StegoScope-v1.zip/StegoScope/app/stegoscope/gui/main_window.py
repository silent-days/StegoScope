"""StegoScope main window and GUI launch entry point.

The application shell:
* shows an animated boot splash for ~3 seconds while modules import;
* then presents the sidebar + top bar + stacked pages with smooth
  page-transition animations.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QApplication, QButtonGroup, QFrame,
                                QHBoxLayout, QLabel, QMainWindow,
                                QPushButton, QScrollArea, QStackedWidget,
                                QVBoxLayout, QWidget)

from .. import __app_name__, __developer__, __version__
from ..utils.logger import init_logging
from .pages import (AboutPage, BatchScannerPage, ChiSquarePage,
                     CleanerPage, DashboardPage, ImageAnalysisPage,
                     LSBAnalysisPage, PayloadInspectorPage, ReportsPage,
                     RSAnalysisPage, SettingsPage, VisualForensicsPage)
from .session import SessionManager
from .theme import APP_COLORS
from .nav_button import NavButton
from .splash import BootSplash

# (button label, icon-name, page factory) in sidebar order.
_NAV = [
    ("Dashboard",        "nav_dashboard", DashboardPage),
    ("Image Analysis",   "nav_image",     ImageAnalysisPage),
    ("Image Cleaner",    "nav_cleaner",   CleanerPage),
    ("Advanced LSB",     "nav_lsb",       LSBAnalysisPage),
    ("Chi-Square",       "nav_chi",       ChiSquarePage),
    ("RS Analysis",      "nav_rs",        RSAnalysisPage),
    ("Batch Scanner",    "nav_batch",     BatchScannerPage),
    ("Payload Inspector","nav_payload",   PayloadInspectorPage),
    ("Visual Forensics", "nav_visual",    VisualForensicsPage),
    ("Reports",          "nav_reports",   ReportsPage),
    ("Settings",         "nav_settings",  SettingsPage),
    ("About",            "nav_about",     AboutPage),
]

# Sidebar grouping (label, indices) — purely decorative.
_NAV_GROUPS = [
    ("OVERVIEW",         (0,)),
    ("ANALYSIS",         (1, 3, 4, 5)),
    ("CLEAN & INVESTIGATE", (2, 6, 7, 8, 9)),
    ("SYSTEM",           (10, 11)),
]


class _FadeStack(QStackedWidget):
    """Classic page stack with immediate, non-animated page switching."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

    def setCurrentIndex(self, idx: int) -> None:  # noqa: N802
        super().setCurrentIndex(idx)


class MainWindow(QMainWindow):
    """The application shell: sidebar + top bar + stacked pages."""

    def __init__(self) -> None:
        super().__init__()
        # launch_gui normally binds the stylesheet first, but MainWindow is
        # also used directly by desktop launchers and tests.  Binding here
        # prevents a partially unstyled/frozen-looking GUI in those paths.
        from PySide6.QtWidgets import QApplication
        from .theme_manager import get_theme_manager
        app = QApplication.instance()
        if app is not None:
            get_theme_manager().set_app(app)
        self.setWindowTitle(f"{__app_name__} — Advanced Steganography Intelligence Suite")
        self.resize(1280, 820)
        self.setMinimumSize(1000, 640)

        # Application icon
        icon_path = (Path(__file__).resolve().parents[1]
                     / "assets" / "icons" / "stegoscope_logo.png")
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

        self.session = SessionManager()

        central = QFrame()
        central.setObjectName("Root")
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())
        right = QFrame()
        right.setObjectName("Right")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        rl.addWidget(self._build_topbar())
        rl.addWidget(self._build_stack(), 1)
        root.addWidget(right, 1)

        self.setCentralWidget(central)

        # Expose the nav definition as a public attribute for tests and
        # external introspection.
        self._NAV = _NAV

        # Initial state.
        self.session.set_status("Ready", "idle")
        self._nav_buttons[0].setChecked(True)
        self._stack.setCurrentIndex(0)

    # ------------------------------------------------------------------ #
    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(240)
        v = QVBoxLayout(sidebar)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        # Brand header with version
        brand = QLabel(__app_name__.upper())
        brand.setObjectName("Brand")
        sub = QLabel(f"v{__version__}  ·  {__developer__}")
        sub.setObjectName("BrandSub")
        tagline = QLabel("STEGANOGRAPHY INTEL")
        tagline.setObjectName("SidebarTagline")
        v.addWidget(brand)
        v.addWidget(sub)
        v.addWidget(tagline)

        # Group nav items with section labels.
        self._nav_group = QButtonGroup(self)
        self._nav_group.setExclusive(True)
        self._nav_buttons: list[NavButton] = []
        # Build a flat list of items we'll display (skipping the group header
        # decorations — sections are rendered as labels in between).
        for group_label, indices in _NAV_GROUPS:
            sep = QLabel(group_label)
            sep.setObjectName("NavSeparator")
            v.addWidget(sep)
            for i in indices:
                label, icon_name, _factory = _NAV[i]
                btn = NavButton(icon_name, label)
                btn.clicked.connect(lambda _=False, idx=i: self._go(idx))
                self._nav_group.addButton(btn, i)
                v.addWidget(btn)
                self._nav_buttons.append(btn)
                # Keep the same button instance reference for index-based
                # access (NavButton.setChecked uses our custom paint path).
                # _nav_buttons[i] must point to the right button.
                # Override by re-arranging in original _NAV order:
        # Re-order _nav_buttons so that _nav_buttons[i] corresponds to _NAV[i]
        ordered = [None] * len(_NAV)
        for btn in list(self._nav_group.buttons()):
            ordered[self._nav_group.id(btn)] = btn
        self._nav_buttons = ordered

        v.addStretch(1)

        # Footer
        footer_wrap = QFrame()
        footer_wrap.setObjectName("SidebarFooter")
        footer_wrap.setStyleSheet("QFrame#SidebarFooter { background: transparent; }")
        fl = QVBoxLayout(footer_wrap)
        fl.setContentsMargins(20, 0, 20, 18)
        fl.setSpacing(2)
        foot1 = QLabel("Detect · Analyze · Investigate")
        foot1.setStyleSheet(f"color:{APP_COLORS['sidebar_dim']};font-size:10px;"
                             f"letter-spacing:1px;background:transparent;")
        foot2 = QLabel("MIT Licensed  ·  All analysis local")
        foot2.setStyleSheet(f"color:{APP_COLORS['sidebar_dim']};font-size:9px;"
                            f"background:transparent;")
        fl.addWidget(foot1)
        fl.addWidget(foot2)
        v.addWidget(footer_wrap)
        return sidebar

    def _build_topbar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("TopBar")
        bar.setFixedHeight(56)
        h = QHBoxLayout(bar)
        h.setContentsMargins(24, 0, 24, 0)
        title = QLabel(__app_name__)
        title.setObjectName("TopBarTitle")
        subtitle = QLabel("Steganography Intelligence Suite")
        subtitle.setObjectName("TopBarSubtitle")
        h.addWidget(title)
        h.addWidget(subtitle)
        h.addStretch(1)

        self.status_pill = QLabel("Ready")
        self.status_pill.setObjectName("StatusPill")
        self.status_pill.setProperty("state", "idle")
        h.addWidget(self.status_pill)

        # ---- Theme toggle button (sun/moon) ----
        # Reads the current mode from the ThemeManager and renders an
        # appropriate icon + label. Clicking flips the mode.
        from .theme_manager import get_theme_manager
        self._theme_mgr = get_theme_manager()
        self.theme_toggle = QPushButton("  Light")
        self.theme_toggle.setObjectName("ThemeToggle")
        self.theme_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.theme_toggle.setToolTip(
            "Switch between Light and Dark theme.\n\n"
            "Light: white content cards on cool-gray backdrop, "
            "classic deep-navy sidebar.\n"
            "Dark: deep-space slate surfaces throughout.")
        self._refresh_theme_toggle()
        self.theme_toggle.clicked.connect(self._on_theme_toggle)
        h.addWidget(self.theme_toggle)
        # Listen for theme changes (so other code can also toggle).
        self._theme_mgr.theme_changed.connect(self._on_theme_changed)

        self.session.status_changed.connect(self._on_status)
        return bar

    def _refresh_theme_toggle(self) -> None:
        """Update the theme-toggle button's icon + label for the current mode."""
        from .theme import Mode
        from .icons import load_nav_icon
        if self._theme_mgr.current_mode() == Mode.LIGHT:
            pix = load_nav_icon("nav_moon", color=APP_COLORS["text_dim"], size=16)
            label = "  Dark"
        else:
            pix = load_nav_icon("nav_sun", color=APP_COLORS["accent2"], size=16)
            label = "  Light"
        if not pix.isNull():
            self.theme_toggle.setIcon(pix)
        self.theme_toggle.setText(label)
        self.theme_toggle.setIconSize(QSize(16, 16))

    def _on_theme_toggle(self) -> None:
        self._theme_mgr.toggle()

    def _on_theme_changed(self, mode: str) -> None:
        """Refresh the whole window after a theme switch."""
        self._refresh_theme_toggle()
        # Force the entire widget tree to recompute styles.
        self.style().unpolish(self)
        self.style().polish(self)
        # Repaint each page so cached colors / pixmaps are rebuilt.
        for btn in self._nav_buttons:
            if btn is not None:
                btn.update()
        # Clear the icon cache so nav icons get re-rendered in the new colors.
        from .icons import clear_icon_cache
        clear_icon_cache()
        self.update()

    def _build_stack(self) -> QStackedWidget:
        self._stack = _FadeStack()
        self._page_factories = [factory for _label, _icon, factory in _NAV]
        self._pages: list[QWidget | None] = [None] * len(_NAV)
        # Wrap each page in a scroll area so tall content stays usable.  Only
        # the dashboard is built during startup; matplotlib-heavy analysis
        # pages are created on first navigation so the window never appears
        # frozen for several seconds on launch.
        # NB: do NOT use a bare ``background: transparent;`` stylesheet on the
        # QScrollArea — without a selector it cascades to all child
        # widgets (including QPushButton) and would wipe their backgrounds.
        # Use a targeted selector on QScrollArea itself only.
        for idx, (_label, _icon, _factory) in enumerate(_NAV):
            page = self._create_page(idx) if idx == 0 else QWidget()
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(page)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setStyleSheet(
                "QScrollArea, QScrollArea > QWidget#qt_scrollarea_viewport "
                "{ background: transparent; border: none; }")
            self._stack.addWidget(scroll)
        return self._stack

    def _create_page(self, idx: int) -> QWidget:
        page = self._page_factories[idx](self.session)
        self._pages[idx] = page
        return page

    def _ensure_page(self, idx: int) -> QWidget:
        """Construct and install a page the first time it is selected."""
        page = self._pages[idx]
        if page is not None:
            return page
        scroll = self._stack.widget(idx)
        if not isinstance(scroll, QScrollArea):
            raise RuntimeError(f"invalid page container at index {idx}")
        placeholder = scroll.takeWidget()
        if placeholder is not None:
            placeholder.deleteLater()
        page = self._create_page(idx)
        scroll.setWidget(page)
        # A report may have been created before this lazy page existed.
        # Replay the current session state so LSB/channel/chart pages never
        # open blank or appear stuck after navigation.
        if self.session.report is not None:
            page._on_report(self.session.report)
        page._on_history(self.session.history)
        page._on_stats()
        return page

    def _go(self, idx: int) -> None:
        self._ensure_page(idx)
        self._stack.setCurrentIndex(idx)

    def _on_status(self, message: str, state: str) -> None:
        self.status_pill.setText(message)
        self.status_pill.setProperty("state", state)
        self.status_pill.style().unpolish(self.status_pill)
        self.status_pill.style().polish(self.status_pill)


def launch_gui(argv: Optional[list[str]] = None) -> int:
    """Create the QApplication, show the boot splash, then run."""

    init_logging()
    app = QApplication.instance() or QApplication(argv or sys.argv)
    app.setApplicationName(__app_name__)
    app.setApplicationVersion(__version__)

    # Bind the theme manager so it owns the application stylesheet and
    # can re-apply it on every mode switch.
    from .theme_manager import get_theme_manager
    tm = get_theme_manager()
    tm.set_app(app)

    # Boot splash for ~3 seconds, then show the main window.
    splash = BootSplash(duration_ms=3000)

    main_window = MainWindow()

    # When the splash finishes, show the main window centered on the
    # same screen and raise it.
    def _show_main():
        try:
            screen = splash.screen() or app.primaryScreen()
            sg = screen.availableGeometry()
            main_window.move(
                sg.center().x() - main_window.width() // 2,
                sg.center().y() - main_window.height() // 2,
            )
        except Exception as _e:
            from ..utils.logger import get_logger
            get_logger("gui").debug("failed to center main window: %s", _e)
        main_window.show()
        main_window.raise_()
        main_window.activateWindow()

    splash.finished.connect(_show_main)
    splash.show()

    return app.exec()


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(launch_gui())
