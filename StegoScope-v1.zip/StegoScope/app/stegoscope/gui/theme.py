"""StegoScope — Classic theme with dark / light mode switching.

Two complete palettes (LIGHT and DARK) live in this file. The
:func:`get_palette` and :func:`get_qss` accessors return the
currently-active palette / stylesheet so widgets can read the live
colors at paint time.

Switching the mode at runtime:

    from .theme import set_mode, Mode
    set_mode(Mode.DARK)        # or Mode.LIGHT
    # all widgets that registered via theme_changed get notified

The :class:`ThemeManager` (in :mod:`theme_manager`) is a Qt-aware
singleton that wraps this module and emits a Qt signal on every
mode switch, so widgets can refresh themselves.

Design language
---------------
* **Classic flat surfaces** — solid color fills, hairline borders,
  no gradients, no glow, no simulated 3-D depth.
* **One primary accent** — indigo ``#4F46E5`` (light) / ``#6366F1``
  (dark). Secondary sky / cyan, tertiary violet.
* **Classic deep-navy sidebar** in light mode (professional
  contrast); sidebar matches the body in dark mode (slate-950).
* **Status palette** — emerald / amber / rose, WCAG-AA on both
  surfaces.
"""

from __future__ import annotations

from enum import Enum


class Mode(str, Enum):
    """Available theme modes."""
    LIGHT = "light"
    DARK = "dark"


# --------------------------------------------------------------------- #
# Light Classic palette
# --------------------------------------------------------------------- #
_LIGHT = {
    # Surfaces -----------------------------------------------------------
    "bg":           "#F4F6FB",   # page backdrop (cool soft gray)
    "bg_alt":       "#FFFFFF",   # top bar / header surface
    "panel":        "#FFFFFF",   # primary card surface
    "panel_alt":    "#F8FAFC",   # zebra rows / alt panel
    "panel_elev":   "#F1F5F9",   # elevated card on hover

    # Sidebar (classic deep navy) --------------------------------------
    "sidebar":      "#1E293B",   # slate-800 sidebar
    "sidebar_fg":   "#F1F5F9",   # primary sidebar text
    "sidebar_dim":  "#94A3B8",   # sidebar secondary text
    "sidebar_hover":"#334155",   # slate-700 hover fill
    "sidebar_active":"#0F172A",  # slate-900 active row
    "sidebar_glow": "#4F46E5",

    # Lines --------------------------------------------------------------
    "border":       "#E2E8F0",   # slate-200 primary hairline
    "border_soft":  "#EDF2F7",   # soft zebra separator
    "border_focus": "#4F46E5",

    # Text ---------------------------------------------------------------
    "text":         "#0F172A",   # slate-900 primary
    "text_dim":     "#475569",   # slate-600 secondary
    "text_muted":   "#94A3B8",   # slate-400 tertiary

    # Accents ------------------------------------------------------------
    "accent":       "#4F46E5",   # indigo-600 primary
    "accent_dim":   "#C7D2FE",   # indigo-200 selection bg
    "accent_hover": "#4338CA",   # indigo-700 hover
    "accent_fg":    "#FFFFFF",   # text on accent fills
    "accent2":      "#0284C7",   # sky-600 secondary
    "accent3":      "#7C3AED",   # violet-600 tertiary

    # Status -------------------------------------------------------------
    "good":         "#059669",   # emerald-600
    "good_bg":      "#D1FAE5",   # emerald-100
    "warn":         "#D97706",   # amber-600
    "warn_bg":      "#FEF3C7",   # amber-100
    "bad":          "#DC2626",   # red-600
    "bad_bg":       "#FEE2E2",   # red-100
    "info":         "#0284C7",

    "hover":        "#F1F5F9",   # slate-100 hover fill
}


# --------------------------------------------------------------------- #
# Dark Classic palette
# --------------------------------------------------------------------- #
_DARK = {
    # Surfaces -----------------------------------------------------------
    "bg":           "#0B1020",   # deep space page backdrop
    "bg_alt":       "#0F172A",   # slate-950 (top bar / sidebar)
    "panel":        "#131A2E",   # primary card surface
    "panel_alt":    "#0F1626",   # alt panel (zebra rows)
    "panel_elev":   "#1A2340",   # elevated card on hover

    # Sidebar (same deep-navy family as body) --------------------------
    "sidebar":      "#0A0F1E",   # deepest sidebar
    "sidebar_fg":   "#E2E8F0",   # primary sidebar text
    "sidebar_dim":  "#64748B",   # sidebar secondary text
    "sidebar_hover":"#141B30",
    "sidebar_active":"#1B2548", # indigo-tinted active row
    "sidebar_glow": "#4F46E5",

    # Lines --------------------------------------------------------------
    "border":       "#1E293B",   # slate-800 primary hairline
    "border_soft":  "#1A2336",
    "border_focus": "#6366F1",

    # Text ---------------------------------------------------------------
    "text":         "#F1F5F9",   # slate-100 primary
    "text_dim":     "#94A3B8",   # slate-400 secondary
    "text_muted":   "#64748B",   # slate-500 tertiary

    # Accents ------------------------------------------------------------
    "accent":       "#6366F1",   # indigo-500 primary
    "accent_dim":   "#312E81",   # indigo-900 selection bg
    "accent_hover": "#818CF8",   # indigo-400 hover
    "accent_fg":    "#FFFFFF",
    "accent2":      "#06B6D4",   # cyan-500 secondary
    "accent3":      "#8B5CF6",   # violet-500 tertiary

    # Status -------------------------------------------------------------
    "good":         "#10B981",   # emerald-500
    "good_bg":      "#064E3B",   # emerald-900
    "warn":         "#F59E0B",   # amber-500
    "warn_bg":      "#78350F",   # amber-900
    "bad":          "#EF4444",   # red-500
    "bad_bg":       "#7F1D1D",   # red-900
    "info":         "#0EA5E9",

    "hover":        "#1E293B",   # slate-800 hover fill
}


# The currently active palette (module-level; toggled by set_mode).
_PALETTE = dict(_LIGHT)
_MODE: Mode = Mode.LIGHT


# Animation timing constants (ms)
ANIM_FAST = 120
ANIM_MED  = 220
ANIM_SLOW = 380


def set_mode(mode: Mode) -> None:
    """Switch the active palette to *mode*."""
    global _PALETTE, _MODE
    if mode == _MODE:
        return
    _MODE = mode
    _PALETTE = dict(_LIGHT if mode == Mode.LIGHT else _DARK)


def get_mode() -> Mode:
    return _MODE


def get_palette() -> dict[str, str]:
    """Return a copy of the currently active palette."""
    return dict(_PALETTE)


# Back-compat: existing widgets import ``APP_COLORS`` and ``APP_QSS``.
# Make APP_COLORS a proxy that always reflects the live palette.
class _PaletteProxy:
    """Mapping proxy that always reflects the live theme palette.

    Allows existing ``APP_COLORS["key"]`` lookups to keep working
    after a runtime mode switch — they read the current palette
    instead of a snapshot taken at import time.
    """
    def __getitem__(self, key):
        return _PALETTE[key]
    def __contains__(self, key):
        return key in _PALETTE
    def get(self, key, default=None):
        return _PALETTE.get(key, default)
    def keys(self):
        return _PALETTE.keys()
    def values(self):
        return _PALETTE.values()
    def items(self):
        return _PALETTE.items()
    def __iter__(self):
        return iter(_PALETTE)
    def __len__(self):
        return len(_PALETTE)
    def __eq__(self, other):
        if isinstance(other, dict):
            return _PALETTE == other
        return NotImplemented


APP_COLORS = _PaletteProxy()


def _build_qss(c: dict[str, str]) -> str:
    """Build the full QSS stylesheet from a palette dict."""

    return f"""
/* ====================================================================
   StegoScope — Classic Theme Stylesheet ({_MODE.value.upper()})
   ==================================================================== */

QWidget {{
    background-color: {c['bg']};
    color: {c['text']};
    font-family: "Segoe UI", "Inter", "DejaVu Sans", "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
}}

QToolTip {{
    background: {c['panel']};
    color: {c['text']};
    border: 1px solid {c['border']};
    padding: 8px 12px;
    border-radius: 0px;
}}

/* ---- Sidebar (classic deep navy in light; deep slate in dark) ---- */
QFrame#Sidebar {{
    background-color: {c['sidebar']};
    border-right: 1px solid {c['border']};
    border-top: none;
    border-bottom: none;
    border-left: none;
}}
QLabel#Brand {{
    color: {c['sidebar_fg']};
    font-size: 19px;
    font-weight: 800;
    letter-spacing: 4px;
    padding: 26px 20px 6px 20px;
    background: transparent;
}}
QLabel#BrandSub {{
    color: {c['sidebar_dim']};
    font-size: 10px;
    padding: 0 20px 18px 20px;
    letter-spacing: 1.5px;
    background: transparent;
}}
QLabel#SidebarTagline {{
    color: {c['accent2']};
    font-size: 9px;
    letter-spacing: 1.5px;
    padding: 0 20px 6px 20px;
    background: transparent;
}}

QPushButton#NavButton {{
    text-align: left;
    padding: 12px 18px 12px 22px;
    border: none;
    border-left: 3px solid transparent;
    color: {c['sidebar_dim']};
    background: transparent;
    font-size: 13px;
    font-weight: 500;
}}
QPushButton#NavButton:hover {{
    color: {c['sidebar_fg']};
    background: {c['sidebar_hover']};
    border-left: 3px solid {c['accent']};
}}
QPushButton#NavButton:checked {{
    color: {c['sidebar_fg']};
    background: {c['sidebar_active']};
    border-left: 3px solid {c['accent2']};
    font-weight: 600;
}}

QLabel#NavSeparator {{
    background: transparent;
    color: {c['sidebar_dim']};
    font-size: 9px;
    letter-spacing: 2px;
    padding: 14px 22px 4px 22px;
    font-weight: 700;
}}

/* ---- Top bar ---- */
QFrame#TopBar {{
    background-color: {c['bg_alt']};
    border-bottom: 1px solid {c['border']};
}}
QLabel#TopBarTitle {{
    color: {c['text']};
    font-size: 14px;
    font-weight: 600;
    padding: 0 8px;
    background: transparent;
}}
QLabel#TopBarSubtitle {{
    color: {c['text_dim']};
    font-size: 11px;
    padding: 0 8px;
    background: transparent;
}}
QLabel#StatusPill {{
    color: {c['accent_fg']};
    background: {c['text_muted']};
    padding: 5px 14px;
    border-radius: 0px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.5px;
}}
QLabel#StatusPill[idle] {{
    background: {c['text_muted']};
    color: {c['accent_fg']};
}}
QLabel#StatusPill[busy] {{
    background: {c['warn']};
    color: {c['accent_fg']};
}}
QLabel#StatusPill[ok] {{
    background: {c['good']};
    color: {c['accent_fg']};
}}

/* ---- Theme toggle button (top-right of top bar) ---- */
QPushButton#ThemeToggle {{
    background: transparent;
    border: 1px solid {c['border']};
    border-radius: 0px;
    padding: 6px 12px 6px 8px;
    color: {c['text_dim']};
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.5px;
}}
QPushButton#ThemeToggle:hover {{
    border-color: {c['accent']};
    color: {c['accent']};
    background: {c['hover']};
}}
QPushButton#ThemeToggle:pressed {{
    background: {c['accent_dim']};
}}

/* ---- Pages ---- */
QLabel#PageTitle {{
    color: {c['text']};
    font-size: 22px;
    font-weight: 700;
    padding: 4px 0 2px 0;
    background: transparent;
}}
QLabel#PageSubtitle {{
    color: {c['text_dim']};
    font-size: 12px;
    padding-bottom: 14px;
    background: transparent;
}}
QFrame#Card {{
    background-color: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
}}
QFrame#Card:hover {{
    border-color: {c['accent_dim']};
}}
QLabel#CardTitle {{
    color: {c['accent2']};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 2px;
    padding: 16px 18px 4px 18px;
    text-transform: uppercase;
    background: transparent;
}}
QLabel#StatValue {{
    color: {c['text']};
    font-size: 32px;
    font-weight: 800;
    background: transparent;
}}
QLabel#StatLabel {{
    color: {c['text_muted']};
    font-size: 10px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    background: transparent;
}}

/* ---- Verdict badges ---- */
QLabel#VerdictClean   {{ color: {c['good']}; font-size: 16px; font-weight: 700; }}
QLabel#VerdictSusp    {{ color: {c['warn']}; font-size: 16px; font-weight: 700; }}
QLabel#VerdictLikely  {{ color: {c['bad']};  font-size: 16px; font-weight: 700; }}

/* ---- Inputs & buttons ---- */
QPushButton {{
    background-color: {c['panel']};
    color: {c['text']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    padding: 9px 18px;
    font-weight: 500;
}}
QPushButton:hover {{
    border-color: {c['accent']};
    background: {c['panel_elev']};
    color: {c['accent']};
}}
QPushButton:pressed {{
    background: {c['accent_dim']};
    color: {c['text']};
}}
QPushButton:disabled {{
    color: {c['text_muted']};
    border-color: {c['border_soft']};
    background: {c['panel_alt']};
}}
QPushButton#Primary {{
    background-color: {c['accent']};
    color: {c['accent_fg']};
    border: none;
    font-weight: 600;
    padding: 10px 22px;
}}
QPushButton#Primary:hover {{
    background-color: {c['accent_hover']};
    color: {c['accent_fg']};
}}
QPushButton#Primary:pressed {{
    background: {c['accent_hover']};
}}
QPushButton#Primary:disabled {{
    background: {c['accent_dim']};
    color: {c['text_muted']};
}}

QPushButton#Ghost {{
    background: transparent;
    color: {c['text_dim']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    padding: 9px 18px;
}}
QPushButton#Ghost:hover {{
    color: {c['accent2']};
    border-color: {c['accent2']};
    background: {c['hover']};
}}

QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
    background-color: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    padding: 8px 12px;
    color: {c['text']};
    selection-background-color: {c['accent_dim']};
    selection-color: {c['text']};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border: 1px solid {c['accent']};
    background-color: {c['panel']};
}}
QLineEdit:disabled {{
    color: {c['text_muted']};
    background: {c['panel_alt']};
}}
QComboBox::drop-down {{
    border: none;
    width: 26px;
    background: transparent;
}}
QComboBox::down-arrow {{
    image: none;
    width: 0;
    height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {c['text_dim']};
    margin-right: 10px;
}}
QComboBox QAbstractItemView {{
    background: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    selection-background-color: {c['accent_dim']};
    selection-color: {c['text']};
    color: {c['text']};
    outline: none;
    padding: 4px;
}}
QComboBox QAbstractItemView::item {{
    padding: 8px 14px;
    border-radius: 0px;
}}
QComboBox QAbstractItemView::item:selected {{
    background: {c['accent_dim']};
    color: {c['text']};
}}

/* ---- Tables ---- */
QTableWidget {{
    background-color: {c['panel']};
    alternate-background-color: {c['panel_alt']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    gridline-color: {c['border_soft']};
    selection-background-color: {c['accent_dim']};
    selection-color: {c['text']};
    outline: none;
}}
QHeaderView::section {{
    background-color: {c['panel_alt']};
    color: {c['text_dim']};
    padding: 11px 14px;
    border: none;
    border-right: 1px solid {c['border']};
    border-bottom: 1px solid {c['border']};
    font-weight: 700;
    font-size: 10px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}}
QTableWidget::item {{
    padding: 8px 12px;
    border-bottom: 1px solid {c['border_soft']};
    background: transparent;
}}
QTableWidget::item:hover {{
    background: {c['hover']};
}}
QTableWidget::item:selected {{
    background: {c['accent_dim']};
}}
QTableCornerButton::section {{
    background-color: {c['panel_alt']};
    border: none;
    border-bottom: 1px solid {c['border']};
}}

/* ---- Scroll bars (thin, classic flat) ---- */
QScrollBar:vertical {{
    background: transparent;
    width: 12px;
    margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {c['border']};
    border-radius: 0px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {c['text_muted']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: transparent;
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 12px;
    margin: 2px;
}}
QScrollBar::handle:horizontal {{
    background: {c['border']};
    border-radius: 0px;
    min-width: 30px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {c['text_muted']};
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
    background: transparent;
}}

/* ---- Progress bar ---- */
QProgressBar {{
    background-color: {c['panel_alt']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    text-align: center;
    color: {c['text']};
    height: 18px;
    font-size: 11px;
    font-weight: 600;
}}
QProgressBar::chunk {{
    background-color: {c['accent']};
    border-radius: 0px;
}}

/* ---- Text browser / log ---- */
QTextEdit, QPlainTextEdit, QTextBrowser {{
    background-color: {c['panel_alt']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    color: {c['text']};
    font-family: "JetBrains Mono", "Cascadia Code", "DejaVu Sans Mono", "Consolas", monospace;
    font-size: 12px;
    padding: 10px;
    selection-background-color: {c['accent_dim']};
    selection-color: {c['text']};
}}

QSlider::groove:horizontal {{
    height: 6px;
    background: {c['border']};
    border-radius: 0px;
}}
QSlider::handle:horizontal {{
    background: {c['accent']};
    width: 18px;
    height: 18px;
    margin: -6px 0;
    border-radius: 0px;
    border: 2px solid {c['panel']};
}}
QSlider::handle:horizontal:hover {{
    background: {c['accent_hover']};
}}
QSlider::sub-page:horizontal {{
    background: {c['accent']};
    border-radius: 0px;
}}

/* ---- Group boxes (used on Settings / About) ---- */
QGroupBox {{
    background-color: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    margin-top: 16px;
    padding: 16px 14px 14px 14px;
    font-weight: 600;
    color: {c['text']};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 12px;
    background: {c['bg']};
    color: {c['accent2']};
    font-size: 10px;
    letter-spacing: 2px;
    border-radius: 0px;
}}

QCheckBox, QRadioButton {{
    color: {c['text']};
    spacing: 8px;
    background: transparent;
}}
QCheckBox::indicator, QRadioButton::indicator {{
    width: 18px;
    height: 18px;
    border: 1px solid {c['border']};
    background: {c['panel']};
    border-radius: 0px;
}}
QCheckBox::indicator:hover {{
    border-color: {c['accent']};
}}
QCheckBox::indicator:checked {{
    background: {c['accent']};
    border-color: {c['accent']};
}}
QRadioButton::indicator {{
    border-radius: 0px;
}}
QRadioButton::indicator:checked {{
    background: {c['accent']};
    border-color: {c['accent']};
}}

QMenu {{
    background-color: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    color: {c['text']};
    padding: 6px;
}}
QMenu::item {{
    padding: 8px 22px 8px 14px;
    border-radius: 0px;
}}
QMenu::item:selected {{
    background: {c['accent_dim']};
    color: {c['text']};
}}

QTabWidget::pane {{
    background: {c['panel']};
    border: 1px solid {c['border']};
    border-radius: 0px;
    padding: 6px;
}}
QTabBar::tab {{
    background: {c['panel_alt']};
    color: {c['text_dim']};
    padding: 9px 16px;
    margin-right: 3px;
    border: 1px solid {c['border']};
    border-radius: 0px;
    font-weight: 500;
}}
QTabBar::tab:hover {{
    color: {c['text']};
    border-color: {c['accent_dim']};
}}
QTabBar::tab:selected {{
    background: {c['accent']};
    color: {c['accent_fg']};
    border-color: {c['accent']};
    font-weight: 600;
}}
"""


# Back-compat: APP_QSS is a string used at module-import time. It
# captures the *initial* palette; for runtime switching the caller
# should use get_qss() instead.
APP_QSS = _build_qss(_PALETTE)


def get_qss() -> str:
    """Return the QSS for the currently active palette."""
    return _build_qss(_PALETTE)


__all__ = [
    "Mode", "APP_COLORS", "APP_QSS",
    "set_mode", "get_mode", "get_palette", "get_qss",
    "ANIM_FAST", "ANIM_MED", "ANIM_SLOW",
]
