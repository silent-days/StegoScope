"""Custom navigation button with SVG icon + label + animated indicator.

The standard ``QPushButton`` mixes icon + text via the layout, but
positioning is crude and the active-state indicator strip needs an
animated glow. ``NavButton`` is a fully custom-painted widget that:

* Renders the SVG icon recoloured for the current state.
* Renders the label left-aligned next to the icon.
* Shows a vertical accent bar on the left when active.
* Animates the indicator fade / slide on state changes.
* Honours the theme palette via :data:`APP_COLORS`.
"""

from __future__ import annotations

from PySide6.QtCore import Property, QRectF, QSize, Qt, Signal
from PySide6.QtGui import (QColor, QFont, QPainter)
from PySide6.QtWidgets import QPushButton

from .theme import APP_COLORS
from .icons import load_nav_icon


class NavButton(QPushButton):
    """Sidebar navigation button with icon, label and animated indicator."""

    hovered = Signal()

    # Qt property names: "glow" and "hoverProgress" — exposed via the
    # Property descriptors below so QPropertyAnimation can animate them.

    def __init__(self, icon_name: str, label: str,
                 parent=None) -> None:
        super().__init__(parent)
        self._icon_name = icon_name
        self._label = label
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setObjectName("NavButton")
        self.setMinimumHeight(46)
        self.setMouseTracking(True)

        # Classic UI state: no glow, slide, or dimensional hover animation.
        self._glow = 0.0
        self._hover_t = 0.0
        self._is_hovered = False

    # ---- Qt properties (registered so QPropertyAnimation can find them) -
    # Use the @Property decorator form for cleaner PySide6 binding.
    @Property(float)
    def glow(self) -> float:
        return self._glow

    @glow.setter  # type: ignore[no-redef]
    def glow(self, v: float) -> None:
        self._glow = v
        self.update()

    @Property(float)
    def hoverProgress(self) -> float:
        return self._hover_t

    @hoverProgress.setter  # type: ignore[no-redef]
    def hoverProgress(self, v: float) -> None:
        self._hover_t = v
        self.update()

    # ---- state ---------------------------------------------------------
    def setChecked(self, checked: bool) -> None:  # noqa: D401
        super().setChecked(checked)
        self._glow = 1.0 if checked else 0.0
        self._hover_t = 1.0 if self._is_hovered else 0.0
        self.update()

    # ---- events --------------------------------------------------------
    def enterEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = True
        self._hover_t = 1.0
        self.update()
        self.hovered.emit()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._is_hovered = False
        self._hover_t = 0.0
        self.update()
        super().leaveEvent(event)

    # ---- painting ------------------------------------------------------
    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(240, 46)

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return QSize(220, 42)

    def paintEvent(self, event) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

        rect = QRectF(self.rect())

        # Background
        if self.isChecked():
            bg_color = QColor(APP_COLORS["sidebar_active"])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(bg_color)
            p.drawRect(rect)
        elif self._hover_t > 0:
            base = QColor(APP_COLORS["sidebar_hover"])
            base.setAlpha(int(255 * self._hover_t))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(base)
            p.drawRect(rect)

        # Left accent strip — flat solid colour
        if self.isChecked() or self._glow > 0:
            h = rect.height()
            strip_w = 3 + 1.5 * self._glow
            strip_rect = QRectF(0, h * 0.2, strip_w, h * 0.6)
            # Flat single colour (no gradient): cyan when checked,
            # indigo when animating.
            strip_color = QColor(APP_COLORS["accent2"]) if self.isChecked() \
                else QColor(APP_COLORS["accent"])
            p.setBrush(strip_color)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRect(strip_rect)

        # Icon — uses sidebar_fg (bright) for active, sidebar_dim for idle.
        # The sidebar is always dark, so the icon must be light regardless of
        # whether the body is light or dark.
        if self.isChecked():
            icon_color = APP_COLORS["sidebar_fg"]
        elif self._hover_t > 0.3:
            # Blend from sidebar_dim to sidebar_fg
            base = QColor(APP_COLORS["sidebar_dim"])
            target = QColor(APP_COLORS["sidebar_fg"])
            r = min(1.0, (self._hover_t - 0.3) / 0.7)
            icon_color = QColor(
                int(base.red() + (target.red() - base.red()) * r),
                int(base.green() + (target.green() - base.green()) * r),
                int(base.blue() + (target.blue() - base.blue()) * r),
                255,
            ).name()
        else:
            icon_color = APP_COLORS["sidebar_dim"]
        pix = load_nav_icon(self._icon_name, color=icon_color, size=22)
        if not pix.isNull():
            ix = 22
            iy = int((rect.height() - pix.height()) / 2)
            p.drawPixmap(ix, iy, pix)

        # Label — sidebar_fg (bright) for active, sidebar_dim for idle.
        # The sidebar is always dark.
        if self.isChecked():
            label_color = QColor(APP_COLORS["sidebar_fg"])
        elif self._hover_t > 0:
            base = QColor(APP_COLORS["sidebar_dim"])
            target = QColor(APP_COLORS["sidebar_fg"])
            r = self._hover_t
            label_color = QColor(
                int(base.red() + (target.red() - base.red()) * r),
                int(base.green() + (target.green() - base.green()) * r),
                int(base.blue() + (target.blue() - base.blue()) * r),
                255,
            )
        else:
            label_color = QColor(APP_COLORS["sidebar_dim"])
        p.setPen(label_color)
        font = QFont("Segoe UI", 10, QFont.Weight.DemiBold if self.isChecked()
                     else QFont.Weight.Medium)
        p.setFont(font)
        text_rect = QRectF(54, 0, rect.width() - 64, rect.height())
        p.drawText(text_rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                   self._label)
