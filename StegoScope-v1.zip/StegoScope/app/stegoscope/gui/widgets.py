"""Reusable StegoScope GUI widgets.

Premium dark-theme aware widgets used across all pages:
* :class:`MatplotlibCanvas` — embeds a matplotlib Figure in Qt.
* :class:`Card` — elevated dark card with subtle border and optional title.
* :class:`StatCard` — KPI tile with icon, value and label.
* :class:`VerdictBadge` — animated verdict label that recolours itself.
* :class:`InfoCard` — key/value pair display.
* :class:`HLine` — themed horizontal divider.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel,
                                QSizePolicy, QVBoxLayout, QWidget)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from .theme import APP_COLORS
from .icons import load_nav_icon


def _make_transparent(widget: QWidget) -> None:
    """Set the widget's background to transparent WITHOUT cascading to children.

    The naive ``widget.setStyleSheet("background: transparent;")`` applies the
    rule to the widget AND every descendant (because no selector is given),
    which silently strips backgrounds off descendant buttons and inputs.
    We instead assign a unique objectName and use a targeted selector.
    """
    name = widget.objectName() or f"_t{id(widget)}"
    widget.setObjectName(name)
    widget.setStyleSheet(f"QWidget#{name} {{ background: transparent; }}")



class MatplotlibCanvas(FigureCanvasQTAgg):
    """A QWidget wrapping a matplotlib Figure for embedding in Qt layouts."""

    def __init__(self, figure: Figure | None = None,
                 parent: QWidget | None = None) -> None:
        self.figure = figure or Figure()
        super().__init__(self.figure)
        self.setParent(parent)
        # Transparent Qt widget background so the figure facecolor shows.
        self.setStyleSheet("background: transparent;")
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(220)
        self.setMaximumHeight(360)

    def set_figure(self, figure: Figure) -> None:
        """Replace the figure shown by this canvas in-place."""

        import matplotlib.pyplot as plt
        old = getattr(self, "figure", None)
        self.figure = figure
        figure.set_canvas(self)
        # Schedule the repaint instead of drawing synchronously inside a
        # session signal.  Large channel-plane figures must never block the
        # GUI thread and make the dashboard appear frozen.
        self.draw_idle()
        self.update()
        self.updateGeometry()
        if old is not None and old is not figure:
            try:
                plt.close(old)
            except Exception as _e:
                from ..utils.logger import get_logger
                get_logger("widgets").debug("matplotlib close failed: %s", _e)


class Card(QFrame):
    """An elevated dark card with an optional title and a content slot.

    The card has a soft inner padding, a hairline border, and a subtle
    hover effect (animated border brighten).
    """

    def __init__(self, title: str | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 14)
        self._layout.setSpacing(6)
        if title:
            lbl = QLabel(title.upper())
            lbl.setObjectName("CardTitle")
            self._layout.addWidget(lbl)
            self._layout.addSpacing(2)

    def addWidget(self, widget: QWidget) -> None:
        widget.setObjectName(widget.objectName() or "CardContent")
        wrap = QWidget()
        _make_transparent(wrap)
        h = QHBoxLayout(wrap)
        h.setContentsMargins(18, 4, 18, 8)
        h.addWidget(widget)
        self._layout.addWidget(wrap)

    def addLayout(self, layout) -> None:
        wrap = QWidget()
        _make_transparent(wrap)
        h = QHBoxLayout(wrap)
        h.setContentsMargins(18, 4, 18, 8)
        h.addLayout(layout)
        self._layout.addWidget(wrap)

    def layout(self) -> QVBoxLayout:  # type: ignore[override]
        return self._layout


class StatCard(QFrame):
    """A premium KPI tile with optional icon, large value and small label.

    Visual: rounded dark card, accent left bar, big bold value on top,
    uppercase label below.
    """

    def __init__(self, label: str, value: str = "—",
                 color: str = APP_COLORS["text"],
                 icon: str | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._color = color
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Left accent bar
        accent = QFrame()
        accent.setFixedWidth(4)
        accent.setStyleSheet(
            f"background: {color}; border-top-left-radius: 12px;"
            f"border-bottom-left-radius: 12px;")
        outer.addWidget(accent)

        # Right content
        body = QWidget()
        _make_transparent(body)
        v = QVBoxLayout(body)
        v.setContentsMargins(16, 16, 16, 16)
        v.setSpacing(4)

        # Optional icon
        if icon:
            icon_lbl = QLabel()
            pix = load_nav_icon(icon, color=color, size=22)
            if not pix.isNull():
                icon_lbl.setPixmap(pix)
            _make_transparent(icon_lbl)
            v.addWidget(icon_lbl)

        self._value = QLabel(value)
        self._value.setObjectName("StatValue")
        self._value.setStyleSheet(f"color: {color}; background: transparent;")
        v.addWidget(self._value)

        self._label = QLabel(label.upper())
        self._label.setObjectName("StatLabel")
        self._label.setStyleSheet("background: transparent;")
        v.addWidget(self._label)

        v.addStretch(1)
        outer.addWidget(body, 1)

        self.setMinimumHeight(110)

    def setValue(self, value: str) -> None:
        self._value.setText(value)


class VerdictBadge(QLabel):
    """A coloured verdict label that switches style with the verdict."""

    _STYLE_MAP = {
        "CLEAN": ("VerdictClean", APP_COLORS["good"]),
        "SUSPICIOUS": ("VerdictSusp", APP_COLORS["warn"]),
        "LIKELY HIDDEN DATA": ("VerdictLikely", APP_COLORS["bad"]),
        "ERROR": ("VerdictLikely", APP_COLORS["bad"]),
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__("—", parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumHeight(46)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    def setVerdict(self, verdict: str) -> None:
        obj, color = self._STYLE_MAP.get(verdict,
                                         ("VerdictLikely", APP_COLORS["text"]))
        self.setObjectName(obj)
        self.setText(verdict)
        self.setStyleSheet(
            f"color: {APP_COLORS['accent_fg']}; background: {color}; "
            f"font-size: 15px; font-weight: 700; padding: 10px 16px; "
            f"border-radius: 10px; letter-spacing: 1px;")
        self.style().unpolish(self)
        self.style().polish(self)


class HLine(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.HLine)
        self.setFixedHeight(1)
        self.setStyleSheet(f"background: {APP_COLORS['border']}; border: none;")


class InfoCard(QFrame):
    """An info card with a small icon, a title, and body text."""

    def __init__(self, title: str, body: str, *,
                 icon: str | None = None,
                 accent: str = APP_COLORS["accent2"],
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        h = QHBoxLayout(self)
        h.setContentsMargins(18, 16, 18, 16)
        h.setSpacing(14)

        if icon:
            icon_lbl = QLabel()
            pix = load_nav_icon(icon, color=accent, size=28)
            if not pix.isNull():
                icon_lbl.setPixmap(pix)
            _make_transparent(icon_lbl)
            icon_lbl.setAlignment(Qt.AlignmentFlag.AlignTop)
            h.addWidget(icon_lbl)

        v = QVBoxLayout()
        v.setSpacing(4)
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet(
            f"color: {APP_COLORS['text']}; font-size: 13px; "
            f"font-weight: 700; background: transparent;")
        title_lbl.setWordWrap(True)
        body_lbl = QLabel(body)
        body_lbl.setStyleSheet(
            f"color: {APP_COLORS['text_dim']}; font-size: 11px;"
            f" background: transparent;")
        body_lbl.setWordWrap(True)
        v.addWidget(title_lbl)
        v.addWidget(body_lbl)
        v.addStretch(1)
        h.addLayout(v, 1)


def kv_row(key: str, value: str) -> tuple[QLabel, QLabel]:
    """Return a (key, value) pair of labels for a metadata row."""
    k = QLabel(key)
    k.setStyleSheet(f"color: {APP_COLORS['text_dim']}; background: transparent;"
                   f"font-size: 12px;")
    k.setMinimumWidth(140)
    v = QLabel(value)
    v.setStyleSheet(f"color: {APP_COLORS['text']}; background: transparent;"
                    f"font-size: 12px;")
    v.setWordWrap(True)
    return k, v


def verdict_color(verdict: str) -> str:
    if verdict == "CLEAN":
        return APP_COLORS["good"]
    if verdict == "SUSPICIOUS":
        return APP_COLORS["warn"]
    return APP_COLORS["bad"]
