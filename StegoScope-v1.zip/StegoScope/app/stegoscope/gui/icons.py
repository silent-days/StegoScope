"""SVG-aware icon loader for StegoScope navigation.

QtSvg's QSvgRenderer is used to load the small monochrome SVG icons
shipped under ``assets/icons/`` and recolour them per state (default,
hover, active). The cached pixmaps are stored against a key composed
from the icon name + colour so the same icon requested twice in the
same colour is served from the cache.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

_ASSET_DIR = Path(__file__).resolve().parents[1] / "assets" / "icons"

_CACHE: dict[tuple[str, str, int], QPixmap] = {}


def _recolor_svg(svg_bytes: bytes, color: str) -> QByteArray:
    """Replace ``currentColor`` in the SVG with the given hex color."""
    text = svg_bytes.decode("utf-8", errors="replace")
    # We authored the icons to use stroke="currentColor". Replace the
    # literal token with the desired colour. Two occurrences: stroke
    # (lines) and any fill="currentColor".
    text = text.replace('stroke="currentColor"', f'stroke="{color}"')
    text = text.replace('fill="currentColor"', f'fill="{color}"')
    return QByteArray(text.encode("utf-8"))


def load_nav_icon(name: str, *, color: str = "#FFFFFF",
                  size: int = 22) -> QPixmap:
    """Return a coloured nav-icon pixmap.

    Parameters
    ----------
    name
        The icon's filename stem (e.g. ``"nav_dashboard"``).
    color
        Hex colour for stroke / fill. Defaults to bright slate-100.
    size
        Edge length in pixels. Defaults to 22.
    """
    key = (name, color.lower(), size)
    if key in _CACHE:
        return _CACHE[key]

    path = _ASSET_DIR / f"{name}.svg"
    if not path.exists():
        # Fallback: empty pixmap (still valid for Qt consumption).
        pix = QPixmap(size, size)
        pix.fill(Qt.GlobalColor.transparent)
        _CACHE[key] = pix
        return pix

    svg_bytes = path.read_bytes()
    data = _recolor_svg(svg_bytes, color)
    renderer = QSvgRenderer(data)
    if not renderer.isValid():
        # Original SVG might not use currentColor. Try unmodified.
        renderer = QSvgRenderer(QByteArray(svg_bytes))
        if not renderer.isValid():
            pix = QPixmap(size, size)
            pix.fill(Qt.GlobalColor.transparent)
            _CACHE[key] = pix
            return pix

    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    renderer.render(p)
    p.end()
    pix = QPixmap.fromImage(img)
    _CACHE[key] = pix
    return pix


def clear_icon_cache() -> None:
    _CACHE.clear()


__all__ = ["load_nav_icon", "clear_icon_cache"]
