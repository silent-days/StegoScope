"""Shared GUI session state.

A single :class:`SessionManager` (owned by the :class:`MainWindow`) holds
the current :class:`~stegoscope.core.verdict.AnalysisReport`, the
rolling history of recent investigations, and the live batch results.

Pages connect to the Qt signals it emits and refresh themselves
whenever the session changes, so no page knows about any other page —
they all observe the session.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from PySide6.QtCore import QObject, Signal

from ..core.batch import BatchResult
from ..core.verdict import AnalysisReport


@dataclass
class HistoryEntry:
    filename: str
    verdict: str
    score: int
    timestamp: str
    path: str = ""


class SessionManager(QObject):
    """Holds and broadcasts the current analysis state."""

    report_changed = Signal(object)        # AnalysisReport | None
    batch_changed = Signal(object)         # list[BatchResult]
    history_changed = Signal(object)       # list[HistoryEntry]
    status_changed = Signal(str, str)      # (message, state)  state in idle/busy/ok
    stats_changed = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._report: AnalysisReport | None = None
        self._batch: list[BatchResult] = []
        self._history: list[HistoryEntry] = []
        self._stats = {"total": 0, "clean": 0, "suspicious": 0, "likely": 0}

    # ---- report ----
    @property
    def report(self) -> AnalysisReport | None:
        return self._report

    def set_report(self, report: AnalysisReport | None) -> None:
        self._report = report
        if report is not None:
            self._push_history(report, emit=False)
            self._update_stats(report.verdict.verdict)
            self.history_changed.emit(list(self._history))
        self.report_changed.emit(report)
        self.stats_changed.emit()

    # ---- batch ----
    @property
    def batch(self) -> list[BatchResult]:
        return self._batch

    def set_batch(self, results: list[BatchResult]) -> None:
        self._batch = results
        # Roll batch results into history + stats too, but emit
        # history_changed ONCE at the end (A3 fix — previously each
        # batch result triggered a separate broadcast and a separate
        # slice operation, so a 1000-image batch rebuilt the dashboard
        # table 1000 times).
        for r in results:
            if r.report is None:
                continue
            self._push_history(r.report, emit=False)
            self._update_stats(r.verdict)
        self.batch_changed.emit(results)
        self.history_changed.emit(list(self._history))
        self.stats_changed.emit()

    # ---- history ----
    @property
    def history(self) -> list[HistoryEntry]:
        return list(self._history)

    @property
    def stats(self) -> dict[str, int]:
        return dict(self._stats)

    def _push_history(self, report: AnalysisReport, *, emit: bool = True) -> None:
        entry = HistoryEntry(
            filename=report.info.filename,
            verdict=report.verdict.verdict,
            score=report.verdict.score,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M"),
            path=report.info.path,
        )
        self._history.insert(0, entry)
        del self._history[20:]   # keep the most recent 20
        if emit:
            self.history_changed.emit(list(self._history))

    def _update_stats(self, verdict: str) -> None:
        self._stats["total"] += 1
        if verdict == "CLEAN":
            self._stats["clean"] += 1
        elif verdict == "SUSPICIOUS":
            self._stats["suspicious"] += 1
        elif verdict == "LIKELY HIDDEN DATA":
            self._stats["likely"] += 1

    # ---- status ----
    def set_status(self, message: str, state: str = "idle") -> None:
        self.status_changed.emit(message, state)
