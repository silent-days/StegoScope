"""Command-line interface sub-package."""

from .cli import main

__all__ = ["main"]
