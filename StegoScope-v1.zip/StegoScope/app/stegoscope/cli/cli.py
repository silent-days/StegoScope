"""StegoScope command-line interface.

Usage
-----
Linux / macOS::

    stegoscope version
    stegoscope scan image.png
    stegoscope scan image.png --extract
    stegoscope scan image.png --report report.json
    stegoscope scan image.png --report report.pdf --extract
    stegoscope batch ./images/ --recursive --output batch_results

Windows (cmd / PowerShell)::

    stegoscope.exe version
    stegoscope.exe scan image.png --extract
    stegoscope.exe scan image.png --report report.pdf
    stegoscope.exe batch .\\images\\ --recursive --output batch_results

The CLI is a thin wrapper over :func:`stegoscope.analyze_image` and
:func:`stegoscope.core.scan_directory`; every advertised command runs
the real detection engine locally.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .. import __app_name__, __developer__, __full_name__, __tagline__, __version__
from ..core.batch import scan_directory
from ..core.image_loader import UnsupportedFormatError
from ..core.verdict import analyze_image
from ..reporting import REPORT_FORMATS, ReportFormatError, save_report
from ..utils.limits import ImageTooLargeError
from ..utils.logger import init_logging, get_logger

_log = get_logger("cli")


# --------------------------------------------------------------------- #
# Argument parsing
# --------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="stegoscope",
        description=f"{__full_name__} — {__tagline__}",
    )
    p.add_argument("-v", "--verbose", action="store_true",
                   help="enable debug logging to stderr")
    sub = p.add_subparsers(dest="command", required=True,
                           metavar="{scan,batch,version}")

    # version
    sub.add_parser("version", help="print application and version info")

    # scan
    scan = sub.add_parser("scan", help="analyse a single image")
    scan.add_argument("image", help="path to a PNG or BMP image")
    scan.add_argument("--extract", action="store_true",
                      help="also extract a candidate LSB payload")
    scan.add_argument("--report", metavar="PATH",
                      help="write a report to PATH; format inferred from "
                           "the suffix (txt/json/csv/pdf)")
    scan.add_argument("--payload-out", metavar="PATH",
                      help="write the extracted candidate payload to this "
                           "file (implies --extract); always saved as .bin")
    scan.add_argument("--max-payload", type=int, default=None,
                      metavar="BYTES",
                      help="cap extracted payload to BYTES (default 8 MiB)")
    scan.add_argument("--channels", default=None,
                      metavar="LIST",
                      help="comma-separated channel names to extract "
                           "(e.g. R,G,B); default: all channels in order")
    scan.add_argument("--bit-order", choices=("msb", "lsb"),
                      default="msb",
                      help="bit significance within each extracted byte "
                           "(default: msb, the assignment-required order)")
    scan.add_argument("--interleave", action="store_true",
                      help="extract bit-round-robin across channels "
                           "(true RGB-interleaved) instead of the default "
                           "channel-sequential order")
    scan.add_argument("--lsb-planes", metavar="DIR",
                      help="save each channel's LSB plane as a "
                           "black-and-white PNG into DIR (a visual "
                           "steganalysis aid)")
    scan.add_argument("--force", action="store_true",
                      help="allow --payload-out / --report / --lsb-planes "
                           "to overwrite existing files")
    scan.add_argument("--quiet", action="store_true",
                      help="suppress the textual report on stdout")

    # batch
    batch = sub.add_parser("batch", help="scan every PNG/BMP in a directory")
    batch.add_argument("directory", help="folder to scan")
    batch.add_argument("--recursive", "-r", action="store_true",
                       help="recurse into subdirectories")
    batch.add_argument("--extract", action="store_true",
                       help="extract candidate payloads (slower)")
    batch.add_argument("--max-files", type=int, default=None,
                       metavar="N",
                       help="cap the number of files processed (after "
                            "filtering to PNG/BMP)")
    batch.add_argument("--output", metavar="STEM",
                       help="write <STEM>.csv and <STEM>.json batch results")
    batch.add_argument("--report-dir", metavar="DIR",
                       help="also write a per-image report into this directory")
    batch.add_argument("--report-fmt", metavar="FMT",
                       choices=REPORT_FORMATS, default="json",
                       help="format for per-image reports (default: json)")
    batch.add_argument("--force", action="store_true",
                       help="allow --output / --report-dir to overwrite "
                            "existing files; duplicate basenames always get "
                            "a unique suffix")

    return p


# --------------------------------------------------------------------- #
# Command handlers
# --------------------------------------------------------------------- #
def _cmd_version() -> int:
    print(f"{__app_name__} {__version__}")
    print(f"{__full_name__}")
    print(f"Developer : {__developer__}")
    print(f"Tagline   : {__tagline__}")
    print(f"Python    : {sys.version.split()[0]}")
    print(f"Platform  : {sys.platform}")
    return 0


def _cmd_scan(args: argparse.Namespace) -> int:
    path = Path(args.image)
    do_extract = args.extract or bool(args.payload_out)
    channels = None
    if args.channels:
        channels = [c.strip() for c in args.channels.split(",") if c.strip()]
    try:
        report = analyze_image(
            path, extract=do_extract,
            max_payload_bytes=args.max_payload,
            extract_channels=channels,
            extract_bit_order=args.bit_order,
            extract_interleave=args.interleave,
        )
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except UnsupportedFormatError as exc:
        print(f"error: unsupported image: {exc}", file=sys.stderr)
        return 3
    except ImageTooLargeError as exc:
        print(f"error: image exceeds safety limits: {exc}", file=sys.stderr)
        return 4

    if args.payload_out:
        from ..extraction.payload import save_payload
        if report.payload is None:
            print("error: no payload was extracted", file=sys.stderr)
            return 4
        try:
            written = save_payload(report.payload, args.payload_out,
                                   overwrite=args.force)
        except FileExistsError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 7
        print(f"candidate payload written: {written}", file=sys.stderr)

    if args.report:
        try:
            out = save_report(report, args.report, overwrite=args.force)
        except ReportFormatError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 5
        except FileExistsError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 7
        print(f"report written: {out}", file=sys.stderr)

    if args.lsb_planes:
        from ..core.image_loader import ImageLoader
        from ..visualization.plots import save_lsb_planes
        try:
            img = ImageLoader().load(path)
            written = save_lsb_planes(img, args.lsb_planes,
                                      overwrite=args.force)
        except Exception as exc:
            print(f"error saving LSB planes: "
                  f"{exc.__class__.__name__}: {exc}", file=sys.stderr)
            return 6
        for w in written:
            print(f"LSB plane written: {w}", file=sys.stderr)

    if not args.quiet:
        from ..reporting import to_txt
        sys.stdout.write(to_txt(report))

    print(f"\n>>> {report.info.filename}: score={report.verdict.score} "
          f"verdict={report.verdict.verdict}", file=sys.stderr)
    return 0


def _cmd_batch(args: argparse.Namespace) -> int:
    directory = Path(args.directory)
    if not directory.is_dir():
        print(f"error: not a directory: {directory}", file=sys.stderr)
        return 2

    print(f"scanning {directory} (recursive={args.recursive})...",
          file=sys.stderr)

    def _progress(done: int, total: int, name: str) -> None:
        sys.stderr.write(f"\r  [{done}/{total}] {name[:50]:<50s}")
        sys.stderr.flush()

    results = scan_directory(
        directory, recursive=args.recursive,
        extract=args.extract, on_progress=_progress,
        max_files=args.max_files,
    )
    sys.stderr.write("\r" + " " * 70 + "\r")

    clean = sum(1 for r in results if r.verdict == "CLEAN")
    susp = sum(1 for r in results if r.verdict == "SUSPICIOUS")
    likely = sum(1 for r in results if r.verdict == "LIKELY HIDDEN DATA")
    errors = sum(1 for r in results if r.verdict == "ERROR")

    print(f"\n{'rank':>4s}  {'verdict':22s} {'score':>5s}  "
          f"{'chi_max':>8s} {'rs_imb':>8s}  filename")
    print("-" * 90)
    for rank, r in enumerate(results, start=1):
        tag = r.verdict if r.verdict != "ERROR" else f"ERROR ({r.error})"
        print(f"{rank:4d}  {tag:22s} {r.score:5d}  "
              f"{r.chi_max:8.3f} {r.rs_imbalance:8.4f}  {r.filename}")

    print(f"\nSummary: {len(results)} image(s) — "
          f"{clean} CLEAN, {susp} SUSPICIOUS, {likely} LIKELY HIDDEN DATA, "
          f"{errors} error(s)")

    if args.output:
        from ..core.batch import save_batch_results, unique_report_path
        try:
            written = save_batch_results(results, args.output,
                                         overwrite=args.force)
        except FileExistsError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 7
        print(f"batch results written: {written['csv']}, {written['json']}",
              file=sys.stderr)

    if args.report_dir:
        rd = Path(args.report_dir)
        rd.mkdir(parents=True, exist_ok=True)
        n_written = 0
        for r in results:
            if r.report is None:
                continue
            # Unique, traversal-safe path per image basename.
            target = unique_report_path(rd, r.filename, args.report_fmt)
            # If --force is set and the unique path equals an existing
            # file (the _1, _2… collision), allow overwrite; otherwise
            # unique_report_path already avoids collisions.
            try:
                save_report(r.report, target, fmt=args.report_fmt,
                            overwrite=args.force)
                n_written += 1
            except FileExistsError as exc:
                print(f"error writing report for {r.filename}: {exc}",
                      file=sys.stderr)
            except ReportFormatError as exc:
                print(f"error writing report for {r.filename}: {exc}",
                      file=sys.stderr)
        print(f"per-image reports written: {n_written} ({args.report_fmt})",
              file=sys.stderr)

    return 0


# --------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    init_logging(level=10 if args.verbose else 20)

    if args.command == "version":
        return _cmd_version()
    if args.command == "scan":
        return _cmd_scan(args)
    if args.command == "batch":
        return _cmd_batch(args)
    parser.print_help()
    return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
