"""Application configuration and detection thresholds.

All thresholds are deliberately exposed and documented so that the
behaviour of the verdict engine is transparent and reproducible.  They
are *calibrated heuristics* derived from the published behaviour of the
Westfeld-Pfitzmann Chi-Square attack and Fridrich-Goljan-Du RS-analysis
on natural photographic imagery — they are **not** a guarantee of correct
classification.  See ``docs/DETECTION_METHODOLOGY.md`` for the rationale.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Thresholds:
    """Verdict-engine thresholds (values in the 0–100 suspicion scale)."""

    # Overall suspicion score cut-offs.
    clean_max: int = 40
    """Scores at or below this value yield a ``CLEAN`` verdict."""

    suspicious_max: int = 70
    """Scores above ``clean_max`` and at or below this value yield
    ``SUSPICIOUS``.  Anything above is ``LIKELY HIDDEN DATA``."""

    # Per-detector weights (must sum to 1.0).
    weight_lsb: float = 0.20
    weight_chi: float = 0.40
    weight_rs: float = 0.40

    # LSB balance scoring.  ``balance_deviation`` = |lsb_mean - 0.5|.
    lsb_balance_strong: float = 0.005
    lsb_balance_moderate: float = 0.01
    lsb_balance_weak: float = 0.02
    lsb_balance_negligible: float = 0.05

    # RS imbalance scoring.  ``imbalance`` = |d0 - d_-1| in [-1, 1].
    rs_imbalance_scale: float = 800.0
    """Multiplier converting |imbalance| to a 0–100 score."""

    rs_rate_scale: float = 200.0
    """Multiplier converting the estimated embedding rate to a 0–100
    score.  ``rs_score = max(imbalance_score, rate_score)``."""

    def weights_sum_to_one(self) -> bool:
        return abs(self.weight_lsb + self.weight_chi + self.weight_rs - 1.0) < 1e-6


@dataclass
class AppConfig:
    """Global application configuration."""

    app_name: str = "StegoScope"
    app_version: str = "1.0.0"
    developer: str = "StegoScope Labs"
    tagline: str = "Detect. Analyze. Investigate."

    # IO / safety.
    supported_read_formats: tuple[str, ...] = ("PNG", "BMP")
    max_image_pixels: int = 60_000_000  # refuse to load images larger than this
    max_payload_extract_bytes: int = 8 * 1024 * 1024  # 8 MiB candidate cap

    # Reporting.
    default_report_dir: Path = Path("reports")

    # Look & feel.
    theme: str = "light"

    thresholds: Thresholds = field(default_factory=Thresholds)

    def verdict_label(self, score: int) -> str:
        if score <= self.thresholds.clean_max:
            return "CLEAN"
        if score <= self.thresholds.suspicious_max:
            return "SUSPICIOUS"
        return "LIKELY HIDDEN DATA"


_CONFIG: AppConfig | None = None


def get_config() -> AppConfig:
    """Return the process-wide :class:`AppConfig` singleton."""

    global _CONFIG
    if _CONFIG is None:
        _CONFIG = AppConfig()
    return _CONFIG
