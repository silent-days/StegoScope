"""Safety limits for image loading.

StegoScope refuses to load images whose decoded pixel count exceeds a
configurable ceiling.  This prevents a maliciously crafted image (or an
honest but enormous scan) from exhausting memory.  The check is
performed against the *decoded* dimensions reported by Pillow, not the
compressed file size, so a small PNG that decodes to a huge canvas is
still rejected.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..utils.logger import get_logger

_log = get_logger("limits")


class ImageTooLargeError(Exception):
    """Raised when an image exceeds the configured pixel ceiling."""


@dataclass(frozen=True)
class ImageLimits:
    max_pixels: int = 60_000_000
    """Refuse images whose width*height exceeds this value."""

    max_file_bytes: int = 200 * 1024 * 1024
    """Refuse source files larger than this on disk (200 MiB)."""


def enforce_limits(width: int, height: int,
                   file_size: int | None,
                   limits: ImageLimits | None = None) -> None:
    """Raise :class:`ImageTooLargeError` if the image is too large.

    Parameters
    ----------
    width, height
        Decoded pixel dimensions.
    file_size
        Source file size in bytes, or ``None`` if unknown.
    limits
        Optional override; defaults to :class:`ImageLimits`.
    """

    lim = limits or ImageLimits()
    pixels = width * height
    if pixels > lim.max_pixels:
        _log.warning("rejecting image: %dx%d = %d pixels > %d",
                     width, height, pixels, lim.max_pixels)
        raise ImageTooLargeError(
            f"Image dimensions {width}x{height} ({pixels:,} pixels) exceed "
            f"the configured ceiling of {lim.max_pixels:,} pixels. "
            f"Raise utils.ImageLimits.max_pixels to allow it."
        )
    if file_size is not None and file_size > lim.max_file_bytes:
        _log.warning("rejecting image: file size %d > %d", file_size, lim.max_file_bytes)
        raise ImageTooLargeError(
            f"Source file is {file_size:,} bytes which exceeds the "
            f"{lim.max_file_bytes:,} byte ceiling."
        )
