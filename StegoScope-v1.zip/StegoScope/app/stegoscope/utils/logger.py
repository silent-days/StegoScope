"""Structured logging for StegoScope.

A single named logger ``stegoscope`` is used throughout the application.
``init_logging`` configures it once; every other module obtains a child
logger via :func:`get_logger`.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

_INITIALIZED = False
_DEFAULT_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"


def init_logging(level: int = logging.INFO,
                 log_file: Path | None = None,
                 force: bool = False) -> logging.Logger:
    """Initialise the root ``stegoscope`` logger.

    Parameters
    ----------
    level
        Logging level for stderr output.
    log_file
        Optional file path for persistent logs.
    force
        Re-initialise even if already initialised.
    """

    global _INITIALIZED
    root = logging.getLogger("stegoscope")
    if _INITIALIZED and not force:
        return root

    if force:
        for handler in list(root.handlers):
            root.removeHandler(handler)

    root.setLevel(logging.DEBUG)
    formatter = logging.Formatter(_DEFAULT_FORMAT)

    stream = logging.StreamHandler(sys.stderr)
    stream.setLevel(level)
    stream.setFormatter(formatter)
    root.addHandler(stream)

    if log_file is not None:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(formatter)
        root.addHandler(fh)

    _INITIALIZED = True
    return root


def get_logger(name: str = "stegoscope") -> logging.Logger:
    """Return a child logger under the ``stegoscope`` namespace."""

    if not name.startswith("stegoscope"):
        name = f"stegoscope.{name}"
    return logging.getLogger(name)
