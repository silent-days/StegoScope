#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="${PYTHON:-python3}"
if [ -x "${SCRIPT_DIR}/.venv/bin/python" ]; then
    PY="${SCRIPT_DIR}/.venv/bin/python"
fi
if ! "$PY" -c 'import sys; print(sys.prefix != sys.base_prefix)' 2>/dev/null | grep -q True; then
    BOOTSTRAP="${SCRIPT_DIR}/.installer-venv"
    if [ ! -x "${BOOTSTRAP}/bin/python" ]; then
        echo "Creating private graphical-installer environment..."
        "$PY" -m venv "$BOOTSTRAP"
    fi
    PY="${BOOTSTRAP}/bin/python"
fi
if ! "$PY" -c 'from PySide6.QtCore import QProcess' >/dev/null 2>&1; then
    echo "Preparing the graphical installer runtime..."
    "$PY" -m pip install --quiet PySide6
fi
exec "$PY" "${SCRIPT_DIR}/install_gui.py" "$@"
