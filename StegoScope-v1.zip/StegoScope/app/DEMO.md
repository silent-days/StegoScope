# StegoScope: Demo & Walkthrough

This is the short demo and write-up required by the assignment: run the
tool on **one clean image** and **one stego sample** (both made by our own
Python embedding script, lab-only), read both reports, and explain one
flagged image — what the scores showed, why it was flagged, and how it was
confirmed.

All commands below were executed in the lab and their **real output** is
reproduced here.

---

## 0. Build the lab samples (ground truth you control)

```bash
cd StegoScope
python -c "import sys; sys.path.insert(0,'.'); \
from tests.helpers.make_samples import generate_sample_suite; \
generate_sample_suite('samples')"
```

This creates `samples/clean_rgb.png` (clean synthetic imagery) and
`samples/embedded_full.png` (the same cover with a 100%-filled random LSB
payload), plus the other lab samples. Because we embed with our own
script, we know exactly which image is clean and which is stego.

---

## 1. Scan the clean image

```bash
python -m stegoscope scan samples/clean_rgb.png
```

Verdict line (printed to stderr):

```
>>> clean_rgb.png: score=20 verdict=CLEAN
```

Key report fields (from the TXT report):

```
LSB ANALYSIS
  channel    zeros%    ones%     mean  longest  bit
  R          50.026   49.974   0.4997       15    0
  Channel imbalance (max-min LSB mean): 0.001999

Chi-Square
  Max embedding probability across channels: 0.0000

RS ANALYSIS
  R   R_M=0.5228  S_M=0.4772  d0=0.0455  d_-1=0.0480  imb=0.0024
  Max |d0 - d_-1| imbalance across channels: 0.0089

VERDICT
  Suspicion score : 20 / 100
  Verdict         : CLEAN
  Confidence      : LOW — no detector reports a strong anomaly. A CLEAN
                    verdict is not proof that no payload exists; only
                    that none was found.
```

**Reading it:** the LSB means sit near 0.5 (a weak hint on its own, since
noisy natural imagery also approaches 0.5), but the Chi-Square embedding
probability is **0.0000** (the value-pair histogram is *not* balanced —
structured/natural) and the RS imbalance is **0.0089** (tiny — the two
flipping masks agree, as they should for a clean image). The 20% LSB
weight contributes only ~18 points; Chi and RS contribute ~0. Total 20 →
CLEAN. The full report is saved in `reports/example_clean.txt` /
`.pdf`.

---

## 2. Scan the stego image (and extract the candidate payload)

```bash
python -m stegoscope scan samples/embedded_full.png --extract \
    --report reports/example_embedded.pdf
```

Verdict line:

```
>>> embedded_full.png: score=80 verdict=LIKELY HIDDEN DATA
```

Key report fields:

```
LSB ANALYSIS
  R   zeros%=50.015  ones%=49.985  mean=0.4998
  G   zeros%=50.082  ones%=49.918  mean=0.4992
  B   zeros%=50.386  ones%=49.614  mean=0.4961

Chi-Square
  R   statistic=126.45  dof=127  p_value=0.4970  embed_prob=0.4970
  G   statistic=136.32  dof=127  p_value=0.2700  embed_prob=0.2700
  B   statistic=109.30  dof=127  p_value=0.8696  embed_prob=0.8696
  Max embedding probability across channels: 0.8696

RS ANALYSIS
  R   d0=-0.0089  d_-1=0.1116  imb=0.1205
  G   d0= 0.0066  d_-1=0.0927  imb=0.0861
  B   d0=-0.0133  d_-1=0.1104  imb=0.1237
  Max |d0 - d_-1| imbalance across channels: 0.1237

VERDICT
  Suspicion score : 80 / 100
  Verdict         : LIKELY HIDDEN DATA
  Confidence      : HIGH — multiple independent detectors and channels
                    agree, but statistical steganalysis is never a proof
                    of payload.
  Per-channel findings:
    [R] score= 76 (LSB  90, Chi  50, RS  96)
    [G] score= 56 (LSB  90, Chi  27, RS  69)
    [B] score= 92 (LSB  90, Chi  87, RS  99)
```

The full report is saved in `reports/example_embedded.txt` / `.pdf`.

---

## 3. Explain one flagged image — `embedded_full.png`

**What the scores showed.** Three independent detectors, all pointing the
same way on multiple channels:

1. **LSB-plane analysis** — every channel's LSB mean is within 0.004 of
   0.5 (R=0.4998, G=0.4992, B=0.4961). A perfectly random bit stream sits
   at 0.5, so this is consistent with random LSB replacement. It is a
   *weak* signal on its own (noisy natural images also hit 0.5), which is
   why it carries only 20% of the weight — but here it is corroborated.
2. **Chi-Square (Westfeld-Pfitzmann)** — the embedding-probability
   heuristic on the **B** channel is **0.87** (statistic=109.3, dof=127).
   Random LSB replacement balances adjacent value pairs (0/1, 2/3, …),
   and the B-channel histogram is strongly consistent with that balanced
   state. (R and G carry a structured payload on part of the channel, so
   they are less balanced — 0.50 and 0.27 — but the max across channels
   is what the verdict uses.)
3. **RS-analysis** — the regular/singular imbalance is **0.12** on R and
   B (clean baseline ≈ 0.009). LSB replacement breaks the symmetry
   between the positive (M) and negative (−M) flipping masks; the
   divergence is the most reliable single signal here.

**Why it was flagged.** The per-channel scores are R=76, G=56, B=92. The
mean is ~75, and because channel B is strongly suspicious (92), the
single-channel lift raises the overall score to **80**, above the
`>70` LIKELY HIDDEN DATA threshold. Three detectors and three channels
agree → confidence HIGH.

**How it was confirmed.** The image was embedded by **our own** script, so
we know the ground truth. We then ran payload extraction and verified
byte-for-byte recovery against the known message:

```bash
python -m stegoscope scan samples/embedded_text.png \
    --payload-out candidate.bin --quiet
```

```
>>> embedded_text.png: score=70 verdict=SUSPICIOUS
original marker: b'STEGOSCOPE-FORENSIC-MARKER-This is a kno'
recovered     : b'STEGOSCOPE-FORENSIC-MARKER-This is a kno'
EXACT MATCH: True
```

The extracted bytes start with the exact plaintext marker we embedded,
confirming the detector fired for the right reason and the extractor
recovers the payload verbatim. (On a clean image, the same extraction
yields no readable planted message — see `reports/example_payload.bin`
which comes from a stego sample, never executed, inspected as hex/text
only.)

> **Caveat repeated:** a LIKELY verdict is a statistical indicator, not a
> confirmed payload, and a CLEAN verdict is not proof of absence. The
> confirmation above works only because we controlled the ground truth in
> the lab.

---

## 4. Optional: save the LSB planes as black-and-white images

```bash
python -m stegoscope scan samples/embedded_full.png \
    --lsb-planes lsb_planes/ --quiet
# writes lsb_planes/embedded_full_R_lsb.png, _G_, _B_  (0=black, 255=white)
```

Structured patterns (or, for a fully random payload, an even salt-and-pepper
noise) become visible at a glance — the classic visual steganalysis aid.

---

## 5. Batch demo (ranked, most suspicious first)

```bash
python -m stegoscope batch samples/ --output reports/example_batch
```

```
Summary: 11 image(s) — 4 CLEAN, 2 SUSPICIOUS, 4 LIKELY HIDDEN DATA, 1 error(s)
```

The one error is `corrupted.png` (deliberately truncated) — it is reported
as an ERROR row and does **not** crash the scan. Ranked output and
CSV/JSON sidecars are written to `reports/example_batch.csv` / `.json`.
