# StegoScope — Detection Methodology & Limitations

This document describes exactly what each StegoScope detector computes,
how the verdict is assembled, and — crucially — what the suite can and
cannot detect. StegoScope is a **statistical steganalytic** tool: it
flags anomalies consistent with LSB-replacement embedding. It does not
prove the existence of a payload, and a CLEAN verdict is not proof of
absence.

## 1. Threat model

StegoScope targets **naive LSB-replacement steganography** in lossless
imagery (PNG, BMP): an embedder writes message bits into the
least-significant bit of pixel values, in channel order, replacing the
original LSB. This is the simplest and historically most common form of
image steganography and the one the classical detectors were designed to
catch.

Lossy formats (JPEG, WebP) are refused at load time because quantisation
destroys the LSB structure every detector relies upon.

## 2. Image loading

`stegoscope.core.image_loader.ImageLoader` opens the image with Pillow and
enforces resource limits **before any expensive operation**:

1. The on-disk file size is checked from `stat()` *before* the file is
   handed to Pillow, so an oversized blob never reaches the decoder
   (`utils.limits.ImageLimits.max_file_bytes = 200 MiB` by default).
2. Pillow's decompression-bomb guard (`Image.MAX_IMAGE_PIXELS`) is pinned
   to the configured pixel ceiling (`60 000 000` pixels by default), so a
   tiny file whose decoded canvas is enormous is rejected at `Image.open`
   time — before a single pixel is materialised.
3. The decoded `width × height` (available from the PNG/BMP header without
   decoding the pixel stream) is re-checked against
   `enforce_limits` before any conversion or `np.asarray` call.

**Information preservation.** The loader never silently destroys the
original LSB information:

* Supported modes (`L`, `LA`, `RGB`, `RGBA`) are read in their **native**
  representation — no conversion, no resampling.
* Palette (`P`) images are read as their raw palette-index plane.  The
  index values are exactly what a palette-image steganographer would
  modify, so analysing the index plane preserves the original LSBs.
  Converting `P → RGB` would replace indices with palette colours and
  *change* the LSB structure, so we deliberately do not do that.
* 16-bit (`I`, `I;16`, …) and exotic modes (`CMYK`, `YCbCr`, `F`, `1`, …)
  require a lossy conversion to become analysable, which would alter the
  LSB plane.  They are refused with a clear `UnsupportedFormatError`
  rather than silently normalised.

The decoded buffer is copied into a NumPy `uint8` array; the source file
is never modified.

## 3. LSB-plane analysis

`stegoscope.analysis.lsb` extracts the LSB plane (`pixel & 1`) of every
channel and computes, per channel:

| statistic | meaning |
| --- | --- |
| `zero_count` / `one_count` | number of 0- and 1-bits in the LSB plane |
| `zero_pct` / `one_pct` | the above as percentages of total bits |
| `lsb_mean` | mean of the LSB plane (0.5 = perfectly balanced) |
| `longest_run` | longest run of equal bits in row-major order |
| `channel_imbalance` | `max(lsb_mean) − min(lsb_mean)` across channels |

A random (encrypted/compressed) payload produces an LSB mean within
~`0.5/√N` of 0.5 and a longest run near `log₂(N)`. Natural imagery has
structured LSBs whose mean wanders away from 0.5 — so an LSB mean
*suspiciously close* to 0.5 is a weak stego indicator. **LSB balance
alone is not conclusive** (noisy natural images also approach 0.5), which
is why it carries the smallest verdict weight.

## 4. Chi-Square analysis (Westfeld-Pfitzmann)

`stegoscope.analysis.chi_square` implements the attack from Westfeld &
Pfitzmann, *Attacks on Steganographic Systems* (2000). The property it
exploits: random LSB replacement makes the histogram of pixel values
pair-wise balanced — for every pair of values `(2k, 2k+1)` the two counts
become approximately equal, because LSB replacement only swaps a value
within its own pair.

For each channel:

1. Build the 256-bin histogram of pixel values.
2. Form pairs `(2k, 2k+1)` and compute `pair_total = count[2k] + count[2k+1]`.
3. The expected count under "balanced pairs" (the embedding hypothesis)
   is `pair_total / 2` for each member.
4. The Chi-Square statistic is
   `χ² = Σ (count[2k] − count[2k+1])² / pair_total`, summed over pairs
   with `pair_total > 0`.
5. Degrees of freedom `df = (number of non-empty pairs) − 1`.
6. The p-value is `P(χ² ≥ observed | balanced)` = `scipy.stats.chi2.sf(χ², df)`.
7. **The embedding probability IS the p-value.** A *large* p-value (small
   χ²) means the histogram is consistent with random embedding; a *small*
   p-value (large χ²) means the histogram is structured/natural.

> **Implementation note.** A common bug is to report `1 − p_value` as the
> embedding probability, which inverts the signal and flags clean images.
> StegoScope uses `p_value` directly and is regression-tested for the
> correct direction in `tests/test_chi_square.py::test_chi_direction_is_correct`.

**Limitations.** The Chi-Square attack only detects random LSB
replacement in a contiguous region starting at the beginning of the pixel
stream. It is blind to: LSB *matching* (±1, which does not pair-balance),
sequential payloads that start mid-image, payloads smaller than ~1% of
the image (insufficient sample), and encrypted payloads embedded in only
one channel.

## 5. RS analysis (Fridrich-Goljan-Du)

`stegoscope.analysis.rs_analysis` implements the RS method from Fridrich,
Goljan & Du, *Reliable Detection of LSB Steganography in Color and
Gray-Scale Images* (2001). Per channel:

1. Flatten the channel row-major and partition into non-overlapping
   groups of 4 pixels.
2. Discrimination function `f(x₁…xₙ) = Σ|x_{i+1} − x_i|` (a smoothness
   measure).
3. Two flipping operations:
   - **F1** (positive-mask partner): `x ↦ x XOR 1` — flips the LSB,
     swapping `0↔1, 2↔3, …`.
   - **F−1** (negative-mask partner): `x ↦ ((x+1) XOR 1) − 1`, clamped to
     `[0, 255]` at the boundaries (`−1 → 0`, `256 → 255`).
4. Masks `M = (0,1,1,1)` and `−M = (0,−1,−1,−1)` apply F1 / F−1 to the
   last three positions of each group.
5. Each group is classified:
   - **Regular (R)**: smoothness *increases* after flipping,
   - **Singular (S)**: smoothness *decreases*,
   - **Unusable (U)**: unchanged.
6. The four fractions `R_M, S_M, R_−M, S_−M` characterise the channel.
   For a clean image the two masks give similar imbalances
   (`R_M − S_M ≈ R_−M − S_−M`); LSB replacement breaks this symmetry.
7. The primary detection signal is `imbalance = |d0 − d_−1|` where
   `d0 = R_M − S_M` and `d_−1 = R_−M − S_−M`.

### Embedding-rate estimate

To estimate the embedding rate, the implementation additionally simulates
"fully embedded" by applying F1 to every pixel and re-measuring under
mask M to obtain `R'_M, S'_M`, giving a third point `d1 = R'_M − S'_M`.
The three points `(d0, d_−1, d1)` define a parabola; the smaller in-range
root of

```
a = 2·(d0 + d1 − 2·d_−1)
b = (d_−1 − d1)
c = (d0 − d_−1)
a·p² + b·p + c = 0
```

is the classic RS embedding-rate estimate, clamped to `[0, 1]`.

**The rate estimate is unreliable.** On natural images the quadratic
frequently has no in-range root or a spurious one; such results are
reported as `0` with `rate_valid = False`. The verdict engine only lets
the rate contribute when (a) the solver returned a valid in-range root
and (b) the reliable imbalance signal already corroborates stego activity
— and even then it is capped so a rogue rate cannot dominate. **Treat the
imbalance as the primary RS signal and the rate as indicative only.**

**Other limitations.** RS assumes random, sequential LSB replacement; it
misses LSB matching and adaptive steganography. It is sensitive to image
content (synthetic / flat images give noisy estimates). Constant channels
(e.g. an all-opaque alpha plane) are detected and short-circuited to
avoid the spurious `imbalance ≈ 1` that flipping a flat plane would
otherwise produce.

## 6. Verdict engine

`stegoscope.core.verdict._build_verdict` combines the three detectors per
channel into a 0–100 suspicion score:

```
channel_score = 0.20·LSB_score + 0.40·Chi_score + 0.40·RS_score
overall       = mean(channel_score)
```

with a partial lift toward the maximum channel score when at least one
channel is strongly suspicious, so a single-channel payload is not masked
by averaging. The verdict thresholds (editable live in **Settings**) are:

| score | verdict |
| --- | --- |
| ≤ 40 | `CLEAN` |
| 41–70 | `SUSPICIOUS` |
| > 70 | `LIKELY HIDDEN DATA` |

The engine never reports certainty. Every verdict carries a confidence
caveat (`LOW` / `MEDIUM` / `HIGH`) that describes how much agreement
exists across detectors and channels, and explicitly reminds the analyst
that statistical steganalysis is never a proof of payload.

### Scoring details

- **LSB score** — bucketed by `|lsb_mean − 0.5|` (tighter deviation →
  higher score).
- **Chi score** — `round(embedding_probability · 100)`.
- **RS score** — `max(imbalance_score, rate_score_if_corroborated)` where
  `imbalance_score = min(100, |imbalance| · 800)` and the rate contributes
  only when `imbalance_score ≥ 30` and the rate is valid, capped at 60.

## 7. Payload extraction

`stegoscope.extraction.payload` reconstructs the byte stream a naive
LSB-replacement embedder would have produced: it reads the LSB of every
pixel in channel order (R, G, B, A) and packs bits MSB-first into bytes.

**Extracted bytes are CANDIDATE data, never confirmed payload.** They are
untrusted input. StegoScope will never execute, interpret, or follow
instructions in them. Saving writes a `.bin` file (with a forced `.bin`
extension) so the OS cannot mistake it for an executable. The
`tests/test_payload.py::test_payload_never_executed` test asserts the
module source contains no `eval`, `exec`, `os.system`, `subprocess`, or
`Popen` references.

## 8. What StegoScope does NOT detect

- **LSB matching (±1 steganography)** — modifies pixel values by ±1
  rather than replacing the LSB, so it does not pair-balance the
  histogram and is invisible to the Chi-Square attack; the RS signal is
  also much weaker.
- **Adaptive / model-based steganography** (HUGO, WOW, S-UNIWARD,
  J-UNIWARD, F5, nsF5, …) — these minimise distortion with respect to a
  statistical model and are designed to evade exactly the detectors
  StegoScope implements.
- **Payloads in lossy-compressed sources** — refused at load time.
- **Steganography in domains other than the spatial LSB** (DCT
  coefficients, frequency domain, palette tricks, etc.).

A CLEAN verdict from StegoScope means *none of the three detectors
reported a statistically significant anomaly*. It is **not** a guarantee
that the image is clean. Use StegoScope as one tool in a broader forensic
workflow, not as a definitive oracle.

## 9. Validation

The test suite (`tests/`) generates controlled laboratory images with
known ground truth — clean natural-ish imagery and images with known LSB
payloads of varying sizes — and asserts:

- no clean image is classified `LIKELY HIDDEN DATA`,
- every embedded image is flagged at least `SUSPICIOUS`,
- a fully-embedded RGB image reaches `LIKELY HIDDEN DATA`,
- a known plaintext marker round-trips through extraction,
- the Chi-Square signal direction is correct (regression guard).

These describe a controlled synthetic suite, not real-world photographs.
They are a sanity check that the detectors fire in the right direction,
not a performance claim against arbitrary images.
