# StegoScope — Linux Installation

StegoScope runs on Kali Linux, Ubuntu, Debian, BlackArch and any
distribution with Python 3.11+ and the standard build toolchain.

## 1. System dependencies

A few shared libraries are needed for PySide6 (Qt) and Pillow image
handling. Install them with your distribution's package manager.

### Ubuntu / Debian / Kali (apt)

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv \
    libegl1 libgl1 libglib2.0-0 libfontconfig1 libxkbcommon0 \
    libdbus-1-3 libxcb-cursor0
```

### BlackArch / Arch (pacman)

```bash
sudo pacman -Syu --needed python python-pip python-virtualenv \
    libegl libgl glib2 fontconfig xorg-server-xpyb
```

## 2. Automated install

```bash
git clone <your-repo-url> STEGOSCOPE
cd STEGOSCOPE
chmod +x install.sh run.sh
./install.sh
```

`install.sh` performs:

1. Creates a virtual environment at `.venv/`.
2. Upgrades `pip` and installs `requirements.txt`.
3. Installs the `stegoscope` package in editable mode (`pip install -e .`).
4. Registers a desktop launcher at `~/.local/share/applications/StegoScope.desktop`.

After it finishes, launch with:

```bash
./run.sh              # GUI
.venv/bin/stegoscope version   # CLI sanity check
```

Or open **StegoScope** from your application menu.

## 3. Manual install

If you prefer to do it by hand:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e .

# run the GUI
python main.py

# or the CLI
stegoscope version
stegoscope scan image.png --report report.pdf
```

## 4. Desktop launcher (optional)

`install.sh` writes this file automatically. To do it manually, create
`~/.local/share/applications/StegoScope.desktop`:

```ini
[Desktop Entry]
Name=StegoScope
Comment=Advanced Steganography Intelligence Suite
Exec=/path/to/STEGOSCOPE/run.sh
Icon=/path/to/STEGOSCOPE/assets/icons/stegoscope_logo.png
Terminal=false
Type=Application
Categories=Security;Utility;
```

Replace `/path/to/STEGOSCOPE` with the absolute path to your checkout.

## 5. Headless / server use

The CLI works with no display attached. To run the GUI over SSH or on a
headless host, force the offscreen platform:

```bash
QT_QPA_PLATFORM=offscreen python main.py --gui   # not interactive
```

For interactive headless access use Xvnc or `xvfb-run`:

```bash
xvfb-run -a python main.py
```

## 6. Building a Linux executable

```bash
source .venv/bin/activate
pip install pyinstaller
pyinstaller --name stegoscope --windowed --onedir \
    --add-data "assets:assets" main.py
```

The bundled application appears in `dist/stegoscope/`.

## Troubleshooting

- **`libEGL.so.1: cannot open shared object file`** — install `libegl1`
  (apt) or `libegl` (pacman).
- **`ModuleNotFoundError: No module named 'PySide6'`** — make sure the
  virtual environment is activated (`source .venv/bin/activate`).
- **GUI launches but is blank** — your system may be missing GL drivers;
  try `QT_QPA_PLATFORM=software python main.py` (not supported on all Qt
  builds).
