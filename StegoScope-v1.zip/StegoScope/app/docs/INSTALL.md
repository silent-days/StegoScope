# StegoScope Installation and Uninstallation

StegoScope supports two installation styles. The recommended style for a
cloned GitHub checkout is the included launcher installer. It keeps all Python
dependencies isolated in `.venv`, creates a desktop-menu entry on Linux, and
never modifies system Python.

## Linux, Kali, Ubuntu, Debian, BlackArch

```bash
git clone https://github.com/YOUR-USER/StegoScope.git
cd StegoScope
chmod +x install.sh run.sh uninstall.sh
./install.sh
```

Launch the GUI:

```bash
./run.sh
```

Run the CLI using the installed project environment:

```bash
.venv/bin/stegoscope version
.venv/bin/stegoscope scan samples/embedded_text.png --report reports/scan.json
.venv/bin/stegoscan batch samples/ --output reports/batch
```

The Linux installer registers `~/.local/share/applications/StegoScope.desktop`.
The source checkout is the application directory, so keep it in a permanent
location rather than a temporary Downloads folder.

### Global command with pipx

For a command available from any directory, install the package with `pipx`:

```bash
python3 -m pip install --user pipx
python3 -m pipx ensurepath
pipx install .
stegoscope version
stegoscope scan /path/to/image.png
```

The GUI console entry is `stegoscope-gui`. Use `pipx uninstall stegoscope` to
remove the pipx installation. The repository installer and pipx installation
are independent; uninstalling one does not remove the other.

## Windows 10/11

Open PowerShell or Command Prompt in the cloned folder:

```bat
install.bat
run.bat
```

CLI commands are available through the environment:

```bat
.venv\Scripts\stegoscope.exe version
.venv\Scripts\stegoscan.exe scan samples\embedded_text.png
```

## Uninstall

From the same checkout:

```bash
./uninstall.sh
```

On Windows:

```bat
uninstall.bat
```

These commands remove the local virtual environment and launcher support but
preserve source code, samples, reports and configuration. Add `--purge` to
also remove build/test caches:

```bash
./uninstall.sh --purge
uninstall.bat --purge
```

For pipx installations, use:

```bash
pipx uninstall stegoscope
```

## Troubleshooting

If `python3 -m venv` fails on Debian-based systems, install the venv package:

```bash
sudo apt update && sudo apt install python3-venv python3-pip
```

If the CLI works but the GUI does not start on Linux, install the OpenGL
runtime libraries:

```bash
sudo apt install libegl1 libgl1
```

All image analysis is local. StegoScope does not upload images or contact a
remote service during installation or analysis.
