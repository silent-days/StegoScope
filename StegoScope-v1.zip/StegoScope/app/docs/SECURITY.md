# StegoScope: Security Notes

StegoScope processes **untrusted input** (arbitrary image files from disk,
including adversarially crafted ones) and writes **forensic output**
(reports, candidate payloads, batch results). This document describes the
security model and the concrete controls implemented to make the tool safe
to run on hostile input.

## Threat model

The assumed adversary can supply *any* file to the loader and *any*
directory to the batch scanner. The tool must not, as a result:

* exhaust memory (decompression bombs, huge canvases),
* exhaust CPU (pathological decodes),
* overwrite or clobber existing user files,
* traverse out of an intended output directory,
* execute or interpret extracted bytes,
* leak sensitive information, or
* crash the whole scan because one file is malformed.

## Controls implemented

### Resource exhaustion (memory / CPU)

| Control | Where | Effect |
| --- | --- | --- |
| On-disk file-size guard | `image_loader.py` (before `Image.open`) | files > 200 MiB are rejected before Pillow touches them |
| Pillow decompression-bomb guard | `image_loader.py` (`Image.MAX_IMAGE_PIXELS` pinned to the pixel ceiling) | a tiny file with an enormous decoded canvas is rejected at open time |
| Decoded pixel-count ceiling | `utils/limits.enforce_limits` (from the header, before decode) | images > 60 000 000 pixels are rejected before the pixel buffer is materialised |
| Truncated-image refusal | `ImageFile.LOAD_TRUNCATED_IMAGES = False` | partial pixel data never silently corrupts statistics |
| Batch file-count cap | `core/batch.scan_directory(max_files=…)` | bounds total work for huge directories |
| Per-file isolation | `scan_directory` wraps each `analyze_image` in try/except | one bad file never aborts the batch |
| Extraction byte cap | `extraction.payload.extract_payload(max_bytes=…)` | candidate extraction is bounded (default 8 MiB) |

### File-write safety

* **Overwrite protection** — `save_payload`, `save_report` and
  `save_batch_results` all refuse to overwrite an existing file unless
  `overwrite=True` is passed (CLI: `--force`). This prevents accidental
  clobbering of evidence or user files.
* **Forced `.bin` extension** — candidate payloads are always written with
  a `.bin` extension (appended if another/none is given), so the OS cannot
  auto-execute them. Files are created with default (non-executable)
  permissions.
* **Traversal-safe report paths** — per-image batch reports are built from
  `Path(filename).stem` (the final path component only), so a maliciously
  named image (`../../etc/passwd.png`) cannot write outside the report
  directory. Duplicate basenames are de-duplicated (`<stem>_N.<ext>`).

### Extracted-data handling

Extracted bytes are **candidate data, treated as untrusted input**:

* They are never `eval`'d, `exec`'d, `subprocess`'d, `pickle`'d, or
  interpreted as code. The extraction module's source is asserted by
  `tests/test_payload.py::test_payload_never_executed` to contain no such
  references.
* They are only ever rendered as hex/printable-ASCII previews and written
  to `.bin` files.
* In PDF reports, all content-derived text is XML-escaped
  (`_xml_sanitize`) so candidate bytes cannot inject markup into the
  ReportLab parser.

### No network, no telemetry, no background services

The codebase contains **no** `requests`, `urllib`, `socket`, `http.client`
or any network call. All analysis is local. There are no background
daemons, update checks, or telemetry. (Verified by source grep.)

### No dynamic code execution

The production code contains **no** `eval`, `exec`, `compile`, `pickle`,
`marshal`, `yaml.load`, `subprocess`, `os.system`, `os.popen`, or
`shell=True`. (Verified by source grep and Bandit.)

## Static analysis & dependency audit

Run from the project root:

```bash
bandit -c .bandit -r stegoscope main.py          # static security scan
pip-audit -r requirements.txt                      # known-vuln check
```

**Results (verified in the tested environment):**

| Check | Result |
| --- | --- |
| Bandit (all severities) | **0 issues** |
| pip-audit (requirements.txt) | **0 known vulnerabilities** |

A pinned, tested lockfile (`requirements.lock.txt`) records the exact
versions these results were obtained against, for reproducible deployments.

## Reporting a vulnerability

This is a course/CEH project; there is no formal bug-bounty programme.
For educational fixes, edit the relevant module and re-run
`bandit`, `pip-audit` and `pytest tests/` before re-shipping.
