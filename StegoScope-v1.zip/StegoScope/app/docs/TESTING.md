# StegoScope: Testing Documentation

## Running the suite

```bash
# from the project root, with the venv active (or python3 if deps are global)
python -m pytest tests/ -v
```

The GUI test requires system OpenGL libraries (`libEGL`/`libGL` on Linux).
In a headless sandbox without them it is skipped automatically; on a
desktop it runs. The CLI and core tests need no display:

```bash
QT_QPA_PLATFORM=offscreen python -m pytest tests/        # headless Linux
```

## What the suite covers

The suite is split into per-module unit tests and a comprehensive
integration file (`tests/test_comprehensive.py`):

| File | Coverage |
| --- | --- |
| `test_image_loader.py` | RGB/RGBA/L/BMP load, JPEG/corrupt/missing rejection, limits |
| `test_lsb.py` | bit counts, mean, longest run, channel imbalance |
| `test_chi_square.py` | statistic/dof/p-value ranges, direction (embedding raises prob) |
| `test_rs_analysis.py` | R/S fractions, imbalance, rate validity |
| `test_verdict.py` | three verdict labels, scoring, reasons, confidence |
| `test_payload.py` | extraction, known-marker round-trip, truncation, `.bin` forcing, never-executed |
| `test_batch.py` | scan, ranking, CSV/JSON export |
| `test_reporting.py` | TXT/JSON/CSV/PDF generation, round-trip |
| `test_cli.py` | argparse, command dispatch |
| `test_main.py` | GUI/CLI dispatcher, PySide6 probe |
| `test_comprehensive.py` | modes (LA/P/16-bit/bomb/file-size), chi insufficient-sample, RS validity, payload (bit-order/interleave/single-channel/exact round-trip/overwrite/invalid dest), verdict (three labels, clean-not-proof), batch (recursive/max-files/cancellation/duplicates/traversal/corrupt-resilience/overwrite), reports (all formats/overwrite/PDF), CLI subprocess (version/scan/payload/batch/force/options), GUI startup, **detection metrics (TP/FP/TN/FN, precision, recall)** |

## Ground-truth sample generation

`tests/helpers/make_samples.py` synthesises the controlled image set with
known ground truth:

* **Clean** — gradient + perceptual noise, modes RGB/RGBA/L/BMP.
* **Stego** — naive LSB-replacement payloads (random and plaintext) at
  full and partial fill, across RGB/RGBA/L, plus a tiny (64-byte) payload.
* **Adversarial** — a truncated/corrupt PNG and a valid JPEG (rejected).

The embedder writes MSB-first in channel order (R,G,B,A), matching the
extractor's default, so byte-for-byte round-trip recovery is testable.

## Detection-metric methodology

`test_comprehensive.py::TestDetectionMetrics` classifies the controlled
suite:

* **Positive class** = embedded (stego) image.
* **Predicted positive** = verdict in `{SUSPICIOUS, LIKELY HIDDEN DATA}`.
* **Predicted negative** = verdict `CLEAN`.

and computes TP, FP, TN, FN, precision = TP/(TP+FP), recall = TP/(TP+FN).
The hard assertions are **FP == 0** (no clean image is a false positive)
and **recall ≥ 0.5** (most stego images are detected).

## Honest limitations of the test suite

* The samples are **synthetic** (gradient + noise), not real photographs.
  Real-world imagery is noisier; expect lower precision in the wild.
* Only **LSB-replacement** steganography is tested. LSB matching (±1),
  adaptive and model-based steganography are out of scope and **not
  detected** by design.
* The GUI test is skipped in sandboxes without system GL libraries — it
  does not exercise widget rendering there, only construction on a desktop.
* The metrics describe the controlled suite, not a performance guarantee.
