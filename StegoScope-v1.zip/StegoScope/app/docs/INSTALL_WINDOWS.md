# StegoScope — Windows Installation

StegoScope runs on Windows 10 and Windows 11 with Python 3.11+.

## 1. Install Python

Download Python 3.11 or newer from <https://www.python.org/downloads/windows/>.
During installation, **check "Add python.exe to PATH"**.

Verify in a Command Prompt or PowerShell:

```bat
python --version
python -m pip --version
```

## 2. Automated install

```bat
git clone <your-repo-url> STEGOSCOPE
cd STEGOSCOPE
install.bat
run.bat
```

`install.bat` performs:

1. Creates a virtual environment at `.venv\`.
2. Upgrades `pip` and installs `requirements.txt`.
3. Installs the `stegoscope` package in editable mode.

`run.bat` activates the environment and launches the GUI.

## 3. Manual install

Open a Command Prompt (or PowerShell) in the project folder:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .

:: run the GUI
python main.py

:: or the CLI
stegoscope version
stegoscope scan image.png --report report.pdf
```

## 4. Start-menu shortcut (optional)

Create a shortcut to `run.bat` (or to `python main.py` with the working
directory set to the project folder) and place it in
`%APPDATA%\Microsoft\Windows\Start Menu\Programs\`. Set the icon to
`assets\icons\stegoscope_logo.png`.

## 5. Building a Windows executable

PyInstaller produces a portable `.exe`. **Windows executables must be
built on Windows** — do not attempt to cross-build on Linux.

```bat
.venv\Scripts\activate
pip install pyinstaller
pyinstaller --name stegoscope --windowed --onedir --add-data "assets;assets" main.py
```

The bundled application appears in `dist\stegoscope\`. For a
console-based CLI build, omit `--windowed`:

```bat
pyinstaller --name stegoscope --onefile --add-data "assets;assets" main.py
```

To distribute the `dist\stegoscope\` folder, zip it and ship it — no
Python installation is required on the target machine.

## 6. PowerShell execution policy

If `install.bat` or `run.bat` are blocked by execution policy, either
use a regular Command Prompt (`.bat` files are not subject to
PowerShell policy) or run:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## Troubleshooting

- **`'python' is not recognized`** — Python is not on PATH. Reinstall
  with "Add to PATH" checked, or use the full path to `python.exe`.
- **`ModuleNotFoundError: No module named 'PySide6'`** — activate the
  virtual environment first (`.venv\Scripts\activate`).
- **Windows Defender flags the PyInstaller build** — this is a common
  false positive on bundled Python executables. Build from source with
  `pip install -e .` to avoid it, or submit the binary to Microsoft for
  review.
- **DLL errors on launch** — install the
  [Microsoft Visual C++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe).
