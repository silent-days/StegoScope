@echo off
REM
REM StegoScope - Windows launcher
REM Activates the project virtual environment and starts the GUI
REM (or the CLI if a subcommand is passed).
REM
setlocal

cd /d "%~dp0"

if not exist ".venv" (
    echo Virtual environment not found. Run install.bat first. 1>&2
    exit /b 1
)

call .venv\Scripts\activate.bat

REM Pass any arguments through to the dispatcher.
python main.py %*
