# Contributing to StegoScope

StegoScope is an offline steganalysis and digital-forensics tool. Contributions
should preserve the core safety boundary: images are analyzed locally, source
files are never modified by a scan, and extracted bytes are always untrusted
candidate data.

## Development setup

```bash
./install.sh
source .venv/bin/activate
python -m pytest -q
bandit -q -r stegoscope main.py
pyflakes stegoscope main.py
python -m build --wheel
```

Run the GUI with `./run.sh`. Use the controlled fixtures in `samples/` for
manual checks. Do not commit `.venv`, build artifacts, generated reports or
private images.

## Pull requests

Describe the user-facing behavior, add a regression test for bug fixes, and
keep CLI exit codes and report formats backwards compatible. Changes to
thresholds or detector behavior must update the methodology documentation and
include a rationale. Never add telemetry, remote image uploads or automatic
execution of extracted payloads.
