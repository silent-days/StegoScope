@echo off
REM StegoScope — Windows uninstaller
REM Removes the local environment and generated caches; source files remain.
setlocal
cd /d "%~dp0"
set "PURGE=0"
if /I "%~1"=="--purge" set "PURGE=1"
if not "%~1"=="" if not "%~1"=="--purge" (
  echo Usage: uninstall.bat [--purge]
  exit /b 2
)
if exist ".venv" (
  rmdir /s /q ".venv"
  echo Removed local virtual environment: .venv
) else (
  echo Virtual environment not present.
)
if "%PURGE%"=="1" (
  if exist "build" rmdir /s /q "build"
  if exist "dist" rmdir /s /q "dist"
  if exist ".pytest_cache" rmdir /s /q ".pytest_cache"
  if exist "stegoscope.egg-info" rmdir /s /q "stegoscope.egg-info"
  echo Removed build and test caches. Source files were preserved.
)
echo StegoScope uninstalled from this checkout. You can reinstall with install.bat.
