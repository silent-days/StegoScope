@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  set "GUI_PY=.venv\Scripts\python.exe"
) else (
  if not exist ".installer-venv\Scripts\python.exe" python -m venv .installer-venv
  set "GUI_PY=.installer-venv\Scripts\python.exe"
)
%GUI_PY% -c "from PySide6.QtCore import QProcess" >nul 2>&1
if errorlevel 1 %GUI_PY% -m pip install --quiet PySide6
%GUI_PY% install_gui.py %*
