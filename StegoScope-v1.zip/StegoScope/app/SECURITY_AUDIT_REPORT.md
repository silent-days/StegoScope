# StegoScope: Security Audit Report

**Project:** StegoScope (Python steganography detector)
**Auditor role:** Senior Python Engineer / Application Security Auditor
**Date:** 2026-11-14
**Scope:** full source tree under `stegoscope/`, `main.py`, install scripts,
test helpers, dependencies.

---

## 1. Executive summary

The audit found **one critical resource-safety bug** (limits enforced
*after* image conversion/decode, enabling memory exhaustion), **one
information-preservation bug** (16-bit and palette images silently
converted, destroying original LSBs), **one report-generation bug**
(unescaped payload bytes breaking the PDF parser), and several
robustness/completeness gaps (no cancellation in batch scans, no
overwrite protection, no payload extraction options, a malformed
sample-generator). All were fixed and verified. Static analysis
(**Bandit: 0 issues**) and dependency scanning (**pip-audit: 0 CVEs**)
are clean.

| Check | Result |
| --- | --- |
| Bandit (all severities/confidence) | **0 issues** / 4 506 LoC scanned |
| pip-audit (requirements.txt) | **0 known vulnerabilities** |
| Dangerous API grep (`eval`/`exec`/`subprocess`/`pickle`/network) | **0 occurrences** |
| Test suite | **144 passed** (GUI offscreen startup verified) |

---

## 2. Bugs found and fixed

### 2.1 CRITICAL — resource limits enforced after image conversion
**File:** `stegoscope/core/image_loader.py`
**Before:** `img.convert(mode)` (palette→RGB, 16-bit→L, exotic→RGB) ran
*before* `enforce_limits(width, height, file_size)`. A decompression-bomb
PNG (tiny file, huge decoded canvas) was fully converted into a giant
pixel buffer before the limit check rejected it — a memory-exhaustion
vector.
**Fix:** reordered to (1) on-disk file-size guard from `stat()` before
`Image.open`, (2) Pillow's `Image.MAX_IMAGE_PIXELS` pinned to the pixel
ceiling so bombs are rejected at open time, (3) `enforce_limits` from the
header dimensions *before* any conversion or `np.asarray`. No conversion
occurs for supported modes, so no buffer is allocated before the guards
pass.
**Verified:** `test_decompression_bomb_rejected`, `test_file_size_guard`.

### 2.2 CRITICAL — 16-bit images silently down-converted, destroying LSBs
**File:** `stegoscope/core/image_loader.py`
**Before:** modes `I`/`I;16` were converted to `L` (8-bit) via
`img.convert("L")`, destroying the original 16-bit pixel information.
**Fix:** 16-bit and exotic modes (`I`, `I;16`, `I;16B/L/N`, `F`, `CMYK`,
`YCbCr`, `HSV`, `1`) are now **refused** with a clear
`UnsupportedFormatError` explaining why (conversion would alter LSBs).
**Verified:** `test_16bit_rejected`.

### 2.3 HIGH — palette images converted to RGB, changing pixel representation
**File:** `stegoscope/core/image_loader.py`
**Before:** `P` mode was converted to RGB/RGBA, replacing palette indices
with palette colours and *changing the LSB structure*.
**Fix:** `P` images are now read as their **raw palette-index plane**
(single channel `"P"`), preserving the original index LSBs — exactly what
a palette-image steganographer would modify. No conversion.
**Verified:** `test_palette_mode_preserves_index_plane` (asserts index
values are byte-identical to the source).

### 2.4 HIGH — PDF report broke on payload bytes containing `<`, `>`, `&`
**File:** `stegoscope/reporting/report.py`
**Before:** the ASCII payload preview was placed into a ReportLab
`Paragraph` via `_sanitize`, which only strips non-ASCII — it did not
XML-escape `<`, `>`, `&`. Random LSB payloads frequently contain those
bytes (all printable ASCII), so reportlab's mini-XML parser raised
`paraparser: syntax error: parse ended with N unclosed tags` and the PDF
was not generated.
**Fix:** added `_xml_sanitize` (strips non-ASCII **and** XML-escapes
`&`/`<`/`>`) and used it for every content-derived PDF Paragraph (payload
ASCII/hex preview, detection reasons, limitations, confidence).
**Verified:** `test_all_formats_generate` (PDF generates for a
random-payload image), `test_pdf_contains_verdict`.

### 2.5 MEDIUM — batch scans could not be cancelled
**File:** `stegoscope/core/batch.py`, `stegoscope/gui/workers.py`
**Before:** `scan_directory` had no cancellation hook; the GUI
`BatchWorker` could not stop a long recursive scan.
**Fix:** added a `should_stop: Callable[[], bool]` predicate polled
between files; `BatchWorker.cancel()` sets a `threading.Event` wired to
it; the GUI batch page gained a Cancel button.
**Verified:** `test_cancellation`.

### 2.6 MEDIUM — no file-overwrite protection anywhere
**Files:** `extraction/payload.py`, `reporting/report.py`, `core/batch.py`
**Before:** `save_payload`, `save_report`, `save_batch_results` silently
clobbered existing files — a forensic-evidence risk.
**Fix:** all three now raise `FileExistsError` unless `overwrite=True`;
CLI exposes `--force`.
**Verified:** `test_save_payload_overwrite_protection`,
`test_save_report_overwrite_protection`,
`test_save_batch_results_overwrite_protection`, `test_scan_force_overwrite`.

### 2.7 MEDIUM — payload extraction lacked channel/bit-order options
**File:** `stegoscope/extraction/payload.py`
**Before:** only one extraction mode (all channels, MSB-first,
channel-sequential). The assignment also requires per-channel,
configurable bit-order and RGB-interleaved extraction.
**Fix:** added `channels` (subset/single), `bit_order` ("msb"/"lsb") and
`interleave` (channel-sequential default vs true round-robin), threaded
through `analyze_image` and the CLI. The default (R,G,B,A, MSB-first,
channel-sequential) is unchanged — the assignment-required order.
**Verified:** `test_exact_roundtrip_msb_default`,
`test_lsb_bit_order_roundtrip`, `test_interleave_mode`,
`test_single_channel_extraction`.

### 2.8 MEDIUM — batch per-image reports clobbered on duplicate basenames
**File:** `stegoscope/cli/cli.py` (via `core/batch.unique_report_path`)
**Before:** recursive scans writing per-image reports used
`rd / Path(r.filename).stem`, so two files named `dup.png` in different
subdirs overwrote each other.
**Fix:** `unique_report_path` builds a traversal-safe path from the
basename stem and de-duplicates (`<stem>_N.<ext>`).
**Verified:** `test_duplicate_filenames_unique_reports`,
`test_unique_report_path_no_traversal`.

### 2.9 LOW — sample generator zeroed unembedded LSBs
**File:** `tests/helpers/make_samples.py`
**Before:** `embed_lsb_payload(fill=False)` initialised the bit stream to
zeros and wrote whole planes, so channels beyond the payload had their
LSBs **zeroed** (not left at cover values) — producing malformed test
samples.
**Fix:** rewrite to write payload bits sequentially and leave the
remainder at original cover values (or random-fill when `fill=True`).
**Verified:** payload round-trips exactly (`test_exact_roundtrip_*`).

### 2.10 LOW — Chi-Square conflated p-value with heuristic in docs; no insufficient-sample flag
**File:** `stegoscope/analysis/chi_square.py`
**Before:** the goodness-of-fit p-value and the Westfeld-Pfitzmann
embedding-probability heuristic were the same number with no semantic
distinction, and insufficient samples returned `embedding_probability=0`
alongside `p_value=1.0` with no flag.
**Fix:** added `insufficient_sample: bool` (set when <2 populated pairs or
any expected cell <5); `max_embedding_probability` now excludes
insufficient channels; docstrings explicitly state that **neither the
p-value nor the embedding probability is the probability that hidden data
is present**. The math (pairing, statistic, dof, survival-function p-value)
was verified correct and unchanged.
**Verified:** `test_insufficient_sample_flagged`, `test_chi_direction_is_correct`.

### 2.11 LOW — verdict notes did not flag inconclusive Chi-Square
**File:** `stegoscope/core/verdict.py`
**Before:** a channel with insufficient Chi-Square sample contributed
`embedding_probability=0` with no note, so the analyst could read "clean"
instead of "inconclusive".
**Fix:** added an explicit note when `insufficient_sample` is true.
**Verified:** `test_reasons_documented`.

---

## 3. Security improvements (beyond bug fixes)

* **Pillow decompression-bomb guard** pinned to the configured pixel
  ceiling (`Image.MAX_IMAGE_PIXELS`), rejecting weaponised PNGs at open
  time.
* **Truncated-image refusal** (`LOAD_TRUNCATED_IMAGES = False`) so partial
  pixel data cannot silently corrupt statistics.
* **Batch `max_files` cap** bounds total work for huge directories.
* **Per-file isolation** in `scan_directory` — one corrupt/oversized file
  is captured as an `ERROR` row, never aborting the batch.
* **Forced `.bin` extension + non-executable permissions** for candidate
  payloads; extraction module asserted to contain no
  `eval`/`exec`/`subprocess`/`Popen` (`test_payload_never_executed`).
* **Pinned, tested dependency lockfile** (`requirements.lock.txt`) and a
  `.bandit` config; `dev` optional-dependency group adds `bandit` +
  `pip-audit`.

---

## 4. Files modified

| File | Change |
| --- | --- |
| `stegoscope/core/image_loader.py` | rewritten — limits-before-decode, P/16-bit/exotic mode handling, bomb guard |
| `stegoscope/analysis/chi_square.py` | `insufficient_sample` flag, max excludes insufficient, doc rewrite |
| `stegoscope/core/verdict.py` | insufficient-sample notes, extraction-option pass-through |
| `stegoscope/extraction/payload.py` | rewritten — channels/bit_order/interleave, overwrite protection, `.bin` forcing |
| `stegoscope/core/batch.py` | rewritten — cancellation, max_files, unique_report_path, overwrite protection |
| `stegoscope/reporting/report.py` | `_xml_sanitize` for PDF, `overwrite` param on `save_report` |
| `stegoscope/cli/cli.py` | extraction options, `--force`, `--max-files`, unique per-image reports |
| `stegoscope/gui/workers.py` | `BatchWorker.cancel()` + `max_files` |
| `stegoscope/gui/pages/batch.py` | Cancel button + max-files control |
| `stegoscope/__init__.py` | StegoScope identity |
| `tests/helpers/make_samples.py` | fixed `embed_lsb_payload` zeroing bug |
| `tests/test_comprehensive.py` | new comprehensive suite + metrics + monotonicity + LSB-plane export |
| `install.sh` / `install.bat` | GL-deps notice, version validation, error handling |
| `requirements.lock.txt`, `.bandit` | new |
| `pyproject.toml` | `dev` extras (bandit/pip-audit); `stegoscan` console-script alias |
| `stegoscope/visualization/plots.py` | `save_lsb_planes` B&W LSB-plane export (stretch feature) |
| `stegoscope/cli/cli.py` | `--lsb-planes` option + extraction options + `--force`/`--max-files` |
| `README.md`, `docs/*`, `DEMO.md` | identity, real metrics, score-meaning table, demo walkthrough |

---

## 5. Outstanding items / limitations

* The GUI could not be **construct-tested** in this sandbox because
  PySide6's Qt shared libraries require `libEGL.so.1`, which is not
  installed and could not be installed without root. The GUI code is
  verified by inspection (real backend via workers, no hardcoded scores)
  and runs on any desktop with Qt's GL deps; `install.sh` detects the
  missing library and prints the `apt install libegl1 libgl1` fix.
* The `install.bat` Windows path was **syntax-reviewed but not executed**
  (no Windows host in the sandbox). It follows the same validated
  structure as `install.sh`.
* Detection is limited to LSB-replacement steganography by design (see
  `docs/DETECTION_METHODOLOGY.md`); LSB matching, adaptive and
  model-based steganography are not detected.
