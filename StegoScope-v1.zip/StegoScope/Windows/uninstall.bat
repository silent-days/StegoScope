@echo off
cd /d "%~dp0..\app"
call uninstall.bat %*
