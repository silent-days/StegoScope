@echo off
cd /d "%~dp0..\app"
call install-gui.bat %*
