@echo off
cd /d "%~dp0..\app"
call run.bat %*
